from __future__ import annotations

import asyncio
from typing import Any

from core.db import read_db_sections
from core.async_runtime import run_blocking
from core.utils import utc_iso
from modules.iran_prices import fetch_iran_market_snapshot
from modules.product_intelligence import market_regime_dashboard
from modules.portfolio import watchlist_for_user
from modules.prices import fetch_market_quote, normalize_market_symbol
from modules.market_scope import classify_market_symbol
from repositories.v2.preferences import PreferenceRepository

_DEFAULT_SYMBOLS = ("XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "US100", "BTCUSD", "ETHUSD")


def _safe_market_symbol(value: Any) -> str:
    """Normalize user/config symbols without letting one bad row break a page."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        return normalize_market_symbol(raw)
    except (TypeError, ValueError):
        return ""


def _watchlist(user_id: int | str) -> list[dict[str, Any]]:
    normalized = PreferenceRepository().get(user_id, "user_watchlists", [])
    values = normalized if isinstance(normalized, list) else []
    legacy_db = read_db_sections(("user_watchlists", "settings", "admin_control_center"))
    legacy = watchlist_for_user(legacy_db, user_id)
    merged: dict[str, dict[str, Any]] = {}
    for item in [*legacy, *values]:
        if not isinstance(item, dict):
            continue
        symbol = _safe_market_symbol(item.get("symbol"))
        if symbol:
            merged[symbol] = {**item, "symbol": symbol}
    return list(merged.values())


async def _fetch(user_id: int | str, *, force: bool = False) -> dict[str, Any]:
    watchlist = await run_blocking(_watchlist, user_id, timeout=10)
    requested: list[str] = []
    for symbol in [*_DEFAULT_SYMBOLS, *[str(item.get("symbol") or "") for item in watchlist]]:
        clean = _safe_market_symbol(symbol)
        if clean and clean not in requested:
            requested.append(clean)
    requested = requested[:20]

    async def quote(symbol: str) -> dict[str, Any]:
        try:
            value = await asyncio.wait_for(fetch_market_quote(symbol, force=force), timeout=12)
            row = value.as_dict()
            price = float(row.get("price") or 0)
            if price <= 0 or price != price or price in {float("inf"), float("-inf")}:
                raise ValueError("INVALID_MARKET_PRICE")
            row["provider"] = row.get("source")
            row["category"] = classify_market_symbol(symbol)
            row["ok"] = True
            row["quality"] = {
                "stale": bool(row.get("stale", False)),
                "delayed": bool(row.get("delayed", False)),
                "confidence": max(0.0, min(1.0, float(row.get("confidence", 0.0) or 0.0))),
                "provider_count": max(1, int(row.get("provider_count", 1) or 1)),
                "age_seconds": max(0.0, float(row.get("age_seconds", 0.0) or 0.0)),
            }
            return row
        except Exception as exc:  # provider-specific failures must not break the entire market page
            return {"symbol": symbol, "ok": False, "error": str(exc)[:180], "updated_at": utc_iso()}

    global_rows = await asyncio.gather(*(quote(symbol) for symbol in requested))
    iran_rows: list[dict[str, Any]] = []
    iran_error = ""
    try:
        snapshot = await asyncio.wait_for(fetch_iran_market_snapshot(force=force), timeout=15)
        for item in snapshot.all_quotes:
            row = {
                "symbol": item.symbol,
                "title": item.title,
                "price": item.price,
                "unit": item.unit,
                "change_percent": item.change_percent,
                "provider": item.source,
                "source": item.source,
                "estimated": item.estimated,
                "stale": snapshot.stale,
                "updated_at": item.updated_at,
                "category": "iran",
                "ok": True,
            }
            iran_rows.append(row)
    except Exception as exc:
        iran_error = str(exc)[:180]

    successful = [row for row in global_rows if row.get("ok")]
    quote_map = {str(row.get("symbol") or ""): row for row in successful}
    enriched_watchlist: list[dict[str, Any]] = []
    for item in watchlist:
        symbol = str(item.get("symbol") or "")
        quote_row = quote_map.get(symbol)
        enriched_watchlist.append({
            **item,
            "quote": quote_row,
            "quote_available": bool(quote_row),
            "stale": bool(quote_row and quote_row.get("stale")),
            "delayed": bool(quote_row and quote_row.get("delayed")),
            "confidence": float(quote_row.get("confidence", 0.0) or 0.0) if quote_row else 0.0,
            "updated_at": quote_row.get("updated_at") if quote_row else item.get("updated_at"),
        })
    db = await run_blocking(read_db_sections, ("market_regime_history", "signals", "signal_archive", "market_prices", "price_cache"), timeout=10)
    return {
        "quotes": successful,
        "failed_quotes": [row for row in global_rows if not row.get("ok")],
        "iran_quotes": iran_rows,
        "watchlist": enriched_watchlist,
        "regime": market_regime_dashboard(db),
        "requested_symbols": requested,
        "iran_error": iran_error,
        "generated_at": utc_iso(),
        "live": True,
    }



async def _fetch_symbols(symbols: list[str], *, force: bool = False) -> dict[str, dict[str, Any]]:
    requested: list[str] = []
    for raw in symbols:
        clean = _safe_market_symbol(raw)
        if clean and clean not in requested:
            requested.append(clean)
    requested = requested[:40]

    async def quote(symbol: str) -> tuple[str, dict[str, Any]]:
        try:
            value = await asyncio.wait_for(fetch_market_quote(symbol, force=force), timeout=10)
            row = value.as_dict()
            price = float(row.get("price") or 0)
            if price <= 0 or price != price or price in {float("inf"), float("-inf")}:
                raise ValueError("INVALID_MARKET_PRICE")
            row.update({
                "provider": row.get("source"),
                "ok": True,
                "stale": bool(row.get("stale", False)),
                "category": classify_market_symbol(symbol),
            })
            return symbol, row
        except Exception as exc:
            return symbol, {"symbol": symbol, "ok": False, "error": str(exc)[:180], "updated_at": utc_iso()}

    rows = await asyncio.gather(*(quote(symbol) for symbol in requested))
    return {symbol: row for symbol, row in rows}


def live_quotes_for_symbols(symbols: list[str] | tuple[str, ...], *, force: bool = False) -> dict[str, dict[str, Any]]:
    """Return resilient current quotes for arbitrary signal symbols.

    Signal pages use this bounded helper instead of loading the entire market
    dashboard. Provider failures stay local to a symbol and never break the
    signal feed or onboarding flow.
    """
    return asyncio.run(_fetch_symbols(list(symbols), force=force))


def live_quote_snapshot(symbol: str, *, force: bool = True) -> dict[str, Any]:
    clean = _safe_market_symbol(symbol)
    if not clean:
        raise ValueError("SYMBOL_REQUIRED")
    row = asyncio.run(_fetch_symbols([clean], force=force)).get(clean) or {}
    if not row.get("ok"):
        raise ValueError(str(row.get("error") or "PRICE_UNAVAILABLE"))
    return row

def live_market_snapshot(user_id: int | str, *, force: bool = False) -> dict[str, Any]:
    """Fetch a resilient live snapshot from a worker thread.

    FastAPI invokes read services through ``run_blocking``, so this function can
    own an event loop without interfering with Telegram's application loop.
    """
    return asyncio.run(_fetch(user_id, force=force))
