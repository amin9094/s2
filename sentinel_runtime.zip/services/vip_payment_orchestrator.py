from __future__ import annotations

import logging
from typing import Any

from config import SETTINGS
from core.async_runtime import run_blocking
from modules.vip import restore_vip_channel_access
from repositories.v2.commerce import CommerceRepository
from services.vip_entitlement_projection import project_normalized_entitlements_to_legacy
from services.vip_order_projection import project_normalized_order_to_legacy, mark_projected_order_notification
from services.vip_discount_bridge import consume_normalized_order_discount, release_normalized_order_discount
from repositories.v2.events import EventRepository

logger = logging.getLogger(__name__)


async def approve_manual_vip_order(bot: Any, order_id: int | str, admin_id: int | str) -> dict[str, Any]:
    """Approve a normalized manual-payment order through one shared workflow.

    The order is first atomically claimed. Telegram access is prepared before
    entitlement finalization. Any failure releases the claim and revokes the
    unused invite when possible, so the order remains reviewable rather than
    becoming half-approved.
    """
    repo = CommerceRepository()
    claimed = repo.claim_order_for_approval(order_id, actor_id=str(admin_id))
    if str(claimed.get("status")) == "approved":
        return claimed

    invite_url = str(claimed.get("processing_invite_link") or "")
    try:
        if not invite_url:
            invite_url = await restore_vip_channel_access(bot, int(claimed["user_id"]), None)
            repo.store_order_approval_invite(claimed["id"], actor_id=str(admin_id), invite_link=invite_url)
        approved = repo.finalize_order_approval(
            claimed["id"],
            actor_id=str(admin_id),
            invite_link=invite_url,
        )
    except Exception as exc:
        logger.exception("Manual VIP approval failed order_id=%s", order_id)
        if invite_url:
            try:
                await bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_url,
                )
            except Exception:
                logger.exception("Could not revoke unused VIP invite order_id=%s", order_id)
        try:
            repo.release_order_approval(order_id, actor_id=str(admin_id), error=str(exc)[:500])
        except Exception:
            logger.exception("Could not release VIP approval claim order_id=%s", order_id)
        raise

    consume_normalized_order_discount(approved)
    project_normalized_entitlements_to_legacy(approved["user_id"])
    project_normalized_order_to_legacy(approved["id"])
    try:
        from core.db import with_db
        from core.domain import record_referral_purchase
        await run_blocking(with_db, lambda db: record_referral_purchase(db, approved["user_id"], approved["id"]), timeout=15)
    except Exception:
        logger.exception("Referral purchase reward projection failed order_id=%s", approved.get("id"))
    await run_blocking(
        EventRepository().append,
        user_id=approved["user_id"],
        event_type="order.status_changed",
        payload={"entity": approved, "source": "manual_payment_orchestrator", "actor_id": str(admin_id)},
        timeout=10,
    )
    notified = await notify_manual_order_user(bot, approved)
    mark_projected_order_notification(approved["id"], audience="user", success=notified)
    return approved


async def reject_manual_vip_order(
    bot: Any,
    order_id: int | str,
    admin_id: int | str,
    reason: str,
) -> dict[str, Any]:
    repo = CommerceRepository()
    rejected = repo.reject_order(order_id, actor_id=str(admin_id), reason=reason)
    release_normalized_order_discount(rejected)
    project_normalized_order_to_legacy(rejected["id"])
    notified = await notify_manual_order_user(bot, rejected)
    mark_projected_order_notification(rejected["id"], audience="user", success=notified)
    return rejected


async def notify_manual_order_user(bot: Any, order: dict[str, Any]) -> bool:
    status = str(order.get("status") or "")
    uid = int(order["user_id"])
    if status == "approved":
        text = (
            "✅ پرداخت شما به‌صورت دستی تأیید شد و اشتراک VIP فعال شد.\n"
            f"اعتبار اشتراک تا: {order.get('expires_at') or 'ثبت‌شده در حساب شما'}"
        )
        if order.get("invite_link"):
            text += f"\n\n🔗 لینک یک‌بارمصرف ورود به کانال VIP:\n{order['invite_link']}"
    elif status == "rejected":
        reason = str(order.get("rejection_reason") or "رسید پرداخت تأیید نشد.")[:700]
        text = f"❌ پرداخت VIP تأیید نشد.\nدلیل: {reason}\nمی‌توانید رسید صحیح را دوباره ارسال کنید."
    else:
        return False
    try:
        await bot.send_message(uid, text)
        return True
    except Exception:
        logger.exception("Could not notify VIP order user=%s order=%s", uid, order.get("id"))
        return False
