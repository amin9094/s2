from __future__ import annotations

from typing import Any

from modules.signal_status import signal_is_final
from repositories.v2.events import EventRepository
from repositories.v2.signals import SignalRepository


def canonical_signal_event(row: dict[str, Any], source_event: str = "signal.updated") -> str:
    """Collapse Telegram lifecycle variants into one Mini App event contract."""
    event = str(source_event or "signal.updated").strip().lower()
    if event == "signal.deleted":
        return event
    if event == "signal.created":
        return event
    if signal_is_final(row):
        return "signal.closed"
    return "signal.updated"


def project_signal_update(
    row: dict[str, Any],
    source_event: str = "signal.updated",
    *,
    signals: SignalRepository | None = None,
    events: EventRepository | None = None,
) -> dict[str, Any]:
    """Persist the canonical signal and publish the matching durable event."""
    normalized = (signals or SignalRepository()).upsert(dict(row))
    signal_id = str(normalized.get("id") or row.get("id") or "")
    event_type = canonical_signal_event(normalized, source_event)
    (events or EventRepository()).append(
        "*",
        event_type,
        {
            "signal_id": signal_id,
            "symbol": normalized.get("symbol") or row.get("symbol"),
            "status": normalized.get("status") or row.get("status"),
            "highest_target_hit": int(
                normalized.get("highest_target_hit") or row.get("highest_target_hit") or 0
            ),
            "updated_at": normalized.get("updated_at") or row.get("updated_at"),
            "source_event": str(source_event or "signal.updated"),
        },
        entity_type="signal",
        entity_id=signal_id,
    )
    return normalized
