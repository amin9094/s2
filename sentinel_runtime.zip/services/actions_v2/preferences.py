from __future__ import annotations

from typing import Any

from core.db import with_db
from modules.portfolio import remove_watchlist_symbol, set_watchlist_alerts, toggle_watchlist_symbol, watchlist_for_user

from repositories.v2.common import utc_iso
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action


@action("watchlist_toggle")
def watchlist_toggle(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    if not symbol:
        raise ValueError("INVALID_SYMBOL")
    added, item = with_db(lambda db: toggle_watchlist_symbol(db, ctx.user_id, symbol))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    # Project the same list into row-level preferences so every Mini App read
    # and every Telegram handler sees one logical watchlist.
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return {"added": added, "item": item, "items": items}


@action("watchlist_remove")
def watchlist_remove(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    removed = with_db(lambda db: remove_watchlist_symbol(db, ctx.user_id, symbol))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return {"removed": removed, "items": items}


@action("watchlist_alerts")
def watchlist_alerts(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    updated = with_db(lambda db: set_watchlist_alerts(db, ctx.user_id, symbol, bool(ctx.payload.get("enabled", True))))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return updated


@action("notification_preferences_update")
def notification_preferences_update(ctx: ActionContext) -> dict[str, Any]:
    return ctx.preferences.patch(ctx.user_id, "user_notification_preferences", ctx.payload)


@action("calendar_preferences_update")
def calendar_preferences_update(ctx: ActionContext) -> dict[str, Any]:
    return ctx.preferences.patch(ctx.user_id, "economic_calendar_preferences", ctx.payload)


@action("onboarding_update")
def onboarding_update(ctx: ActionContext) -> dict[str, Any]:
    """Persist first-run setup and create the user's default trading account.

    Mini App setup is an idempotent one-time mutation.  Earlier versions only
    patched the answers and never stored ``completed=True`` on the normalized
    preference row, so the onboarding modal reopened on every launch.
    """
    payload = dict(ctx.payload or {})
    experience = str(payload.get("experience") or "").strip().lower()
    goal = str(payload.get("goal") or "").strip().lower()
    market = str(payload.get("market") or "both").strip().lower()
    tolerance = str(payload.get("risk_tolerance") or "balanced").strip().lower()
    if experience not in {"beginner", "intermediate", "advanced", "professional"}:
        raise ValueError("INVALID_EXPERIENCE")
    if goal not in {"education", "signals", "prop", "journal", "growth", "income"}:
        raise ValueError("INVALID_GOAL")
    if market not in {"forex", "crypto", "both"}:
        raise ValueError("INVALID_MARKET")
    if tolerance not in {"conservative", "balanced", "aggressive"}:
        raise ValueError("INVALID_RISK_TOLERANCE")

    balance = float(payload.get("balance") or payload.get("account_size") or 0)
    equity = float(payload.get("equity") or balance)
    if balance <= 0 or equity <= 0:
        raise ValueError("ACCOUNT_BALANCE_REQUIRED")
    account_name = str(payload.get("account_name") or "حساب 1").strip()[:80] or "حساب 1"
    professional_raw = payload.get("professional")
    professional = (
        professional_raw is True
        or str(professional_raw or "").strip().lower() in {"1", "true", "yes", "professional", "pro"}
        or experience == "professional"
    )
    now = utc_iso()
    previous = ctx.preferences.get(ctx.user_id, "miniapp_onboarding", {})
    previous = previous if isinstance(previous, dict) else {}
    values = {
        "experience": experience,
        "professional": professional,
        "market": market,
        "account_name": account_name,
        "account_size": balance,
        "balance": balance,
        "equity": equity,
        "risk_tolerance": tolerance,
        "goal": goal,
        "completed": True,
        "completed_at": previous.get("completed_at") or now,
        "setup_version": 2,
        "updated_at": now,
    }
    data = ctx.preferences.patch(ctx.user_id, "miniapp_onboarding", values)

    plan = {
        "conservative": (0.5, 2.0, 3.0),
        "balanced": (1.0, 3.0, 5.0),
        "aggressive": (1.5, 4.0, 6.0),
    }.get(tolerance, (1.0, 3.0, 5.0))
    account = ctx.accounts.get(ctx.user_id)
    account_values: dict[str, Any] = {
        "name": account_name,
        "type": "personal",
        "phase": "personal",
        "currency": str(payload.get("currency") or "USD").upper()[:10],
        "balance": balance,
        "equity": equity,
        "starting_balance": float(account.get("starting_balance") or balance) if account else balance,
        "is_default": True,
        "default_risk_percent": plan[0],
        "max_daily_risk_percent": plan[1],
        "max_open_risk_percent": plan[2],
        "data_source": "manual",
        "data_confidence": 0.9,
        "data_observed_at": now,
    }
    account = ctx.accounts.upsert(ctx.user_id, account_values, account_id=account.get("id") if account else None)
    ctx.accounts.record_equity(
        ctx.user_id,
        account["id"],
        balance=balance,
        equity=equity,
        source="manual",
        confidence=0.9,
        observed_at=now,
        payload={"source": "miniapp_onboarding", "setup_version": 2, "request_id": ctx.request_id},
    )
    account = ctx.accounts.get(ctx.user_id, account["id"]) or account
    return {"onboarding": data, "account": account, "completed": True}


@action("language_update")
def language_update(ctx: ActionContext) -> dict[str, Any]:
    language = str(ctx.payload.get("language") or "fa").lower()
    if language not in {"fa", "en"}:
        raise ValueError("INVALID_LANGUAGE")
    profile = ctx.preferences.patch(ctx.user_id, "user_profiles", {"language": language, "updated_at": utc_iso()})
    return {"language": language, "profile": profile}


@action("rules_accept")
def rules_accept(ctx: ActionContext) -> dict[str, Any]:
    version = int(ctx.payload.get("version") or 0)
    content_hash = str(ctx.payload.get("content_hash") or "")
    language = str(ctx.payload.get("language") or "fa")
    if version <= 0 or not content_hash:
        raise ValueError("RULES_NOT_PUBLISHED")
    record = {
        "version": version,
        "content_hash": content_hash,
        "language": language,
        "accepted_at": utc_iso(),
        "source": "telegram_miniapp",
    }
    values = ctx.preferences.get(ctx.user_id, "rules_acceptances", {})
    if not isinstance(values, dict):
        values = {}
    values[language] = record
    ctx.preferences.set(ctx.user_id, "rules_acceptances", values)
    return record
