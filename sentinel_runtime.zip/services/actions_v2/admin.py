from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, Callable

from core.db import read_db_sections, with_db
from core.utils import parse_dt, utc_iso
from modules.action_inbox import action_inbox_snapshot
from modules.admin_access import (
    PERMISSION_ADMIN_SHIFTS,
    PERMISSION_AUTOMATIONS,
    PERMISSION_CAMPAIGNS,
    PERMISSION_DISCOUNTS,
    PERMISSION_INCIDENTS,
    PERMISSION_MISSION_CONTROL,
    PERMISSION_RUNTIME_SAFETY,
    PERMISSION_SYSTEM_CONTROL,
    PERMISSION_TICKETS,
    PERMISSION_TICKETS_REPLY,
    PERMISSION_TICKETS_ASSIGN,
    PERMISSION_TICKETS_STATUS_MANAGE,
    PERMISSION_TICKETS_PRIORITY_MANAGE,
    PERMISSION_TICKET_INTERNAL_NOTES,
    PERMISSION_SIGNALS,
    PERMISSION_SIGNAL_PUBLISH_NOW,
    PERMISSION_SIGNAL_SCHEDULE,
    PERMISSION_SIGNAL_BOARD_MANAGE,
    PERMISSION_SIGNAL_STATUS_MANAGE,
    PERMISSION_USER_BAN_MANAGE,
    PERMISSION_ANNOUNCEMENT_PUBLISH,
    PERMISSION_MAINTENANCE_MODE_MANAGE,
    PERMISSION_SIGNAL_EDIT,
    PERMISSION_SIGNAL_RESULTS,
    PERMISSION_SIGNAL_DELETE,
    PERMISSION_USERS,
    PERMISSION_ADMIN_MANAGEMENT,
    PERMISSION_ANNOUNCEMENTS,
    PERMISSION_FEATURE_MANAGEMENT,
    PERMISSION_OPERATIONS_GOVERNANCE,
    PERMISSION_TWO_STEP_APPROVALS,
    ALL_PERMISSIONS,
    OWNER_ONLY_PERMISSIONS,
    ADMIN_ROLE_PRESETS,
    apply_admin_role_preset,
    remove_delegated_admin,
    set_permissions,
    upsert_delegated_admin,
)
from modules.automation_outbox import retry_automation_message
from modules.advanced_features import reset_signal_result, set_user_ban, unban_user
from modules.management_suite import delete_signal_permanently, edit_signal, set_signal_lifecycle
from modules.channel_management import (
    cancel_scheduled_signal, edit_scheduled_signal, retry_scheduled_signal, schedule_signal,
)
from modules.signal import normalize_signal_price, normalize_signal_risk, normalize_signal_side, normalize_signal_symbol, validate_signal_levels
from modules.signal_engine import enrich_signal_payload, normalize_entries
from modules.signal_safety import create_signal_approval, evaluate_signal_safety
from modules.signal_team_rules import update_team_rules
from modules.ai_action_firewall import is_human_confirmation, validate_permissions_for_ai
from modules.signal_portal import (
    close_signal_cycle, rename_signal_cycle, rollover_signal_cycle, start_signal_cycle,
)
from modules.campaign_studio import (
    create_marketing_campaign,
    schedule_campaign,
    set_campaign_delivery,
    set_campaign_status,
)
from modules.sales_growth import create_public_discount
from modules.experiment_lab import create_experiment, set_experiment_status
from modules.incident_center import update_incident_status
from modules.mission_control import mission_control_snapshot
from modules.operations_handoff import create_shift_handoff, update_shift_handoff
from modules.runtime_safety import set_runtime_mode
from config import SETTINGS, is_primary_admin
from modules.admin_control_center import (
    FIELD_BY_KEY as CONTROL_FIELDS, MODULE_BY_KEY as CONTROL_MODULES,
    capability_status, module_state as control_module_state, normalize_control_value,
    reset_module as reset_control_module, set_control_value,
)
from modules.operations_governance import (
    apply_governance_request, approve_governance_request, create_governance_request,
    governance_control_risk, governance_request, governance_reset_risk,
    reject_governance_request, retry_governance_request,
)
from modules.admin_access import has_permission
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.unified_support_service import (
    admin_add_ticket_note, admin_assign_ticket, admin_reply_ticket,
    admin_ticket_status, admin_update_ticket_priority,
)


def _execute(ctx: ActionContext, command: str, operation: Callable[[dict[str, Any]], dict[str, Any]]) -> dict[str, Any]:
    """Execute a compatibility-domain admin mutation synchronously and audit it.

    The earlier implementation only queued commands and returned ``accepted``
    without a consumer. This boundary now commits the requested mutation before
    responding, while the normalized command row records completion/failure.
    """
    audit = ctx.admin_commands.create(
        ctx.user_id,
        command,
        {"input": dict(ctx.payload), "transport": dict(ctx.transport)},
    )
    try:
        result = with_db(operation)
    except Exception as exc:
        ctx.admin_commands.update(audit["id"], status="failed", result={"error": exc.__class__.__name__, "detail": str(exc)[:500]})
        raise
    ctx.admin_commands.update(audit["id"], status="completed", result=result)
    return {"command_id": audit["id"], "status": "completed", "result": result}


def _is_ai_transport(ctx: ActionContext) -> bool:
    transport = ctx.transport or {}
    source = str(transport.get("source") or "")
    return bool(transport.get("ai_origin")) or source.startswith("gemini") or source.startswith("human_approved_gemini")


def _require_human_confirmation(ctx: ActionContext) -> None:
    if not is_human_confirmation(ctx.transport):
        raise PermissionError("HUMAN_CONFIRMATION_REQUIRED")


def _validate_admin_permissions_for_source(ctx: ActionContext, permissions: list[Any]) -> list[str]:
    values = [str(value) for value in permissions]
    if _is_ai_transport(ctx):
        return validate_permissions_for_ai(values)
    invalid = [value for value in values if value not in ALL_PERMISSIONS]
    if invalid:
        raise ValueError("INVALID_ADMIN_PERMISSIONS")
    if any(value in OWNER_ONLY_PERMISSIONS for value in values):
        raise PermissionError("OWNER_ONLY_PERMISSION_NOT_ASSIGNABLE")
    return list(dict.fromkeys(values))


def _sync_signal_projection() -> None:
    """Keep Telegram's canonical signal records and Mini App SQL projection aligned."""
    from services.unified_signal_service import sync_legacy_signals_to_normalized

    sync_legacy_signals_to_normalized(include_archive=True)


_USER_FEATURE_MODULE_KEYS = frozenset({
    "signals", "portal", "watchlists", "journal", "risk", "prices", "crypto", "stocks",
    "energy", "calendar", "news", "edu", "faq", "support", "alerts", "missions",
    "contests", "league", "rewards", "referrals", "privacy", "paper_trading",
    "copilot", "risk_coach", "prop_guardian", "market_v2", "performance", "miniapp_next",
})


def _require_request_permission(db: dict[str, Any], user_id: str, row: dict[str, Any], *, approval: bool = False) -> None:
    required = str(row.get("required_permission") or PERMISSION_SYSTEM_CONTROL)
    if not has_permission(db, user_id, PERMISSION_OPERATIONS_GOVERNANCE) or not has_permission(db, user_id, required):
        raise PermissionError("GOVERNANCE_PERMISSION_REQUIRED")
    if approval and str(row.get("risk_level") or "") == "critical" and not has_permission(db, user_id, PERMISSION_TWO_STEP_APPROVALS):
        raise PermissionError("TWO_STEP_APPROVAL_REQUIRED")


@action("control_change", admin_only=True, permission=PERMISSION_SYSTEM_CONTROL)
def control_change_action(ctx: ActionContext) -> dict[str, Any]:
    module_key = str(ctx.payload.get("module") or "").strip()
    field_key = str(ctx.payload.get("field") or "").strip()
    if module_key not in CONTROL_MODULES or field_key not in CONTROL_FIELDS.get(module_key, {}):
        raise ValueError("INVALID_CONTROL_FIELD")
    if capability_status(module_key, field_key) == "planned":
        raise ValueError("CONTROL_NOT_OPERATIONAL")
    if module_key == "signals" and field_key == "owner_approval" and not is_primary_admin(ctx.user_id):
        raise PermissionError("OWNER_REQUIRED")

    snapshot = read_db_sections(("enterprise_control", "delegated_admins", "admin_shifts", "operations_governance"))
    if field_key == "enabled" and module_key in _USER_FEATURE_MODULE_KEYS and not has_permission(snapshot, ctx.user_id, PERMISSION_FEATURE_MANAGEMENT):
        raise PermissionError("FEATURE_MANAGEMENT_REQUIRED")
    field = CONTROL_FIELDS[module_key][field_key]
    old = control_module_state(snapshot, module_key).get(field_key, field.default)
    normalized = normalize_control_value(module_key, field_key, ctx.payload.get("value"))
    risk = governance_control_risk(module_key, field_key, old, normalized)
    if risk:
        return _execute(ctx, "control_change", lambda db: {
            "status": "review_required",
            "request": create_governance_request(
                db, action="control_change", payload={"module": module_key, "field": field_key, "value": normalized},
                requested_by=ctx.user_id, risk_level=risk,
                title=f"Mini App control change: {module_key}.{field_key}",
                description=f"Requested change from {old!r} to {normalized!r}",
                target_type="control_field", target_id=f"{module_key}.{field_key}",
                source="miniapp_admin", dedupe_key=f"control-change:{module_key}:{field_key}:{normalized}",
            ),
        })
    return _execute(ctx, "control_change", lambda db: {
        "status": "applied", "module": module_key, "field": field_key,
        "old": (result := set_control_value(db, module_key, field_key, normalized, ctx.user_id))[0],
        "new": result[1],
    })


@action("control_reset", admin_only=True, permission=PERMISSION_SYSTEM_CONTROL)
def control_reset_action(ctx: ActionContext) -> dict[str, Any]:
    module_key = str(ctx.payload.get("module") or "").strip()
    if module_key not in CONTROL_MODULES:
        raise ValueError("INVALID_CONTROL_MODULE")
    if module_key == "signals" and not is_primary_admin(ctx.user_id):
        raise PermissionError("OWNER_REQUIRED")
    snapshot = read_db_sections(("enterprise_control", "delegated_admins", "admin_shifts", "operations_governance"))
    if module_key in _USER_FEATURE_MODULE_KEYS and not has_permission(snapshot, ctx.user_id, PERMISSION_FEATURE_MANAGEMENT):
        raise PermissionError("FEATURE_MANAGEMENT_REQUIRED")
    risk = governance_reset_risk(module_key)
    if risk:
        return _execute(ctx, "control_reset", lambda db: {
            "status": "review_required",
            "request": create_governance_request(
                db, action="control_reset", payload={"module": module_key}, requested_by=ctx.user_id,
                risk_level=risk, title=f"Mini App module reset: {module_key}",
                description="Reset module to canonical defaults", target_type="control_module", target_id=module_key,
                source="miniapp_admin", dedupe_key=f"control-reset:{module_key}",
            ),
        })
    return _execute(ctx, "control_reset", lambda db: {"status": "applied", "module": module_key, "state": reset_control_module(db, module_key, ctx.user_id)})


@action("control_preset", admin_only=True, permission=PERMISSION_SYSTEM_CONTROL)
def control_preset_action(ctx: ActionContext) -> dict[str, Any]:
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("OWNER_REQUIRED")
    preset = str(ctx.payload.get("preset") or "").strip().lower()
    if preset not in {"default", "full", "safe"}:
        raise ValueError("INVALID_CONTROL_PRESET")
    return _execute(ctx, "control_preset", lambda db: {
        "status": "review_required",
        "request": create_governance_request(
            db, action="control_preset", payload={"preset": preset}, requested_by=ctx.user_id,
            risk_level="critical", title=f"Mini App global preset: {preset}",
            description="Global module preset requires governance approval", target_type="control_center", target_id="all",
            source="miniapp_admin", dedupe_key=f"control-preset:{preset}",
        ),
    })


@action("governance_request_approve", admin_only=True, permission=PERMISSION_OPERATIONS_GOVERNANCE)
def governance_request_approve_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human_confirmation(ctx)
    request_id = str(ctx.payload.get("request_id") or "").strip()
    if not request_id:
        raise ValueError("REQUEST_ID_REQUIRED")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = governance_request(db, request_id)
        if not row:
            raise ValueError("REQUEST_NOT_FOUND")
        _require_request_permission(db, ctx.user_id, row, approval=True)
        return approve_governance_request(db, request_id, ctx.user_id)
    return _execute(ctx, "governance_request_approve", mutate)


@action("governance_request_reject", admin_only=True, permission=PERMISSION_OPERATIONS_GOVERNANCE)
def governance_request_reject_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human_confirmation(ctx)
    request_id = str(ctx.payload.get("request_id") or "").strip()
    reason = str(ctx.payload.get("reason") or "رد از مینی‌اپ").strip()
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = governance_request(db, request_id)
        if not row:
            raise ValueError("REQUEST_NOT_FOUND")
        _require_request_permission(db, ctx.user_id, row)
        return reject_governance_request(db, request_id, ctx.user_id, reason)
    return _execute(ctx, "governance_request_reject", mutate)


@action("governance_request_apply", admin_only=True, permission=PERMISSION_OPERATIONS_GOVERNANCE)
def governance_request_apply_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human_confirmation(ctx)
    request_id = str(ctx.payload.get("request_id") or "").strip()
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = governance_request(db, request_id)
        if not row:
            raise ValueError("REQUEST_NOT_FOUND")
        _require_request_permission(db, ctx.user_id, row)
        return apply_governance_request(db, request_id, ctx.user_id)
    return _execute(ctx, "governance_request_apply", mutate)


@action("governance_request_retry", admin_only=True, permission=PERMISSION_OPERATIONS_GOVERNANCE)
def governance_request_retry_action(ctx: ActionContext) -> dict[str, Any]:
    request_id = str(ctx.payload.get("request_id") or "").strip()
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = governance_request(db, request_id)
        if not row:
            raise ValueError("REQUEST_NOT_FOUND")
        _require_request_permission(db, ctx.user_id, row)
        return retry_governance_request(db, request_id, ctx.user_id)
    return _execute(ctx, "governance_request_retry", mutate)


@action("admin_user_ban", admin_only=True, permission=PERMISSION_USER_BAN_MANAGE)
def admin_user_ban(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    if not user_id:
        raise ValueError("USER_ID_REQUIRED")
    days_value = ctx.payload.get("days")
    days = None if days_value in (None, "", 0, "0") else max(1, int(days_value))
    return _execute(
        ctx, "admin_user_ban",
        lambda db: set_user_ban(
            db, user_id, days=days,
            reason=str(ctx.payload.get("reason") or "مسدودسازی توسط ادمین مینی‌اپ"),
            admin_id=ctx.user_id,
        ),
    )


@action("admin_user_unban", admin_only=True, permission=PERMISSION_USER_BAN_MANAGE)
def admin_user_unban(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    if not user_id:
        raise ValueError("USER_ID_REQUIRED")
    return _execute(ctx, "admin_user_unban", lambda db: {"user_id": str(user_id), "unbanned": unban_user(db, user_id)})


@action("delegated_admin_upsert", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_upsert_action(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    permissions = ctx.payload.get("permissions")
    if not user_id or not isinstance(permissions, list):
        raise ValueError("ADMIN_ID_AND_PERMISSIONS_REQUIRED")
    permissions = _validate_admin_permissions_for_source(ctx, permissions)
    return _execute(
        ctx, "delegated_admin_upsert",
        lambda db: upsert_delegated_admin(db, user_id, permissions, ctx.user_id),
    )


@action("delegated_admin_permissions_set", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_permissions_set(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    permissions = ctx.payload.get("permissions")
    if not user_id or not isinstance(permissions, list):
        raise ValueError("ADMIN_ID_AND_PERMISSIONS_REQUIRED")
    permissions = _validate_admin_permissions_for_source(ctx, permissions)
    return _execute(ctx, "delegated_admin_permissions_set", lambda db: set_permissions(db, user_id, permissions, ctx.user_id))


@action("delegated_admin_role_preset", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_role_preset_action(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    preset = str(ctx.payload.get("preset") or "").strip().lower()
    if not user_id or preset not in ADMIN_ROLE_PRESETS:
        raise ValueError("ADMIN_ID_AND_ROLE_PRESET_REQUIRED")
    return _execute(
        ctx,
        "delegated_admin_role_preset",
        lambda db: apply_admin_role_preset(db, user_id, preset, ctx.user_id),
    )


@action("delegated_admin_remove", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_remove_action(ctx: ActionContext) -> dict[str, Any]:
    user_id = ctx.payload.get("user_id")
    if not user_id:
        raise ValueError("ADMIN_ID_REQUIRED")
    return _execute(
        ctx, "delegated_admin_remove",
        lambda db: {"user_id": str(user_id), "removed": remove_delegated_admin(db, user_id)},
    )


@action("signal_edit", admin_only=True, permission=PERMISSION_SIGNAL_EDIT)
def signal_edit_action(ctx: ActionContext) -> dict[str, Any]:
    signal_id = ctx.payload.get("signal_id")
    field = str(ctx.payload.get("field") or "").strip()
    if not signal_id or not field or ctx.payload.get("value") is None:
        raise ValueError("SIGNAL_ID_FIELD_VALUE_REQUIRED")
    result = _execute(
        ctx, "signal_edit",
        lambda db: edit_signal(db, signal_id, ctx.user_id, field, ctx.payload.get("value")),
    )
    _sync_signal_projection()
    return result


@action("signal_result_set", admin_only=True, permission=PERMISSION_SIGNAL_STATUS_MANAGE)
def signal_result_set_action(ctx: ActionContext) -> dict[str, Any]:
    signal_id = ctx.payload.get("signal_id")
    result_value = str(ctx.payload.get("result") or "").strip().lower()
    if not signal_id or not result_value:
        raise ValueError("SIGNAL_ID_RESULT_REQUIRED")
    result = _execute(
        ctx, "signal_result_set",
        lambda db: set_signal_lifecycle(db, signal_id, "tp1" if result_value == "target" else result_value, ctx.user_id),
    )
    _sync_signal_projection()
    return result


@action("signal_result_reset", admin_only=True, permission=PERMISSION_SIGNAL_STATUS_MANAGE)
def signal_result_reset_action(ctx: ActionContext) -> dict[str, Any]:
    signal_id = ctx.payload.get("signal_id")
    if not signal_id:
        raise ValueError("SIGNAL_ID_REQUIRED")
    result = _execute(
        ctx, "signal_result_reset",
        lambda db: reset_signal_result(db, signal_id, ctx.user_id),
    )
    _sync_signal_projection()
    return result


@action("signal_delete", admin_only=True, permission=PERMISSION_SIGNAL_DELETE)
def signal_delete_action(ctx: ActionContext) -> dict[str, Any]:
    signal_id = ctx.payload.get("signal_id")
    if not signal_id:
        raise ValueError("SIGNAL_ID_REQUIRED")
    result = _execute(
        ctx, "signal_delete",
        lambda db: delete_signal_permanently(db, signal_id, ctx.user_id),
    )
    _sync_signal_projection()
    return result


@action("runtime_mode_update", admin_only=True, permission=PERMISSION_MAINTENANCE_MODE_MANAGE)
def runtime_mode_update(ctx: ActionContext) -> dict[str, Any]:
    requested = str(ctx.payload.get("mode") or "").strip().lower()
    if requested not in {"normal", "safe", "maintenance", "read_only", "production", "staging"}:
        raise ValueError("INVALID_RUNTIME_MODE")

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        if requested in {"normal", "production"}:
            return set_runtime_mode(db, mode="production", disaster_mode=False, read_only=False, reason=str(ctx.payload.get("reason") or ""), actor_id=ctx.user_id)
        if requested == "staging":
            return set_runtime_mode(db, mode="staging", disaster_mode=False, read_only=False, reason=str(ctx.payload.get("reason") or ""), actor_id=ctx.user_id)
        if requested == "safe":
            return set_runtime_mode(db, mode="production", disaster_mode=False, read_only=True, reason=str(ctx.payload.get("reason") or "safe mode"), actor_id=ctx.user_id)
        if requested == "maintenance":
            return set_runtime_mode(db, mode="staging", disaster_mode=True, read_only=True, reason=str(ctx.payload.get("reason") or "maintenance"), actor_id=ctx.user_id)
        return set_runtime_mode(db, read_only=True, reason=str(ctx.payload.get("reason") or "read only"), actor_id=ctx.user_id)

    return _execute(ctx, "runtime_mode_update", mutate)


@action("miniapp_runtime_toggle", admin_only=True, permission=PERMISSION_MAINTENANCE_MODE_MANAGE)
def miniapp_runtime_toggle(ctx: ActionContext) -> dict[str, Any]:
    from modules.miniapp_runtime import set_miniapp_enabled

    enabled = bool(ctx.payload.get("enabled", True))
    reason = str(ctx.payload.get("reason") or "")
    return _execute(
        ctx,
        "miniapp_runtime_toggle",
        lambda db: set_miniapp_enabled(db, enabled, actor_id=ctx.user_id, reason=reason),
    )


@action("integration_reconcile", admin_only=True, permission=PERMISSION_SYSTEM_CONTROL)
def integration_reconcile(ctx: ActionContext) -> dict[str, Any]:
    from services.integration_health_service import reconcile_shared_state

    return reconcile_shared_state(ctx.user_id)


@action("mission_control_refresh", admin_only=True, permission=PERMISSION_MISSION_CONTROL, mutation=False, idempotency_required=False)
def mission_control_refresh(ctx: ActionContext) -> dict[str, Any]:
    snapshot = read_db_sections(("mission_control", "operations", "incidents", "provider_health", "admin_shifts"))
    return {"snapshot": mission_control_snapshot(snapshot), "refreshed": True}


@action("action_inbox_refresh", admin_only=True, permission=PERMISSION_MISSION_CONTROL, mutation=False, idempotency_required=False)
def action_inbox_refresh(ctx: ActionContext) -> dict[str, Any]:
    snapshot = read_db_sections(("action_inbox", "operations", "incidents", "automation_outbox", "support_tickets"))
    return {"snapshot": action_inbox_snapshot(snapshot), "refreshed": True}


@action("incident_status_update", admin_only=True, permission=PERMISSION_INCIDENTS)
def incident_status_update(ctx: ActionContext) -> dict[str, Any]:
    incident_id = ctx.payload.get("incident_id")
    status = str(ctx.payload.get("status") or "").strip().lower()
    if not incident_id or status not in {"open", "acknowledged", "investigating", "resolved"}:
        raise ValueError("INCIDENT_AND_STATUS_REQUIRED")
    return _execute(ctx, "incident_status_update", lambda db: update_incident_status(db, incident_id, status, ctx.user_id))


@action("campaign_status_update", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def campaign_status_update(ctx: ActionContext) -> dict[str, Any]:
    campaign_id = ctx.payload.get("campaign_id")
    status = str(ctx.payload.get("status") or "").strip().lower()
    if not campaign_id or not status:
        raise ValueError("CAMPAIGN_AND_STATUS_REQUIRED")
    return _execute(ctx, "campaign_status_update", lambda db: set_campaign_status(db, campaign_id, status, actor_id=ctx.user_id))


@action("campaign_create", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def campaign_create(ctx: ActionContext) -> dict[str, Any]:
    required = ("name", "category", "audience", "message", "delivery")
    if any(not str(ctx.payload.get(key) or "").strip() for key in required):
        raise ValueError("CAMPAIGN_FIELDS_REQUIRED")
    return _execute(
        ctx,
        "campaign_create",
        lambda db: create_marketing_campaign(
            db,
            name=str(ctx.payload["name"]),
            category=str(ctx.payload["category"]),
            audience=str(ctx.payload["audience"]),
            message=str(ctx.payload["message"]),
            delivery=str(ctx.payload["delivery"]),
            created_by=ctx.user_id,
            objective=str(ctx.payload.get("objective") or ""),
            tracking=ctx.payload.get("tracking") if isinstance(ctx.payload.get("tracking"), dict) else {},
        ),
    )


@action("public_discount_create", admin_only=True, permission=PERMISSION_DISCOUNTS)
def public_discount_create(ctx: ActionContext) -> dict[str, Any]:
    code = str(ctx.payload.get("code") or "").strip().upper()
    percent = int(ctx.payload.get("percent") or 0)
    days = int(ctx.payload.get("days") or 0)
    max_uses = int(ctx.payload.get("max_uses") or 0)
    one_per_user = bool(ctx.payload.get("one_per_user", True))
    if not 4 <= len(code) <= 24:
        raise ValueError("DISCOUNT_CODE_INVALID")
    if not 1 <= percent <= 100:
        raise ValueError("DISCOUNT_PERCENT_INVALID")
    if not 1 <= days <= 365:
        raise ValueError("DISCOUNT_DURATION_INVALID")
    if not 0 <= max_uses <= 1_000_000:
        raise ValueError("DISCOUNT_MAX_USES_INVALID")
    return _execute(
        ctx,
        "public_discount_create",
        lambda db: create_public_discount(
            db,
            code=code,
            percent=percent,
            starts_at=utc_iso(),
            ends_at=utc_iso(datetime.now(UTC) + timedelta(days=days)),
            max_uses=max_uses,
            one_per_user=one_per_user,
            created_by=ctx.user_id,
        ),
    )


@action("campaign_delivery_update", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def campaign_delivery_update(ctx: ActionContext) -> dict[str, Any]:
    campaign_id = str(ctx.payload.get("campaign_id") or "")
    delivery = str(ctx.payload.get("delivery") or "")
    if not campaign_id or not delivery:
        raise ValueError("CAMPAIGN_AND_DELIVERY_REQUIRED")
    return _execute(
        ctx,
        "campaign_delivery_update",
        lambda db: set_campaign_delivery(db, campaign_id, delivery, actor_id=ctx.user_id),
    )


@action("campaign_schedule", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def campaign_schedule_action(ctx: ActionContext) -> dict[str, Any]:
    campaign_id = str(ctx.payload.get("campaign_id") or "")
    scheduled_for = ctx.payload.get("scheduled_for")
    if not campaign_id or not scheduled_for:
        raise ValueError("CAMPAIGN_AND_SCHEDULE_REQUIRED")
    return _execute(
        ctx,
        "campaign_schedule",
        lambda db: schedule_campaign(
            db,
            campaign_id,
            scheduled_for,
            actor_id=ctx.user_id,
            priority=int(ctx.payload.get("priority") or 3),
        ),
    )


@action("signal_cycle_rollover", admin_only=True, permission=PERMISSION_SIGNAL_BOARD_MANAGE)
def signal_cycle_rollover(ctx: ActionContext) -> dict[str, Any]:
    name = str(ctx.payload.get("name") or ctx.payload.get("new_name") or "").strip()
    if len(name) < 2:
        raise ValueError("SIGNAL_CYCLE_NAME_REQUIRED")
    return _execute(
        ctx,
        "signal_cycle_rollover",
        lambda db: rollover_signal_cycle(db, ctx.user_id, new_name=name),
    )


@action("signal_cycle_close", admin_only=True, permission=PERMISSION_SIGNAL_BOARD_MANAGE)
def signal_cycle_close(ctx: ActionContext) -> dict[str, Any]:
    return _execute(ctx, "signal_cycle_close", lambda db: close_signal_cycle(db, ctx.user_id))


@action("signal_cycle_start", admin_only=True, permission=PERMISSION_SIGNAL_BOARD_MANAGE)
def signal_cycle_start(ctx: ActionContext) -> dict[str, Any]:
    name = str(ctx.payload.get("name") or "").strip()
    if len(name) < 2:
        raise ValueError("SIGNAL_CYCLE_NAME_REQUIRED")
    return _execute(ctx, "signal_cycle_start", lambda db: start_signal_cycle(db, ctx.user_id, name))


@action("signal_cycle_rename", admin_only=True, permission=PERMISSION_SIGNAL_BOARD_MANAGE)
def signal_cycle_rename(ctx: ActionContext) -> dict[str, Any]:
    cycle_id = ctx.payload.get("cycle_id")
    name = str(ctx.payload.get("name") or "").strip()
    if not cycle_id or len(name) < 2:
        raise ValueError("SIGNAL_CYCLE_ID_NAME_REQUIRED")
    return _execute(
        ctx,
        "signal_cycle_rename",
        lambda db: rename_signal_cycle(db, cycle_id, name, ctx.user_id),
    )


@action("ai_signal_draft_create", admin_only=True, permission=PERMISSION_SIGNAL_SCHEDULE)
def ai_signal_draft_create(ctx: ActionContext) -> dict[str, Any]:
    """Create a human-review-only signal draft; never publish from Gemini."""
    target = str(ctx.payload.get("target") or "public").lower()
    if target not in {"public", "private", "both"}:
        raise ValueError("INVALID_SIGNAL_TARGET")
    symbol = normalize_signal_symbol(str(ctx.payload.get("symbol") or ""))
    side = normalize_signal_side(str(ctx.payload.get("side") or ""))
    entries = normalize_entries(ctx.payload.get("entries") or ctx.payload.get("entry") or "")
    entry = normalize_signal_price(entries[0], "قیمت ورود")
    targets = [normalize_signal_price(value, f"هدف {index}") for index, value in enumerate(ctx.payload.get("targets") or [], start=1)]
    if not targets:
        raise ValueError("حداقل یک تارگت لازم است")
    stop = normalize_signal_price(str(ctx.payload.get("stop") or ctx.payload.get("stop_loss") or ""), "حد ضرر")
    risk = normalize_signal_risk(str(ctx.payload.get("risk") or ctx.payload.get("risk_percent") or "1"))
    for item in entries:
        validate_signal_levels(item, targets, stop, side)
    payload = enrich_signal_payload({
        "symbol": symbol, "side": side, "entries": entries, "entry": entry,
        "targets": targets, "stop": stop, "risk": risk,
        "market_category": str(ctx.payload.get("market_category") or ""),
        "timeframe": str(ctx.payload.get("timeframe") or "1H")[:20],
        "note": str(ctx.payload.get("note") or "")[:2000],
        "analysis": str(ctx.payload.get("analysis") or "")[:2000],
        "source": "gemini_ai_signal_draft",
    })
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        report = evaluate_signal_safety(db, payload)
        # A draft may be reviewed even when a team limit currently blocks it,
        # but the exact gate result is attached and publication re-checks it.
        row = create_signal_approval(
            db, payload=payload, target=target, requested_by=ctx.user_id,
            run_at=ctx.payload.get("scheduled_at"), source="gemini_ai_signal_draft",
            review_requirements=["entry", "stop", "targets"],
        )
        row["safety_report"] = report.as_dict()
        row["ai_draft"] = True
        return {"approval": row, "safety": report.as_dict(), "published": False}
    return _execute(ctx, "ai_signal_draft_create", mutate)


@action("signal_team_rules_update", admin_only=True, permission=PERMISSION_SIGNALS)
def signal_team_rules_update(ctx: ActionContext) -> dict[str, Any]:
    changes = {key: value for key, value in ctx.payload.items() if value is not None}
    return _execute(ctx, "signal_team_rules_update", lambda db: {"rules": update_team_rules(db, ctx.user_id, changes)})


@action("miniapp_signal_publish", admin_only=True, permission=PERMISSION_SIGNAL_PUBLISH_NOW)
def miniapp_signal_publish(ctx: ActionContext) -> dict[str, Any]:
    """Queue a validated human signal for the Telegram + Mini App pipeline."""
    if _is_ai_transport(ctx) and not (
        is_primary_admin(ctx.user_id) and SETTINGS.gemini_primary_admin_full_bot_access
    ):
        return ai_signal_draft_create(ctx)
    target = str(ctx.payload.get("target") or "public").lower()
    if target not in {"public", "private", "both"}:
        raise ValueError("INVALID_SIGNAL_TARGET")
    symbol = normalize_signal_symbol(str(ctx.payload.get("symbol") or ""))
    side = normalize_signal_side(str(ctx.payload.get("side") or ""))
    entries = normalize_entries(ctx.payload.get("entries") or ctx.payload.get("entry") or "")
    entry = normalize_signal_price(entries[0], "قیمت ورود")
    targets = [normalize_signal_price(value, f"هدف {index}") for index, value in enumerate(ctx.payload.get("targets") or [], start=1)]
    if not targets:
        raise ValueError("حداقل یک تارگت لازم است")
    stop = normalize_signal_price(str(ctx.payload.get("stop") or ctx.payload.get("stop_loss") or ""), "حد ضرر")
    risk = normalize_signal_risk(str(ctx.payload.get("risk") or ctx.payload.get("risk_percent") or "1"))
    for item in entries:
        validate_signal_levels(item, targets, stop, side)
    payload = enrich_signal_payload({
        "symbol": symbol, "side": side, "entries": entries, "entry": entry,
        "targets": targets, "stop": stop, "risk": risk,
        "market_category": str(ctx.payload.get("market_category") or ""),
        "timeframe": str(ctx.payload.get("timeframe") or "1H")[:20],
        "note": str(ctx.payload.get("note") or "")[:2000],
        "analysis": str(ctx.payload.get("analysis") or "")[:2000],
        "source": "gemini_primary_admin" if _is_ai_transport(ctx) else "miniapp_admin",
    })
    run_at = datetime.now(UTC) + timedelta(seconds=1)
    queued = with_db(lambda db: schedule_signal(db, payload=payload, target=target, run_at=run_at, admin_id=ctx.user_id))
    return {"queued": True, "queue_id": queued["id"], "run_at": queued["run_at"], "target": target, "payload": payload}


@action("signal_job_retry", admin_only=True, permission=PERMISSION_SIGNAL_SCHEDULE)
def signal_job_retry(ctx: ActionContext) -> dict[str, Any]:
    job_id = ctx.payload.get("job_id")
    if not job_id:
        raise ValueError("SIGNAL_JOB_REQUIRED")
    return _execute(ctx, "signal_job_retry", lambda db: retry_scheduled_signal(db, job_id, actor_id=ctx.user_id))


@action("signal_job_cancel", admin_only=True, permission=PERMISSION_SIGNAL_SCHEDULE)
def signal_job_cancel(ctx: ActionContext) -> dict[str, Any]:
    job_id = ctx.payload.get("job_id")
    if not job_id:
        raise ValueError("SIGNAL_JOB_REQUIRED")
    return _execute(
        ctx, "signal_job_cancel",
        lambda db: cancel_scheduled_signal(db, job_id, actor_id=ctx.user_id, reason=str(ctx.payload.get("reason") or "")),
    )


@action("signal_job_update", admin_only=True, permission=PERMISSION_SIGNAL_SCHEDULE)
def signal_job_update(ctx: ActionContext) -> dict[str, Any]:
    job_id = ctx.payload.get("job_id")
    if not job_id:
        raise ValueError("SIGNAL_JOB_REQUIRED")
    return _execute(
        ctx, "signal_job_update",
        lambda db: edit_scheduled_signal(
            db, job_id, actor_id=ctx.user_id, target=ctx.payload.get("target"),
            run_at=ctx.payload.get("run_at"),
            payload=ctx.payload.get("payload") if isinstance(ctx.payload.get("payload"), dict) else None,
        ),
    )


@action("miniapp_announcement_publish", admin_only=True, permission=PERMISSION_ANNOUNCEMENT_PUBLISH)
def miniapp_announcement_publish(ctx: ActionContext) -> dict[str, Any]:
    """Create and schedule a channel announcement through the durable campaign scheduler."""
    title = str(ctx.payload.get("title") or "").strip()
    message = str(ctx.payload.get("message") or "").strip()
    delivery = str(ctx.payload.get("delivery") or "public").lower()
    if len(title) < 3 or not message:
        raise ValueError("ANNOUNCEMENT_TITLE_MESSAGE_REQUIRED")
    if delivery not in {"public", "private"}:
        raise ValueError("INVALID_ANNOUNCEMENT_DELIVERY")
    scheduled_for = parse_dt(ctx.payload.get("scheduled_for")) or (datetime.now(UTC) + timedelta(seconds=45))
    if scheduled_for <= datetime.now(UTC):
        scheduled_for = datetime.now(UTC) + timedelta(seconds=5)
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        campaign = create_marketing_campaign(
            db, name=title[:100], category="announcement", audience="all",
            message=message[:3500], delivery=delivery, created_by=ctx.user_id,
            objective="Channel announcement from Mini App",
            tracking={"source": "miniapp_admin", "content_type": "announcement"},
        )
        scheduled = schedule_campaign(db, campaign["id"], scheduled_for, actor_id=ctx.user_id, priority=1)
        return {"campaign": campaign, "schedule": scheduled}
    return _execute(ctx, "miniapp_announcement_publish", mutate)


@action("automation_retry", admin_only=True, permission=PERMISSION_AUTOMATIONS)
def automation_retry(ctx: ActionContext) -> dict[str, Any]:
    message_id = str(ctx.payload.get("message_id") or "").strip()
    if not message_id:
        raise ValueError("AUTOMATION_MESSAGE_REQUIRED")
    return _execute(ctx, "automation_retry", lambda db: retry_automation_message(db, message_id, actor_id=ctx.user_id))


@action("ticket_admin_reply", admin_only=True, permission=PERMISSION_TICKETS_REPLY)
def ticket_admin_reply(ctx: ActionContext) -> dict[str, Any]:
    ticket_id = str(ctx.payload.get("ticket_id") or "")
    text = str(ctx.payload.get("text") or "").strip()
    attachment = ctx.payload.get("attachment") if isinstance(ctx.payload.get("attachment"), dict) else None
    if not ticket_id or (not text and not attachment):
        raise ValueError("TICKET_TEXT_OR_ATTACHMENT_REQUIRED")
    return admin_reply_ticket(ctx.user_id, ticket_id, text, attachment=attachment)


@action("ticket_admin_status_update", admin_only=True, permission=PERMISSION_TICKETS_STATUS_MANAGE)
def ticket_admin_status_update(ctx: ActionContext) -> dict[str, Any]:
    ticket_id = str(ctx.payload.get("ticket_id") or "")
    status = str(ctx.payload.get("status") or "").lower()
    if status not in {"open", "pending", "answered", "closed"}:
        raise ValueError("INVALID_TICKET_STATUS")
    return admin_ticket_status(ticket_id, status)


@action("ticket_admin_assign", admin_only=True, permission=PERMISSION_TICKETS_ASSIGN)
def ticket_admin_assign(ctx: ActionContext) -> dict[str, Any]:
    ticket_id = str(ctx.payload.get("ticket_id") or "")
    admin_id = ctx.payload.get("admin_id") or ctx.payload.get("assigned_admin_id")
    if not ticket_id or not admin_id:
        raise ValueError("TICKET_AND_ADMIN_REQUIRED")
    return admin_assign_ticket(ctx.user_id, ticket_id, admin_id)


@action("ticket_admin_priority_update", admin_only=True, permission=PERMISSION_TICKETS_PRIORITY_MANAGE)
def ticket_admin_priority_update(ctx: ActionContext) -> dict[str, Any]:
    ticket_id = str(ctx.payload.get("ticket_id") or "")
    priority = str(ctx.payload.get("priority") or "").strip().lower()
    if not ticket_id or priority not in {"low", "normal", "high", "urgent"}:
        raise ValueError("TICKET_AND_PRIORITY_REQUIRED")
    return admin_update_ticket_priority(ctx.user_id, ticket_id, priority)


@action("ticket_admin_internal_note", admin_only=True, permission=PERMISSION_TICKET_INTERNAL_NOTES)
def ticket_admin_internal_note(ctx: ActionContext) -> dict[str, Any]:
    ticket_id = str(ctx.payload.get("ticket_id") or "")
    text = str(ctx.payload.get("text") or "").strip()
    if not ticket_id or len(text) < 2:
        raise ValueError("TICKET_AND_NOTE_REQUIRED")
    return admin_add_ticket_note(ctx.user_id, ticket_id, text)


@action("shift_handoff_create", admin_only=True, permission=PERMISSION_ADMIN_SHIFTS)
def shift_handoff_create(ctx: ActionContext) -> dict[str, Any]:
    to_admin_id = ctx.payload.get("to_admin_id")
    summary = str(ctx.payload.get("summary") or "").strip()
    if not to_admin_id or len(summary) < 5:
        raise ValueError("HANDOFF_ADMIN_SUMMARY_REQUIRED")
    return _execute(
        ctx,
        "shift_handoff_create",
        lambda db: create_shift_handoff(
            db,
            from_admin_id=ctx.user_id,
            to_admin_id=to_admin_id,
            summary=summary,
            pending_items=ctx.payload.get("pending_items"),
            risks=ctx.payload.get("risks"),
            decisions=ctx.payload.get("decisions"),
            next_actions=ctx.payload.get("next_actions"),
            due_at=ctx.payload.get("due_at"),
        ),
    )


@action("shift_handoff_status_update", admin_only=True, permission=PERMISSION_ADMIN_SHIFTS)
def shift_handoff_status_update(ctx: ActionContext) -> dict[str, Any]:
    handoff_id = ctx.payload.get("handoff_id")
    status = str(ctx.payload.get("status") or "").strip().lower()
    if not handoff_id or not status:
        raise ValueError("HANDOFF_AND_STATUS_REQUIRED")
    return _execute(
        ctx,
        "shift_handoff_status_update",
        lambda db: update_shift_handoff(db, handoff_id, admin_id=ctx.user_id, status=status, note=str(ctx.payload.get("note") or "")),
    )


@action("experiment_create", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def experiment_create(ctx: ActionContext) -> dict[str, Any]:
    name = str(ctx.payload.get("name") or "").strip()
    if not name:
        raise ValueError("EXPERIMENT_NAME_REQUIRED")
    return _execute(
        ctx,
        "experiment_create",
        lambda db: create_experiment(
            db,
            name=name,
            hypothesis=str(ctx.payload.get("hypothesis") or "").strip(),
            variants=ctx.payload.get("variants"),
            primary_metric=str(ctx.payload.get("primary_metric") or "purchase"),
            created_by=ctx.user_id,
            holdout_percent=float(ctx.payload.get("holdout_percent") or 10),
            conversion_window_hours=int(ctx.payload.get("conversion_window_hours") or 168),
            min_sample_per_variant=int(ctx.payload.get("min_sample_per_variant") or 100),
            stop_loss_percent=float(ctx.payload.get("stop_loss_percent") or 25),
            starts_at=ctx.payload.get("starts_at"),
            ends_at=ctx.payload.get("ends_at"),
        ),
    )


@action("experiment_status_update", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def experiment_status_update(ctx: ActionContext) -> dict[str, Any]:
    experiment_id = ctx.payload.get("experiment_id")
    status = str(ctx.payload.get("status") or "").strip().lower()
    if not experiment_id or not status:
        raise ValueError("EXPERIMENT_AND_STATUS_REQUIRED")
    return _execute(ctx, "experiment_status_update", lambda db: set_experiment_status(db, experiment_id, status=status, changed_by=ctx.user_id))


@action("prop_template_create", admin_only=True, permission=PERMISSION_RUNTIME_SAFETY)
def prop_template_create(ctx: ActionContext) -> dict[str, Any]:
    provider = str(ctx.payload.get("provider") or "").strip()
    name = str(ctx.payload.get("name") or "").strip()
    rules = ctx.payload.get("rules") if isinstance(ctx.payload.get("rules"), dict) else {}
    if len(provider) < 2 or len(name) < 3:
        raise ValueError("PROP_TEMPLATE_NAME_REQUIRED")
    return ctx.prop_rules.create_template(
        provider=provider,
        name=name,
        rules=rules,
        version=int(ctx.payload.get("version") or 1),
        template_id=str(ctx.payload.get("template_id") or "") or None,
    )
