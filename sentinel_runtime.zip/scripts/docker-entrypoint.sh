#!/bin/sh
set -eu

cd /app

DB_FILE_VALUE="${DB_FILE:-data/sentinel.sqlite3}"
LOG_DIR_VALUE="${LOG_DIR:-logs}"
BACKUP_DIR_VALUE="${BACKUP_DIR:-data/backups}"
HEARTBEAT_FILE_VALUE="${HEARTBEAT_FILE:-data/heartbeat.json}"
PERSISTENCE_FILE_VALUE="${PERSISTENCE_FILE:-data/telegram-state.sqlite3}"
METRICS_FILE_VALUE="${METRICS_FILE:-data/metrics.json}"
PERSISTENT_DATA_DIR_VALUE="${PERSISTENT_DATA_DIR:-}"
SUPPORT_ATTACHMENT_DIR_VALUE="${SUPPORT_ATTACHMENT_STORAGE_DIR:-${PERSISTENT_DATA_DIR_VALUE:+$PERSISTENT_DATA_DIR_VALUE/support_attachments}}"
SIGNAL_TEMPLATE_DIR_VALUE="${SIGNAL_TEMPLATE_STORAGE_DIR:-${PERSISTENT_DATA_DIR_VALUE:+$PERSISTENT_DATA_DIR_VALUE/signal_templates}}"
if [ -n "${RECEIPT_STORAGE_DIR:-}" ]; then
    RECEIPT_DIR_VALUE="$RECEIPT_STORAGE_DIR"
elif [ -n "$PERSISTENT_DATA_DIR_VALUE" ]; then
    RECEIPT_DIR_VALUE="$PERSISTENT_DATA_DIR_VALUE/payment_receipts"
else
    RECEIPT_DIR_VALUE="data/payment_receipts"
fi

absolute_path() {
    case "$1" in /*) printf '%s\n' "$1" ;; *) printf '/app/%s\n' "$1" ;; esac
}
canonical_path() {
    readlink -m "$1"
}

DB_PATH="$(canonical_path "$(absolute_path "$DB_FILE_VALUE")")"
LOG_PATH="$(canonical_path "$(absolute_path "$LOG_DIR_VALUE")")"
BACKUP_PATH="$(canonical_path "$(absolute_path "$BACKUP_DIR_VALUE")")"
HEARTBEAT_PATH="$(canonical_path "$(absolute_path "$HEARTBEAT_FILE_VALUE")")"
PERSISTENCE_PATH="$(canonical_path "$(absolute_path "$PERSISTENCE_FILE_VALUE")")"
METRICS_PATH="$(canonical_path "$(absolute_path "$METRICS_FILE_VALUE")")"
RECEIPT_PATH="$(canonical_path "$(absolute_path "$RECEIPT_DIR_VALUE")")"
SUPPORT_ATTACHMENT_PATH="$(canonical_path "$(absolute_path "${SUPPORT_ATTACHMENT_DIR_VALUE:-data/support_attachments}")")"
SIGNAL_TEMPLATE_PATH="$(canonical_path "$(absolute_path "${SIGNAL_TEMPLATE_DIR_VALUE:-data/signal_templates}")")"

# Never recursively change ownership outside explicitly approved runtime roots.
# Operators may extend this list for a mounted volume, but cannot use / or /app.
ALLOWED_ROOTS="${SENTINEL_ALLOWED_STORAGE_ROOTS:-/app/data:/app/logs:/mnt/data:/data:/var/lib/sentinel}"
validate_directory() {
    candidate="$(canonical_path "$1")"
    case "$candidate" in /|/app|/usr|/etc|/var|/home|/root) echo "Unsafe storage directory: $candidate" >&2; exit 78 ;; esac
    old_ifs="$IFS"
    IFS=':'
    allowed=0
    for raw_root in $ALLOWED_ROOTS; do
        root="$(canonical_path "$raw_root")"
        case "$root" in /|/app|/usr|/etc|/var|/home|/root|'') continue ;; esac
        case "$candidate/" in "$root/"*) allowed=1; break ;; esac
    done
    IFS="$old_ifs"
    if [ "$allowed" -ne 1 ]; then
        echo "Storage directory is outside SENTINEL_ALLOWED_STORAGE_ROOTS: $candidate" >&2
        exit 78
    fi
}

DB_DIR="$(dirname "$DB_PATH")"
HEARTBEAT_DIR="$(dirname "$HEARTBEAT_PATH")"
PERSISTENCE_DIR="$(dirname "$PERSISTENCE_PATH")"
METRICS_DIR="$(dirname "$METRICS_PATH")"
for directory in "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"; do
    validate_directory "$directory"
done

mkdir -p "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"
for directory in "$DB_DIR" "$LOG_PATH" "$BACKUP_PATH" "$HEARTBEAT_DIR" "$PERSISTENCE_DIR" "$METRICS_DIR" "$RECEIPT_PATH" "$SUPPORT_ATTACHMENT_PATH" "$SIGNAL_TEMPLATE_PATH"; do
    chown sentinel:sentinel "$directory"
    chmod 0700 "$directory"
done

umask 077
exec gosu sentinel "$@"
