#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PIN=re.compile(r"^[A-Za-z0-9_.-]+(?:\[[A-Za-z0-9_,.-]+\])?==[^\s;\\]+(?:\s*;.*)?(?:\s+\\)?$")
HASH=re.compile(r"--hash=sha256:[0-9a-f]{64}")

def rows(path:Path)->list[str]:
 return [line.strip() for line in path.read_text(encoding='utf-8').splitlines() if line.strip() and not line.lstrip().startswith('#')]

def package_name(row:str)->str:
 value=row.split(';',1)[0].split('==',1)[0].split()[0].strip().lower().replace('_','-')
 return value.split('[',1)[0]

def logical_rows(path:Path)->list[str]:
 out=[]; current=''
 for raw in path.read_text(encoding='utf-8').splitlines():
  line=raw.strip()
  if not line or line.startswith('#'): continue
  current=(current+' '+line).strip()
  if current.endswith('\\'):
   current=current[:-1].strip(); continue
  out.append(current); current=''
 if current: out.append(current)
 return out

def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument('--require-hashes',action='store_true'); args=ap.parse_args()
 status=json.loads((ROOT/'DEPENDENCY_LOCK_STATUS.json').read_text(encoding='utf-8'))
 production=logical_rows(ROOT/'requirements.lock.txt')
 if not production: raise RuntimeError('requirements.lock.txt is empty')
 invalid=[line for line in production if '==' not in line.split(';',1)[0]]
 if invalid: raise RuntimeError(f'all production dependencies must use exact pins: {invalid[:3]}')
 direct=rows(ROOT/'requirements.txt')
 direct_names={package_name(x) for x in direct if not x.startswith(('-r ', '-c '))}
 locked_names={package_name(x) for x in production if not x.startswith(('-r ', '-c '))}
 if not direct_names.issubset(locked_names): raise RuntimeError('lock omits one or more direct requirements')
 require_hashes=args.require_hashes or bool(status.get('hashes_required'))
 if require_hashes:
  missing=[line for line in production if not HASH.search(line)]
  if missing: raise RuntimeError('production lock is not fully hash-pinned')
  if not status.get('complete_transitive_lock'): raise RuntimeError('dependency lock status is not complete')
 development=rows(ROOT/'requirements-dev.txt')
 if development[:1] != ['-r requirements.lock.txt']: raise RuntimeError('requirements-dev.txt must inherit the production lock')
 dev_lock_path = ROOT/'requirements-dev.lock.txt'
 if not dev_lock_path.is_file(): raise RuntimeError('requirements-dev.lock.txt is missing')
 dev_lock = logical_rows(dev_lock_path)
 if require_hashes:
  missing_dev=[line for line in dev_lock if not line.startswith(('-r ', '-c ')) and not HASH.search(line)]
  if missing_dev: raise RuntimeError('development lock is not fully hash-pinned')
 print(f"DEPENDENCY LOCK OK: locked={len(production)} dev_locked={len(dev_lock)} direct={len(direct)} complete={bool(status.get('complete_transitive_lock'))} hashes={require_hashes}")
 return 0
if __name__=='__main__': raise SystemExit(main())
