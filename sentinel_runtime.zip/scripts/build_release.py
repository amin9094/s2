#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import stat
import subprocess  # nosec B404 -- fixed internal release command only
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from quality_utils import source_fingerprint

ROOT = Path(__file__).resolve().parents[1]
FIXED_ZIP_TIME = (2026, 7, 22, 0, 0, 0)
EXCLUDED_DIRS = {
    ".git", ".pytest_cache", ".ruff_cache", ".mypy_cache", ".audit-cache", "__pycache__", ".venv", ".venv-test", "venv", "logs", "dist",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".sqlite", ".sqlite3", ".db", ".log", ".tmp"}
EXCLUDED_FILES = {".env", ".env.local", ".DS_Store", ".coverage"}
HISTORICAL_DOC_RE = re.compile(r"^(?:FINAL_AUDIT|IMPLEMENTATION_REPORT|RELEASE_NOTES)_V(.+)_FA\.md$")
HISTORICAL_MISC_PREFIXES = ("COVERAGE_REPORT_V", "QUALITY_PROOF_V")
HISTORICAL_ROOT_PREFIXES = ("RAILWAY_BUILD_FIX_", "RAILWAY_FEATURE_FIX_")
HISTORICAL_ROOT_FILES = {"ADMIN_PERMISSIONS_R27_FA.md", "SIGNAL_RR_POLICY_R26_FA.md", "SINGLE_SOURCE_STORAGE_V8.15.0_FA.md"}
RUNTIME_OUTER_ONLY_TESTS = {
    "tests/test_runtime_restore_bootstrap.py",
    "tests/test_railway_clean_bundle_build.py",
}


def _is_excluded_directory(name: str) -> bool:
    return name in EXCLUDED_DIRS or name.startswith(".venv")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def clean_tree() -> None:
    for path in sorted(ROOT.rglob("*"), reverse=True):
        if path.is_dir() and path.name in {"__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache"}:
            shutil.rmtree(path, ignore_errors=True)
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix in {".pyc", ".pyo", ".tmp"}:
            path.unlink(missing_ok=True)


def _is_current_release_document(path: Path) -> bool:
    if path.parent != ROOT:
        return True
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip() if (ROOT / "VERSION").is_file() else ""
    match = HISTORICAL_DOC_RE.match(path.name)
    if match:
        return match.group(1) == version
    if path.name.startswith(HISTORICAL_MISC_PREFIXES):
        return False
    if path.name.startswith(HISTORICAL_ROOT_PREFIXES) or path.name in HISTORICAL_ROOT_FILES:
        return False
    return True


def is_allowed(path: Path, *, outer: bool) -> bool:
    relative = path.relative_to(ROOT)
    if any(_is_excluded_directory(part) for part in relative.parts):
        return False
    if path.name in EXCLUDED_FILES or path.name.startswith(".coverage") or path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False
    if outer and not _is_current_release_document(path):
        return False
    posix = relative.as_posix()
    if posix.startswith("data/backups/") and path.name != ".gitkeep":
        return False
    if posix in {"data/heartbeat.json", "data/metrics.json", "data/telegram-state.sqlite3"}:
        return False
    if not outer and posix in {
        "sentinel_runtime.zip", "sentinel_runtime.zip.sha256", "RELEASE_MANIFEST.json", "SHA256SUMS.txt",
        "restore_runtime.py",
    }:
        return False
    return True


def runtime_files() -> list[Path]:
    roots = [
        "main.py", "bot.py", "config.py", "requirements.txt", "requirements.in", "requirements.lock.txt",
        "requirements-dev.txt", "requirements-dev.in", "requirements-dev.lock.txt", "pyproject.toml", "pytest.ini",
        "DEPENDENCY_LOCK_STATUS.json", "RUNTIME_BUNDLE_CONTRACT.json", ".env.example", ".dockerignore", "VERSION",
        "Dockerfile", "Dockerfile.dockerignore", "Dockerfile.quality", "Dockerfile.quality.dockerignore", "Procfile", "railway.toml", "docker-compose.yml", "data/database.json", "QUALITY_PROOF.json",
    ]
    files = [ROOT / name for name in roots if (ROOT / name).is_file()]
    for directory in (
        "bot_runtime", "core", "modules", "services", "repositories", "handlers", "jobs", "ui", "scripts", "tests",
        "assets", "webapp", "nginx", "systemd",
    ):
        root = ROOT / directory
        if root.exists():
            files.extend(path for path in root.rglob("*") if path.is_file() and is_allowed(path, outer=False))
    files = [path for path in files if path.relative_to(ROOT).as_posix() not in RUNTIME_OUTER_ONLY_TESTS]
    return sorted(set(files), key=lambda path: path.relative_to(ROOT).as_posix())


def evidence_files() -> list[Path]:
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    names = {
        "QUALITY_PROOF.json", "RELEASE_MANIFEST.json", "SHA256SUMS.txt", "DEPENDENCY_LOCK_STATUS.json",
        f"FINAL_AUDIT_V{version}_FA.md", f"IMPLEMENTATION_REPORT_V{version}_FA.md", f"RELEASE_NOTES_V{version}_FA.md",
        "MT5_PRODUCTION_ACCEPTANCE_FA.txt",
    }
    files = [ROOT / name for name in names if (ROOT / name).is_file()]
    artifacts = ROOT / "quality-artifacts"
    if artifacts.is_dir():
        files.extend(path for path in artifacts.rglob("*") if path.is_file() and not path.name.startswith(".coverage"))
    return sorted(set(files), key=lambda path: path.relative_to(ROOT).as_posix())


def outer_files() -> list[Path]:
    return sorted(
        (path for path in ROOT.rglob("*") if path.is_file() and is_allowed(path, outer=True)),
        key=lambda path: path.relative_to(ROOT).as_posix(),
    )


def write_zip(target: Path, files: list[Path]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, FIXED_ZIP_TIME)
            executable = bool(path.stat().st_mode & stat.S_IXUSR)
            info.external_attr = ((0o755 if executable else 0o644) & 0xFFFF) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(temporary) as archive:
        broken = archive.testzip()
        if broken:
            raise RuntimeError(f"corrupt ZIP member: {broken}")
    temporary.replace(target)


def update_runtime_checksum(runtime: Path) -> str:
    digest = sha256(runtime)
    restore = ROOT / "restore_runtime.py"
    # Replace bytes in place so the source file's existing line endings remain
    # untouched on Linux, macOS and Windows.  Text-mode read/write normalizes
    # newlines and can invalidate the source fingerprint after packaging.
    payload = restore.read_bytes()
    payload, count = re.subn(
        rb'BUNDLE_SHA256 = "[0-9a-fA-F_]+"',
        f'BUNDLE_SHA256 = "{digest}"'.encode("ascii"),
        payload,
        count=1,
    )
    if count != 1:
        raise RuntimeError("could not update restore_runtime.py checksum")
    restore.write_bytes(payload)
    (ROOT / "sentinel_runtime.zip.sha256").write_text(f"{digest}  sentinel_runtime.zip\n", encoding="utf-8")
    return digest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outer", type=Path, required=True)
    parser.add_argument("--quality-proof", type=Path, default=ROOT / "QUALITY_PROOF.json")
    parser.add_argument("--production", action="store_true")
    parser.add_argument("--evidence", type=Path, help="Optional separate quality-evidence ZIP")
    args = parser.parse_args()

    clean_tree()
    proof_path = args.quality_proof if args.quality_proof.is_absolute() else ROOT / args.quality_proof
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if str(proof.get("version") or "") != version:
        raise RuntimeError("quality proof version does not match VERSION")
    if str(proof.get("source_sha256") or "") != source_fingerprint(ROOT):
        raise RuntimeError("source changed after quality validation; rerun quality_gate.py")
    validations = proof.get("validation") if isinstance(proof.get("validation"), dict) else {}
    if not validations or not all(bool(value) for value in validations.values()):
        raise RuntimeError("quality proof contains an unsuccessful validation")
    deferred = proof.get("deferred_validation") if isinstance(proof.get("deferred_validation"), dict) else {}
    if args.production and (proof.get("release_channel") != "production" or deferred):
        raise RuntimeError("production archive requires a production proof without deferred validation")
    if proof_path.resolve() != (ROOT / "QUALITY_PROOF.json").resolve():
        shutil.copy2(proof_path, ROOT / "QUALITY_PROOF.json")

    runtime = ROOT / "sentinel_runtime.zip"
    write_zip(runtime, runtime_files())
    runtime_digest = update_runtime_checksum(runtime)

    lock_status = json.loads((ROOT / "DEPENDENCY_LOCK_STATUS.json").read_text(encoding="utf-8"))
    manifest = {
        "version": version,
        "release_channel": str(proof.get("release_channel") or "candidate"),
        "created_at": datetime.now(UTC).isoformat(),
        "commit_sha": proof.get("commit_sha"),
        "docker_image_digest": proof.get("docker_image_digest"),
        "quality_proof_source_sha256": proof.get("source_sha256"),
        "runtime_sha256": runtime_digest,
        "automated_tests_discovered": proof.get("automated_tests_discovered", 0),
        "automated_tests_executed": proof.get("automated_tests_executed", 0),
        "telegram_handlers": proof.get("telegram_handlers", 0),
        "line_coverage_percent": proof.get("line_coverage_percent", 0),
        "critical_path_coverage_percent": proof.get("critical_path_coverage_percent", 0),
        "validation": validations,
        "deferred_validation": deferred,
        "dependency_lock": lock_status,
        "security_controls": {
            "docker_quality_dependency": True,
            "secure_non_root_entrypoint": True,
            "strict_production_secret_validation": True,
            "session_key_rotation": True,
            "backup_key_rotation": True,
            "private_encrypted_receipt_storage": True,
            "receipt_upload_quota_and_retention": True,
            "postgres_advisory_migration_lock": True,
            "postgres_connection_pool": True,
            "redis_connection_limits": True,
            "bounded_blocking_io": True,
            "sse_connection_limits": True,
            "maintenance_mutation_gate": True,
            "csrf_and_origin_validation": True,
        },
        "production_acceptance": {
            "required_line_coverage_percent": 40,
            "required_critical_path_coverage_percent": 85,
            "requires_no_deferred_validation": True,
            "requires_real_postgres_redis_telegram_staging": True,
            "requires_live_gemini_generation_test": True,
            "requires_playwright_telegram_webview_smoke": True,
            "requires_mt5_ex5_and_demo_attestation": True,
            "requires_complete_transitive_hash_lock": True,
        },
    }
    (ROOT / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    subprocess.run(  # nosec B603
        [sys.executable, "scripts/release_gate.py", *( ["--production"] if args.production else [] )],
        cwd=ROOT, check=True,
    )

    hashes = {
        "sentinel_runtime.zip": sha256(runtime),
        "QUALITY_PROOF.json": sha256(ROOT / "QUALITY_PROOF.json"),
        "RELEASE_MANIFEST.json": sha256(ROOT / "RELEASE_MANIFEST.json"),
    }
    (ROOT / "SHA256SUMS.txt").write_text(
        "".join(f"{digest}  {name}\n" for name, digest in sorted(hashes.items())), encoding="utf-8",
    )
    write_zip(args.outer, outer_files())
    evidence_digest = None
    if args.evidence:
        write_zip(args.evidence, evidence_files())
        evidence_digest = sha256(args.evidence)
    print(
        f"RELEASE ARCHIVE OK: {args.outer} sha256={sha256(args.outer)} "
        f"channel={manifest['release_channel']} evidence_sha256={evidence_digest or 'not_requested'}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
