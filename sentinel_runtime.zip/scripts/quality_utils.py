from __future__ import annotations

import hashlib
from pathlib import Path

GENERATED_FILES = {
    "QUALITY_PROOF.json",
    "RELEASE_MANIFEST.json",
    "SHA256SUMS.txt",
    "sentinel_runtime.zip",
    "sentinel_runtime.zip.sha256",
    "junit.xml",
    "coverage.xml",
    "coverage.json",
}
DEPLOY_ROOT_FILES = {
    ".dockerignore",
    ".pre-commit-config.yaml",
    ".env.example",
    "Dockerfile",
    "Dockerfile.dockerignore",
    "Dockerfile.quality",
    "Dockerfile.quality.dockerignore",
    "DEPENDENCY_LOCK_STATUS.json",
    "Procfile",
    "VERSION",
    "bot.py",
    "config.py",
    "docker-compose.yml",
    "main.py",
    "pyproject.toml",
    "pytest.ini",
    "railway.toml",
    "requirements.in",
    "requirements-dev.in",
    "requirements.txt",
    "requirements.lock.txt",
    "requirements-dev.txt",
    "requirements-dev.lock.txt",
    "restore_runtime.py",
}
DEPLOY_ROOT_DIRS = {
    ".github",
    "assets",
    "bot_runtime",
    "core",
    "handlers",
    "jobs",
    "modules",
    "nginx",
    "repositories",
    "scripts",
    "services",
    "systemd",
    "tests",
    "ui",
    "webapp",
}
DEPLOY_EXACT_FILES = {"data/database.json"}
IGNORED_DIRS = {
    ".git",
    ".pytest_cache",
    ".ruff_cache",
    ".audit-cache",
    ".venv",
    "venv",
    "__pycache__",
    "logs",
    "backups",
    "quality-artifacts",
}
IGNORED_SUFFIXES = {".pyc", ".pyo", ".sqlite", ".sqlite3", ".db", ".log", ".tmp", ".zip"}


def _is_ignored_directory(name: str) -> bool:
    return name in IGNORED_DIRS or name.startswith(".venv")


def source_files(root: Path) -> list[Path]:
    output: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(_is_ignored_directory(part) for part in relative.parts):
            continue
        if path.name in GENERATED_FILES or path.suffix.lower() in IGNORED_SUFFIXES:
            continue
        relative_name = relative.as_posix()
        deploy_source = (
            (len(relative.parts) == 1 and relative.name in DEPLOY_ROOT_FILES)
            or (relative.parts and relative.parts[0] in DEPLOY_ROOT_DIRS)
            or relative_name in DEPLOY_EXACT_FILES
        )
        if deploy_source:
            output.append(path)
    return sorted(output, key=lambda item: item.relative_to(root).as_posix())


def source_fingerprint(root: Path) -> str:
    digest = hashlib.sha256()
    for path in source_files(root):
        relative_name = path.relative_to(root).as_posix()
        relative = relative_name.encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        payload = path.read_bytes()
        if relative_name == "restore_runtime.py":
            # The release builder updates only the embedded runtime checksum.
            # Normalize that generated value while still fingerprinting every
            # executable line of the restore implementation.
            import re
            payload = re.sub(
                rb'BUNDLE_SHA256 = "[0-9a-fA-F_]+"',
                b'BUNDLE_SHA256 = "__RUNTIME_BUNDLE_SHA256__"',
                payload,
                count=1,
            )
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def automated_test_count(root: Path) -> int:
    count = 0
    tests_root = root / "tests"
    for path in tests_root.rglob("test_*.py"):
        count += path.read_text(encoding="utf-8").count("def test_")
    return count
