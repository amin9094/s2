#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from core.db import with_db
from jobs.receipt_maintenance import cleanup_orphan_receipts


def main() -> int:
    parser = argparse.ArgumentParser(description="Clean unused SENTINEL payment receipt uploads")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--limit", type=int, default=500)
    args = parser.parse_args()
    result = with_db(lambda db: cleanup_orphan_receipts(db, older_than_days=args.days, limit=args.limit))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
