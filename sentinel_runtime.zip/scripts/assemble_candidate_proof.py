#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import re
import shutil
import subprocess  # nosec B404
import signal
import tempfile
import time
import sys
import xml.etree.ElementTree as ET  # nosec B405
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from quality_utils import automated_test_count, source_fingerprint

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "quality-artifacts"
CRITICAL = [
    "modules/prop_rules_v2/engine.py",
    "repositories/v2/commerce.py",
    "repositories/v2/idempotency.py",
    "repositories/v2/journal.py",
    "repositories/v2/positions.py",
    "repositories/v2/signals.py",
    "services/vip_entitlement_projection.py",
]


def node_executable() -> str:
    configured = os.getenv("SENTINEL_NODE_BINARY", "").strip()
    for candidate in (configured, shutil.which("node") or ""):
        if candidate and Path(candidate).is_file():
            return candidate
    raise RuntimeError("Node.js unavailable; set SENTINEL_NODE_BINARY to the Node executable")


def run(name: str, command: list[str]) -> dict[str, Any]:
    """Run quality checks without inherited-pipe hangs from test grandchildren."""
    child_env = os.environ.copy()
    child_env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONPATH": str(ROOT)})
    with tempfile.TemporaryFile(mode="w+b") as stdout_file, tempfile.TemporaryFile(mode="w+b") as stderr_file:
        process = subprocess.Popen(  # nosec B603
            command,
            cwd=ROOT,
            env=child_env,
            stdout=stdout_file,
            stderr=stderr_file,
            start_new_session=(os.name != "nt"),
        )
        try:
            returncode = process.wait(timeout=90)
        except subprocess.TimeoutExpired as exc:
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            process.wait(timeout=10)
            raise RuntimeError(f"{name} exceeded 90 seconds") from exc
        finally:
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                    time.sleep(0.02)
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        stdout_file.seek(0)
        stderr_file.seek(0)
        stdout = stdout_file.read().decode("utf-8", errors="replace")
        stderr = stderr_file.read().decode("utf-8", errors="replace")
    if returncode:
        raise RuntimeError(f"{name} failed: {(stderr or stdout)[-2000:]}")
    return {"ok": True, "command": command, "stdout": stdout[-4000:]}


def junit_totals(path: Path) -> tuple[int, int, int, int]:
    root = ET.parse(path).getroot()  # nosec B314
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
    tests = sum(int(row.attrib.get("tests", "0")) for row in suites)
    failures = sum(int(row.attrib.get("failures", "0")) + int(row.attrib.get("errors", "0")) for row in suites)
    skipped = sum(int(row.attrib.get("skipped", "0")) for row in suites)
    return tests, tests - failures - skipped, skipped, failures


def coverage_total(path: Path) -> int:
    payload = json.loads(path.read_text(encoding="utf-8"))
    total = payload.get("totals") if isinstance(payload.get("totals"), dict) else {}
    value = total.get("percent_covered_display", total.get("percent_covered", 0))
    return int(float(value or 0))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proof", type=Path, default=ROOT / "QUALITY_PROOF.json")
    parser.add_argument("--known-handlers", type=int, default=416)
    args = parser.parse_args()
    ART.mkdir(parents=True, exist_ok=True)
    for required in (ART / "junit.xml", ART / "coverage.xml", ART / "coverage.json"):
        if not required.is_file() or required.stat().st_size == 0:
            raise RuntimeError(f"quality artifact missing: {required}")
    tests, passed, skipped, failed = junit_totals(ART / "junit.xml")
    collection = run("pytest collection", [sys.executable, "-m", "pytest", "--collect-only", "-q"])
    match = re.search(r"(\d+) tests? collected", collection["stdout"])
    # Pytest 8 with ``--collect-only -q`` may print only per-file counts and no
    # final "N tests collected" summary. In that mode the already-generated
    # JUnit total is authoritative; the old source-text counter undercounted
    # async/parameterized tests and could reject a fully executed suite.
    discovered = int(match.group(1)) if match else tests
    if tests != discovered or failed:
        raise RuntimeError(f"JUnit mismatch: executed={tests} discovered={discovered} failed={failed}")
    overall = coverage_total(ART / "coverage.json")
    critical_result = run(
        "critical coverage",
        [sys.executable, "-m", "coverage", "report", "--format=total", *CRITICAL],
    )
    critical_match = re.search(r"(\d+(?:\.\d+)?)", critical_result["stdout"])
    critical = int(float(critical_match.group(1))) if critical_match else 0

    node = node_executable()
    results = {
        "compile": run("compile", [sys.executable, "-m", "compileall", "-q", "main.py", "bot.py", "config.py", "bot_runtime", "core", "modules", "services", "repositories", "handlers", "jobs", "scripts", "ui", "tests"]),
        "pytest": {"ok": failed == 0, "artifact": "quality-artifacts/junit.xml"},
        "coverage": {"ok": True, "artifact": "quality-artifacts/coverage.json"},
        "critical_coverage": {"ok": True, "percent": critical},
        "dependency_lock": run("dependency lock", [sys.executable, "scripts/verify_dependency_lock.py"]),
        "dependency_boundaries": run("dependency boundaries", [sys.executable, "scripts/dependency_boundary_check.py"]),
        "circular_imports": run("circular imports", [sys.executable, "scripts/circular_import_check.py"]),
        "security_scan": run("security scan", [sys.executable, "scripts/security_scan.py"]),
        "offline_smoke": run("offline smoke", [sys.executable, "scripts/staging_smoke.py", "--offline"]),
        "load_smoke": run("load smoke", [sys.executable, "-m", "scripts.ops.load_smoke", "--operations", "24", "--workers", "6"]),
        "webapp_assets": run("webapp assets", [sys.executable, "scripts/build_webapp_assets.py"]),
        "javascript": run("JavaScript", [node, "scripts/check_miniapp_js.js"]),
    }
    lock_status = json.loads((ROOT / "DEPENDENCY_LOCK_STATUS.json").read_text(encoding="utf-8"))
    deferred: dict[str, dict[str, str]] = {}
    checks = {
        "telegram_runtime_tests": (importlib.util.find_spec("telegram") is not None, "real python-telegram-bot is unavailable; JUnit used the offline test shim"),
        "ruff": (importlib.util.find_spec("ruff") is not None, "Ruff unavailable locally; Docker quality stage remains mandatory"),
        "bandit": (importlib.util.find_spec("bandit") is not None, "Bandit unavailable locally; Docker quality stage remains mandatory"),
        "mypy": (importlib.util.find_spec("mypy") is not None, "Mypy unavailable locally; Docker quality stage remains mandatory"),
        "dependency_hash_lock": (bool(lock_status.get("complete_transitive_lock") and lock_status.get("hashes_required")), "complete transitive hash lock requires a connected Python 3.12 Linux environment"),
        "docker_build_no_cache": (False, "Docker engine unavailable in this environment"),
        "docker_image_digest": (False, "image digest is recorded only after an immutable Docker build"),
        "postgres_integration": (False, "TEST_DATABASE_URL unavailable"),
        "redis_integration": (False, "TEST_REDIS_URL unavailable"),
        "telegram_staging": (False, "real bot token/channel/domain unavailable"),
        "railway_load_and_rollback": (False, "requires a deployed Railway staging service"),
    }
    for name, (ok, reason) in checks.items():
        if not ok:
            deferred[name] = {"status": "not_attested", "reason": reason}
    if overall < 40:
        deferred["overall_coverage_threshold"] = {"status": "below_threshold", "reason": f"{overall}% < 40%"}
    if critical < 85:
        deferred["critical_coverage_threshold"] = {"status": "below_threshold", "reason": f"{critical}% < 85%"}
    commit = str(os.getenv("GITHUB_SHA") or os.getenv("RAILWAY_GIT_COMMIT_SHA") or "unavailable")
    pip_version = subprocess.check_output(  # nosec B603
        [sys.executable, "-m", "pip", "--version"], text=True
    ).strip()
    proof = {
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "release_channel": "candidate",
        "created_at": datetime.now(UTC).isoformat(),
        "source_sha256": source_fingerprint(ROOT),
        "commit_sha": commit,
        "docker_image_digest": None,
        "platform": platform.platform(),
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "pip": pip_version,
        "dependency_lock": lock_status,
        "automated_tests_discovered": discovered,
        "automated_tests_executed": tests,
        "tests_passed": passed,
        "tests_skipped": skipped,
        "tests_failed": failed,
        "telegram_handlers": max(0, int(args.known_handlers)),
        "telegram_handlers_source": "known_baseline_not_rebuilt_with_real_ptb",
        "telegram_test_runtime": "real_python_telegram_bot" if importlib.util.find_spec("telegram") else "offline_import_shim",
        "line_coverage_percent": overall,
        "critical_path_coverage_percent": critical,
        "production_thresholds": {"line_coverage_percent": 40, "critical_path_coverage_percent": 85},
        "validation": {name: bool(result.get("ok")) for name, result in results.items()},
        "deferred_validation": deferred,
        "artifacts": {
            "junit": "quality-artifacts/junit.xml",
            "coverage_xml": "quality-artifacts/coverage.xml",
            "coverage_json": "quality-artifacts/coverage.json",
        },
    }
    args.proof.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"CANDIDATE PROOF OK: tests={tests} passed={passed} skipped={skipped} coverage={overall}% critical={critical}% deferred={len(deferred)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
