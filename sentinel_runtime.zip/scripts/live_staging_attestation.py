#!/usr/bin/env python3
"""Credential-gated production-readiness attestation for SENTINEL.

This script intentionally refuses to use production BOT_TOKEN/DATABASE_URL or
production channel IDs.  It runs only when the explicit TEST_* variables are
present, so a local/offline release cannot accidentally claim a live pass.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import UTC, datetime
from typing import Any

REQUIRED = ("TEST_DATABASE_URL", "TEST_REDIS_URL", "TEST_BOT_TOKEN")
OPTIONAL_CHANNELS = ("TEST_PUBLIC_CHANNEL_ID", "TEST_PRIVATE_CHANNEL_ID")


def now() -> str:
    return datetime.now(UTC).isoformat()


def emit(report: dict[str, Any], code: int) -> int:
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return code


def postgres_check(url: str) -> dict[str, Any]:
    import psycopg

    with psycopg.connect(url, connect_timeout=10) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database(), current_user, NOW()")
            database, user, stamp = cur.fetchone()
            cur.execute("CREATE TEMP TABLE sentinel_attestation_probe(id INTEGER PRIMARY KEY, value TEXT)")
            cur.execute("INSERT INTO sentinel_attestation_probe VALUES (1, 'ok')")
            cur.execute("SELECT value FROM sentinel_attestation_probe WHERE id=1")
            value = cur.fetchone()[0]
        conn.rollback()
    return {"ok": value == "ok", "database": database, "user": user, "server_time": str(stamp)}


def redis_check(url: str) -> dict[str, Any]:
    import redis

    client = redis.Redis.from_url(url, socket_connect_timeout=10, socket_timeout=10, decode_responses=True)
    key = f"sentinel:attestation:{os.getpid()}"
    pong = bool(client.ping())
    client.set(key, "ok", ex=30)
    value = client.get(key)
    client.delete(key)
    info = client.info(section="server")
    return {"ok": pong and value == "ok", "redis_version": info.get("redis_version", "unknown")}


async def telegram_check(token: str) -> dict[str, Any]:
    from telegram import Bot

    bot = Bot(token=token)
    await bot.initialize()
    messages: list[dict[str, Any]] = []
    try:
        me = await bot.get_me()
        for env_name in OPTIONAL_CHANNELS:
            raw = str(os.getenv(env_name) or "").strip()
            if not raw:
                continue
            chat_id = int(raw)
            member = await bot.get_chat_member(chat_id, me.id)
            message = await bot.send_message(
                chat_id,
                "SENTINEL staging attestation — this message will be deleted automatically.",
                disable_notification=True,
            )
            deleted = False
            try:
                deleted = bool(await bot.delete_message(chat_id, message.message_id))
            except Exception:
                deleted = False
            messages.append({
                "scope": env_name,
                "chat_id": chat_id,
                "member_status": str(member.status),
                "message_id": int(message.message_id),
                "deleted": deleted,
            })
        return {
            "ok": True,
            "bot_id": int(me.id),
            "username": str(me.username or ""),
            "channel_probes": messages,
            "channels_attested": len(messages),
        }
    finally:
        await bot.shutdown()


async def main() -> int:
    missing = [name for name in REQUIRED if not str(os.getenv(name) or "").strip()]
    report: dict[str, Any] = {
        "status": "NOT_ATTESTED" if missing else "RUNNING",
        "started_at": now(),
        "missing": missing,
        "checks": {},
    }
    if missing:
        report["message"] = "Live staging checks were not run because explicit TEST_* credentials are absent."
        return emit(report, 3)
    failures: list[str] = []
    checks = report["checks"]
    for name, fn, value in (
        ("postgresql", postgres_check, os.environ["TEST_DATABASE_URL"]),
        ("redis", redis_check, os.environ["TEST_REDIS_URL"]),
    ):
        try:
            checks[name] = await asyncio.to_thread(fn, value)
            if not checks[name].get("ok"):
                failures.append(name)
        except Exception as exc:
            checks[name] = {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}
            failures.append(name)
    try:
        checks["telegram"] = await telegram_check(os.environ["TEST_BOT_TOKEN"])
        if not checks["telegram"].get("ok"):
            failures.append("telegram")
    except Exception as exc:
        checks["telegram"] = {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}
        failures.append("telegram")
    report["finished_at"] = now()
    report["status"] = "FAILED" if failures else "PASSED"
    report["failures"] = failures
    return emit(report, 1 if failures else 0)


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
