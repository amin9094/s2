from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

from core.db import snapshot


def _rows() -> list[dict[str, Any]]:
    data = snapshot()
    users = data.get("users", {}) if isinstance(data.get("users"), dict) else {}
    profiles = data.get("user_profiles", {}) if isinstance(data.get("user_profiles"), dict) else {}
    memberships = data.get("vip_users", {}) if isinstance(data.get("vip_users"), dict) else {}
    points = data.get("user_points", {}) if isinstance(data.get("user_points"), dict) else {}
    crm = data.get("crm_profiles", {}) if isinstance(data.get("crm_profiles"), dict) else {}
    rows: list[dict[str, Any]] = []
    for user_id in sorted(set(users) | set(profiles) | set(memberships) | set(points) | set(crm)):
        account = users.get(user_id, {}) if isinstance(users.get(user_id), dict) else {}
        profile = profiles.get(user_id, {}) if isinstance(profiles.get(user_id), dict) else {}
        membership = memberships.get(user_id, {}) if isinstance(memberships.get(user_id), dict) else {}
        crm_profile = crm.get(user_id, {}) if isinstance(crm.get(user_id), dict) else {}
        rows.append(
            {
                "user_id": str(user_id),
                "username": account.get("username", ""),
                "first_name": account.get("first_name", ""),
                "last_name": account.get("last_name", ""),
                "phone": profile.get("phone") or crm_profile.get("phone") or "",
                "email": profile.get("email") or crm_profile.get("email") or "",
                "source": profile.get("source") or crm_profile.get("source") or "",
                "company": profile.get("company") or crm_profile.get("company") or "",
                "preferred_market": profile.get("preferred_market") or crm_profile.get("preferred_market") or "",
                "crm_stage": crm_profile.get("stage", ""),
                "assigned_admin": crm_profile.get("assigned_admin") or profile.get("assigned_admin") or "",
                "lead_score": crm_profile.get("lead_score", 0),
                "vip_status": membership.get("status", ""),
                "vip_plan_id": membership.get("plan_id") or membership.get("plan") or "",
                "vip_expires_at": membership.get("expires_at") or membership.get("expiry") or "",
                "points": int(points.get(user_id, 0) or 0),
                "created_at": account.get("created_at", ""),
                "last_seen_at": account.get("last_seen_at", ""),
            }
        )
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Export the SENTINEL user master dataset")
    parser.add_argument("output", type=Path)
    parser.add_argument("--format", choices=("csv", "json"), default="csv")
    args = parser.parse_args()
    rows = _rows()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.format == "json":
        args.output.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    else:
        fields = list(rows[0]) if rows else ["user_id"]
        with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
    print(f"Exported {len(rows)} users to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
