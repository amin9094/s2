from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.db import with_db
from modules.app_migrations import MIGRATIONS, apply_migration, migration_status, rollback_migration


def main() -> int:
    parser = argparse.ArgumentParser(description="SENTINEL application migration manager")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    apply_parser = sub.add_parser("apply")
    apply_parser.add_argument("name", nargs="?", default="all")
    rollback_parser = sub.add_parser("rollback")
    rollback_parser.add_argument("name")
    args = parser.parse_args()

    if args.command == "status":
        from core.db import load_db
        print(json.dumps(migration_status(load_db()), ensure_ascii=False, indent=2))
        return 0
    if args.command == "apply":
        names = list(MIGRATIONS) if args.name == "all" else [args.name]
        results = [with_db(lambda db, name=name: apply_migration(db, name)) for name in names]
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0
    result = with_db(lambda db: rollback_migration(db, args.name))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
