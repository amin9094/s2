from __future__ import annotations

from datetime import UTC, datetime, timedelta
import os
from typing import Any

from modules.vip_order_state import (
    ORDER_APPROVED, ORDER_APPROVING, ORDER_CANCELLED, ORDER_NEEDS_RECEIPT,
    ORDER_PENDING, ORDER_REJECTED, RESUBMITTABLE_STATES,
    assert_manual_payment_evidence, assert_transition,
)

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso


class CommerceRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def create_receipt(self, user_id: int | str, record: dict[str, Any]) -> dict[str, Any]:
        """Persist a receipt exactly once per user/checksum.

        The database unique index is the concurrency boundary. A repeated upload
        returns the existing public receipt record instead of creating another
        storage reference or allowing a later order to attach a duplicate.
        """
        receipt = {
            **record,
            "id": str(record.get("receipt_id") or record.get("id") or new_id("rcpt")),
            "user_id": str(user_id),
            "status": str(record.get("status") or "available"),
            "created_at": str(record.get("created_at") or utc_iso()),
        }
        checksum = str(receipt.get("checksum") or "").strip().lower()
        if len(checksum) != 64 or any(ch not in "0123456789abcdef" for ch in checksum):
            raise ValueError("RECEIPT_CHECKSUM_INVALID")
        object_key = str(receipt.get("object_key") or receipt.get("path") or receipt.get("storage_key") or "")
        receipt["checksum"] = checksum
        with self.engine.transaction() as cursor:
            # ``ON CONFLICT DO NOTHING`` keeps the PostgreSQL transaction usable
            # when concurrent uploads race on the unique checksum boundary.
            # Catching a unique-violation and querying again would leave a
            # PostgreSQL transaction aborted until rollback.
            cursor.execute(
                """INSERT INTO v8_receipts(id,user_id,storage_backend,object_key,checksum,mime_type,size_bytes,status,order_id,created_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING""",
                (
                    receipt["id"], receipt["user_id"], str(receipt.get("storage_backend") or "local"), object_key,
                    checksum, str(receipt.get("mime_type") or "image/webp"), int(receipt.get("size_bytes") or 0),
                    receipt["status"], str(receipt.get("order_id") or "") or None, receipt["created_at"], json_dump(receipt),
                ),
            )
            canonical = cursor.execute(
                "SELECT * FROM v8_receipts WHERE user_id=? AND checksum=?",
                (receipt["user_id"], checksum),
            ).fetchone()
            if not canonical:
                raise RuntimeError("RECEIPT_PERSISTENCE_FAILED")
            return self._decode_receipt(canonical)

    @staticmethod
    def _decode_receipt(row: dict[str, Any]) -> dict[str, Any]:
        data = json_load(row.get("payload"), {}) or {}
        data.update({key: value for key, value in row.items() if key != "payload"})
        data["receipt_id"] = str(data.get("id") or "")
        return data


    def receipt_usage(self, user_id: int | str, *, since_iso: str = "") -> dict[str, int]:
        uid = str(user_id)
        where = "user_id=?"
        params: list[Any] = [uid]
        if since_iso:
            where += " AND created_at>=?"
            params.append(str(since_iso))
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                f"SELECT COUNT(*) AS count, COALESCE(SUM(size_bytes),0) AS bytes FROM v8_receipts WHERE {where}",  # nosec B608
                tuple(params),
            ).fetchone() or {}
            available = cursor.execute(
                "SELECT COUNT(*) AS count, COALESCE(SUM(size_bytes),0) AS bytes FROM v8_receipts WHERE user_id=? AND status='available' AND order_id IS NULL",
                (uid,),
            ).fetchone() or {}
        return {
            "count": int(row.get("count") or 0),
            "bytes": int(row.get("bytes") or 0),
            "available": int(available.get("count") or 0),
            "available_bytes": int(available.get("bytes") or 0),
        }

    def prune_available_receipts(self, user_id: int | str, *, keep: int, exclude_id: str = "") -> list[dict[str, Any]]:
        uid = str(user_id)
        keep_count = max(0, int(keep))
        with self.engine.transaction() as cursor:
            rows = cursor.execute(
                "SELECT * FROM v8_receipts WHERE user_id=? AND status='available' AND order_id IS NULL ORDER BY created_at DESC, id DESC",
                (uid,),
            ).fetchall() or []
            retained = 0
            removed: list[dict[str, Any]] = []
            for row in rows:
                if str(row.get("id") or "") == str(exclude_id or ""):
                    retained += 1
                    continue
                if retained < keep_count:
                    retained += 1
                    continue
                cursor.execute(
                    "DELETE FROM v8_receipts WHERE id=? AND user_id=? AND status='available' AND order_id IS NULL",
                    (str(row.get("id") or ""), uid),
                )
                if cursor.rowcount == 1:
                    removed.append(self._decode_receipt(row))
        return removed

    def get_receipt(self, user_id: int | str, receipt_id: str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT * FROM v8_receipts WHERE id=? AND user_id=?",(str(receipt_id),str(user_id))).fetchone()
        if not row:
            return None
        return self._decode_receipt(row)

    def attach_receipt(self, user_id: int | str, receipt_id: str, order_id: str) -> dict[str, Any]:
        receipt=self.get_receipt(user_id,receipt_id)
        if not receipt:raise ValueError("RECEIPT_NOT_FOUND")
        current_order = str(receipt.get("order_id") or "")
        if current_order:
            if current_order == str(order_id):
                return receipt  # idempotent retry for the same order
            raise ValueError("RECEIPT_ALREADY_USED")
        receipt.update({"order_id":str(order_id),"status":"attached"})
        with self.engine.transaction() as cursor:
            cursor.execute("UPDATE v8_receipts SET status='attached',order_id=?,payload=? WHERE id=? AND user_id=? AND order_id IS NULL",
                           (str(order_id),json_dump(receipt),str(receipt_id),str(user_id)))
            if cursor.rowcount != 1:
                canonical = cursor.execute(
                    "SELECT * FROM v8_receipts WHERE id=? AND user_id=?",
                    (str(receipt_id), str(user_id)),
                ).fetchone()
                if canonical and str(canonical.get("order_id") or "") == str(order_id):
                    return self._decode_receipt(canonical)
                raise ValueError("RECEIPT_ALREADY_USED")
        return receipt

    def create_quote(self, user_id: int | str, quote: dict[str, Any]) -> dict[str, Any]:
        row = {
            **quote,
            "quote_id": str(quote.get("quote_id") or new_id("quote")),
            "user_id": str(user_id),
            "status": str(quote.get("status") or "active"),
            "created_at": str(quote.get("created_at") or utc_iso()),
            "payment_review_mode": "manual_receipt",
        }
        payable_toman = max(0, int(round(float(row.get("payable_toman") or 0))))
        row["payable_toman"] = payable_toman
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_checkout_quotes(id,user_id,plan_id,status,payment_method,payable_toman,usdt_amount,
                   expires_at,consumed_at,order_id,created_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET status=excluded.status,consumed_at=excluded.consumed_at,
                   order_id=excluded.order_id,payload=excluded.payload""",
                (
                    row["quote_id"], row["user_id"], str(row.get("plan_id") or "") or None, row["status"],
                    str(row.get("payment_method") or ""), payable_toman,
                    float(row.get("payment_amount_usdt") or row.get("usdt_amount") or 0),
                    str(row.get("expires_at") or utc_iso()), row.get("consumed_at"),
                    str(row.get("order_id") or "") or None, row["created_at"], json_dump(row),
                ),
            )
        return row

    def get_quote(self, user_id: int | str, quote_id: str, *, require_active: bool = True) -> dict[str, Any]:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT * FROM v8_checkout_quotes WHERE id=? AND user_id=?",(str(quote_id),str(user_id))).fetchone()
        if not row: raise ValueError("CHECKOUT_QUOTE_NOT_FOUND")
        quote=json_load(row.get("payload"),{}) or {}; quote.update({"quote_id":row["id"],"status":row["status"],"expires_at":str(row["expires_at"])})
        from datetime import datetime, UTC
        try: expired=datetime.fromisoformat(str(row["expires_at"]).replace("Z","+00:00"))<=datetime.now(UTC)
        except Exception: expired=True
        if expired and quote["status"]=="active": quote["status"]="expired"
        if require_active and quote["status"]!="active": raise ValueError("CHECKOUT_QUOTE_EXPIRED")
        return quote

    def consume_quote(self, user_id: int | str, quote_id: str, order_id: str) -> dict[str, Any]:
        quote=self.get_quote(user_id,quote_id,require_active=True); now=utc_iso(); quote.update({"status":"consumed","consumed_at":now,"order_id":order_id})
        with self.engine.transaction() as cursor:
            cursor.execute("UPDATE v8_checkout_quotes SET status='consumed',consumed_at=?,order_id=?,payload=? WHERE id=? AND user_id=? AND status='active'",
                           (now,order_id,json_dump(quote),quote_id,str(user_id)))
            if cursor.rowcount!=1: raise ValueError("CHECKOUT_QUOTE_ALREADY_CONSUMED")
        return quote

    def submit_order_from_quote(
        self,
        user_id: int | str,
        *,
        quote_id: str,
        receipt_id: str = "",
        transaction_hash: str = "",
        profile: dict[str, Any] | None = None,
        order_id: str = "",
    ) -> dict[str, Any]:
        """Atomically consume a quote, attach the receipt and create a manual-review order.

        Every payable order requires an image receipt for both card and USDT.
        TXID is optional metadata and is never used for automatic approval. Even
        zero-value orders remain pending so an administrator explicitly approves
        the entitlement and the Telegram invite link is created in one workflow.
        """
        uid = str(user_id)
        now_dt = datetime.now(UTC)
        now = now_dt.isoformat()
        order_id = str(order_id or new_id("ord"))
        with self.engine.transaction() as cursor:
            # PostgreSQL transactions for the same user are serialized so two
            # simultaneous quotes cannot create two open payment orders. SQLite
            # already uses BEGIN IMMEDIATE at the engine boundary.
            if self.engine.dialect.name == "postgres":
                cursor.execute(
                    "SELECT pg_advisory_xact_lock(hashtextextended(?, 0))",
                    (f"sentinel:vip-order-user:{uid}",),
                )
            quote_sql = "SELECT * FROM v8_checkout_quotes WHERE id=? AND user_id=?"
            if self.engine.dialect.name == "postgres":
                quote_sql += " FOR UPDATE"
            quote_row = cursor.execute(quote_sql, (str(quote_id), uid)).fetchone()
            if not quote_row:
                raise ValueError("CHECKOUT_QUOTE_NOT_FOUND")
            quote = json_load(quote_row.get("payload"), {}) or {}
            try:
                expired = datetime.fromisoformat(str(quote_row["expires_at"]).replace("Z", "+00:00")) <= now_dt
            except Exception:
                expired = True
            if str(quote_row["status"]) != "active" or expired:
                raise ValueError("CHECKOUT_QUOTE_EXPIRED")

            payable = max(0, int(round(float(quote_row.get("payable_toman") or 0))))
            method = str(quote_row.get("payment_method") or "").strip().lower()
            tx = str(transaction_hash or "").strip() or None
            open_order = cursor.execute(
                "SELECT id FROM v8_vip_orders WHERE user_id=? AND status IN ('pending','approving') LIMIT 1",
                (uid,),
            ).fetchone()
            if open_order:
                raise ValueError("ORDER_ALREADY_PENDING")
            if payable > 0 and not receipt_id:
                raise ValueError("RECEIPT_REQUIRED")
            if tx and cursor.execute("SELECT id FROM v8_vip_orders WHERE transaction_hash=?", (tx,)).fetchone():
                raise ValueError("TRANSACTION_HASH_ALREADY_USED")

            receipt = None
            if receipt_id:
                receipt_sql = "SELECT * FROM v8_receipts WHERE id=? AND user_id=?"
                if self.engine.dialect.name == "postgres":
                    receipt_sql += " FOR UPDATE"
                receipt = cursor.execute(receipt_sql, (str(receipt_id), uid)).fetchone()
                if not receipt:
                    raise ValueError("RECEIPT_NOT_FOUND")
                if str(receipt.get("order_id") or ""):
                    raise ValueError("RECEIPT_ALREADY_USED")

            order = {
                **(profile or {}),
                "id": order_id,
                "order_id": order_id,
                "user_id": uid,
                "plan_id": quote.get("plan_id"),
                "plan_name": str(quote.get("plan_name") or "VIP"),
                "duration_days": max(1, int(quote.get("duration_days") or 30)),
                "base_price": max(0, int(quote.get("base_price") or payable)),
                "discount_percent": max(0, int(quote.get("discount_percent") or 0)),
                "discount_amount": max(0, int(quote.get("discount_amount") or 0)),
                "coupon": str(quote.get("coupon") or ""),
                "status": ORDER_PENDING,
                "payment_method": method,
                "payment_review_mode": "manual_receipt",
                "manual_review_required": True,
                "amount_toman": payable,
                "price": payable,
                "usdt_amount": float(quote_row.get("usdt_amount") or 0),
                "payment_amount_usdt": str(quote.get("payment_amount_usdt") or quote_row.get("usdt_amount") or ""),
                "payment_network": str(quote.get("payment_network") or ""),
                "payment_wallet": str(quote.get("payment_wallet") or ""),
                "payment_rate_toman": int(round(float(quote.get("payment_rate_toman") or 0))),
                "payment_card_number": str(quote.get("payment_card_number") or ""),
                "payment_card_owner": str(quote.get("payment_card_owner") or ""),
                "quote_id": str(quote_id),
                "transaction_hash": tx,
                "verification_status": "manual_review",
                "verification_verified": False,
                "receipt_key": str(receipt_id or "") or None,
                "receipt_id": str(receipt_id or ""),
                "receipt_attached": bool(receipt_id),
                "created_at": now,
                "updated_at": now,
                "approved_at": None,
                "pricing": quote,
            }
            assert_manual_payment_evidence(order, receipt_attached=bool(receipt_id) if payable > 0 else None)
            cursor.execute(
                """INSERT INTO v8_vip_orders(id,user_id,plan_id,status,payment_method,amount_toman,usdt_amount,
                   quote_id,transaction_hash,receipt_key,created_at,updated_at,approved_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    order_id, uid, str(order.get("plan_id") or "") or None, ORDER_PENDING, method, payable,
                    order["usdt_amount"], str(quote_id), tx, order.get("receipt_key"), now, now, None,
                    json_dump(order),
                ),
            )
            if receipt:
                receipt_payload = json_load(receipt.get("payload"), {}) or {}
                receipt_payload.update({"order_id": order_id, "status": "attached"})
                cursor.execute(
                    "UPDATE v8_receipts SET status='attached',order_id=?,payload=? WHERE id=? AND user_id=? AND order_id IS NULL",
                    (order_id, json_dump(receipt_payload), str(receipt_id), uid),
                )
                if cursor.rowcount != 1:
                    raise ValueError("RECEIPT_ALREADY_USED")
            consumed = {**quote, "status": "consumed", "consumed_at": now, "order_id": order_id}
            cursor.execute(
                "UPDATE v8_checkout_quotes SET status='consumed',consumed_at=?,order_id=?,payload=? WHERE id=? AND user_id=? AND status='active'",
                (now, order_id, json_dump(consumed), str(quote_id), uid),
            )
            if cursor.rowcount != 1:
                raise ValueError("CHECKOUT_QUOTE_ALREADY_CONSUMED")
        return order

    def resubmit_order(
        self,
        user_id: int | str,
        order_id: str | int,
        *,
        receipt_id: str = "",
        transaction_hash: str = "",
    ) -> dict[str, Any]:
        """Atomically attach fresh evidence and return a terminal order to review."""
        uid = str(user_id)
        oid = str(order_id)
        now_dt = datetime.now(UTC)
        now = now_dt.isoformat()
        with self.engine.transaction() as cursor:
            if self.engine.dialect.name == "postgres":
                cursor.execute(
                    "SELECT pg_advisory_xact_lock(hashtextextended(?, 0))",
                    (f"sentinel:vip-order-user:{uid}",),
                )
            order_sql = "SELECT * FROM v8_vip_orders WHERE id=? AND user_id=?"
            if self.engine.dialect.name == "postgres":
                order_sql += " FOR UPDATE"
            row = cursor.execute(order_sql, (oid, uid)).fetchone()
            if not row:
                raise PermissionError("ORDER_NOT_OWNED")
            order = self._decode(row)
            if str(row["status"]) not in RESUBMITTABLE_STATES:
                raise ValueError("ORDER_CANNOT_BE_RESUBMITTED")
            other_open = cursor.execute(
                "SELECT id FROM v8_vip_orders WHERE user_id=? AND id<>? AND status IN ('pending','approving') LIMIT 1",
                (uid, oid),
            ).fetchone()
            if other_open:
                raise ValueError("ORDER_ALREADY_PENDING")

            tx = str(transaction_hash or "").strip() or None
            if tx:
                duplicate = cursor.execute(
                    "SELECT id FROM v8_vip_orders WHERE transaction_hash=? AND id<>?", (tx, oid)
                ).fetchone()
                if duplicate:
                    raise ValueError("TRANSACTION_HASH_ALREADY_USED")

            payable = max(0, int(round(float(row.get("amount_toman") or 0))))
            target_receipt = str(receipt_id or "").strip() or None
            if payable > 0 and not target_receipt:
                raise ValueError("RECEIPT_REQUIRED")

            receipt = None
            if target_receipt:
                receipt_sql = "SELECT * FROM v8_receipts WHERE id=? AND user_id=?"
                if self.engine.dialect.name == "postgres":
                    receipt_sql += " FOR UPDATE"
                receipt = cursor.execute(receipt_sql, (target_receipt, uid)).fetchone()
                if not receipt:
                    raise ValueError("RECEIPT_NOT_FOUND")
                attached_to = str(receipt.get("order_id") or "")
                if attached_to and attached_to != oid:
                    raise ValueError("RECEIPT_ALREADY_USED")

            old_receipt = str(row.get("receipt_key") or "")
            if old_receipt and old_receipt != target_receipt:
                old = cursor.execute("SELECT * FROM v8_receipts WHERE id=? AND user_id=?", (old_receipt, uid)).fetchone()
                if old and str(old.get("order_id") or "") == oid:
                    old_payload = json_load(old.get("payload"), {}) or {}
                    old_payload.update({"status": "replaced", "replaced_at": now})
                    cursor.execute(
                        "UPDATE v8_receipts SET status='replaced',payload=? WHERE id=? AND user_id=? AND order_id=?",
                        (json_dump(old_payload), old_receipt, uid, oid),
                    )

            if receipt and str(receipt.get("order_id") or "") != oid:
                receipt_payload = json_load(receipt.get("payload"), {}) or {}
                receipt_payload.update({"order_id": oid, "status": "attached"})
                cursor.execute(
                    "UPDATE v8_receipts SET status='attached',order_id=?,payload=? WHERE id=? AND user_id=? AND order_id IS NULL",
                    (oid, json_dump(receipt_payload), target_receipt, uid),
                )
                if cursor.rowcount != 1:
                    raise ValueError("RECEIPT_ALREADY_USED")

            assert_transition(str(row["status"]), ORDER_PENDING)
            order.update({
                "status": ORDER_PENDING,
                "receipt_key": target_receipt,
                "receipt_id": target_receipt or "",
                "receipt_attached": bool(target_receipt),
                "transaction_hash": tx,
                "verification_status": "manual_review",
                "verification_verified": False,
                "rejection_reason": "",
                "resubmitted_at": now,
                "updated_at": now,
                "status_changed_by": uid,
            })
            assert_manual_payment_evidence(order, receipt_attached=bool(target_receipt) if payable > 0 else None)
            cursor.execute(
                """UPDATE v8_vip_orders SET status='pending',transaction_hash=?,receipt_key=?,updated_at=?,payload=?
                   WHERE id=? AND user_id=?""",
                (tx, target_receipt, now, json_dump(order), oid, uid),
            )
            if cursor.rowcount != 1:
                raise RuntimeError("ORDER_RESUBMIT_FAILED")
        return order

    def approve_order(self, order_id: str | int, *, actor_id: str) -> dict[str, Any]:
        """Fail closed: approval requires the Telegram invite orchestration path."""
        current = self.get(order_id)
        if current and str(current.get("status")) == ORDER_APPROVED:
            return current
        raise ValueError("APPROVAL_ORCHESTRATION_REQUIRED")

    def claim_order_for_approval(self, order_id: str | int, *, actor_id: str) -> dict[str, Any]:
        oid = str(order_id)
        admin = str(actor_id)
        now_dt = datetime.now(UTC)
        now = now_dt.isoformat()
        lease_seconds = max(60, int(os.getenv("VIP_APPROVAL_LEASE_SECONDS", "300") or 300))
        with self.engine.transaction() as cursor:
            sql = "SELECT * FROM v8_vip_orders WHERE id=?"
            if self.engine.dialect.name == "postgres":
                sql += " FOR UPDATE"
            row = cursor.execute(sql, (oid,)).fetchone()
            if not row:
                raise ValueError("ORDER_NOT_FOUND")
            order = self._decode(row)
            current_status = str(row["status"])
            if current_status == ORDER_APPROVED:
                return order
            if current_status == ORDER_APPROVING:
                if str(order.get("processing_by") or "") == admin:
                    return order
                try:
                    started = datetime.fromisoformat(str(order.get("processing_started_at") or "").replace("Z", "+00:00"))
                    if started.tzinfo is None:
                        started = started.replace(tzinfo=UTC)
                except (TypeError, ValueError):
                    started = datetime.fromtimestamp(0, UTC)
                if started > now_dt - timedelta(seconds=lease_seconds):
                    raise ValueError("ORDER_NOT_PENDING")
                if str(order.get("processing_invite_link") or ""):
                    raise ValueError("ORDER_STALE_APPROVAL_REQUIRES_RECOVERY")
                order.update({
                    "status": ORDER_PENDING,
                    "processing_by": None,
                    "processing_started_at": None,
                    "approval_last_error": "stale approval lease recovered",
                    "approval_last_failed_at": now,
                    "updated_at": now,
                })
                cursor.execute(
                    "UPDATE v8_vip_orders SET status='pending',updated_at=?,payload=? WHERE id=? AND status='approving'",
                    (now, json_dump(order), oid),
                )
                if cursor.rowcount != 1:
                    raise ValueError("ORDER_APPROVAL_CONFLICT")
                current_status = ORDER_PENDING
            if current_status != ORDER_PENDING:
                raise ValueError("ORDER_NOT_PENDING")
            receipt_attached = False
            receipt_key = str(row.get("receipt_key") or "")
            if receipt_key:
                receipt = cursor.execute(
                    "SELECT id,status,order_id FROM v8_receipts WHERE id=? AND user_id=?",
                    (receipt_key, str(row.get("user_id") or "")),
                ).fetchone()
                receipt_attached = bool(
                    receipt and str(receipt.get("order_id") or "") == oid and str(receipt.get("status") or "") == "attached"
                )
            assert_manual_payment_evidence(order, receipt_attached=receipt_attached if int(round(float(row.get("amount_toman") or 0))) > 0 else None)
            assert_transition(ORDER_PENDING, ORDER_APPROVING)
            order.update({
                "status": ORDER_APPROVING,
                "processing_by": admin,
                "processing_started_at": now,
                "approval_last_error": "",
                "updated_at": now,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='approving',updated_at=?,payload=? WHERE id=? AND status='pending'",
                (now, json_dump(order), oid),
            )
            if cursor.rowcount != 1:
                raise ValueError("ORDER_APPROVAL_CONFLICT")
        return order

    def store_order_approval_invite(self, order_id: str | int, *, actor_id: str, invite_link: str) -> dict[str, Any]:
        oid = str(order_id)
        admin = str(actor_id)
        link = str(invite_link or "").strip()
        if not link.startswith(("https://t.me/", "https://telegram.me/", "tg://")):
            raise ValueError("INVITE_LINK_INVALID")
        now = utc_iso()
        with self.engine.transaction() as cursor:
            row = cursor.execute("SELECT * FROM v8_vip_orders WHERE id=?", (oid,)).fetchone()
            if not row:
                raise ValueError("ORDER_NOT_FOUND")
            order = self._decode(row)
            if str(row["status"]) != ORDER_APPROVING or str(order.get("processing_by") or "") != admin:
                raise ValueError("ORDER_APPROVAL_CLAIM_LOST")
            existing = str(order.get("processing_invite_link") or "")
            if existing:
                if existing != link:
                    raise ValueError("ORDER_APPROVAL_INVITE_CONFLICT")
                return order
            order.update({"processing_invite_link": link, "processing_invite_created_at": now, "updated_at": now})
            cursor.execute(
                "UPDATE v8_vip_orders SET updated_at=?,payload=? WHERE id=? AND status='approving'",
                (now, json_dump(order), oid),
            )
            if cursor.rowcount != 1:
                raise ValueError("ORDER_APPROVAL_CLAIM_LOST")
        return order

    def release_order_approval(self, order_id: str | int, *, actor_id: str, error: str) -> dict[str, Any] | None:
        oid = str(order_id)
        admin = str(actor_id)
        now = utc_iso()
        with self.engine.transaction() as cursor:
            row = cursor.execute("SELECT * FROM v8_vip_orders WHERE id=?", (oid,)).fetchone()
            if not row:
                return None
            order = self._decode(row)
            if str(row["status"]) != ORDER_APPROVING or str(order.get("processing_by") or "") != admin:
                return order
            assert_transition(ORDER_APPROVING, ORDER_PENDING)
            order.update({
                "status": ORDER_PENDING,
                "processing_by": None,
                "processing_started_at": None,
                "processing_invite_link": None,
                "processing_invite_created_at": None,
                "approval_last_error": str(error or "approval failed")[:500],
                "approval_last_failed_at": now,
                "updated_at": now,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='pending',updated_at=?,payload=? WHERE id=? AND status='approving'",
                (now, json_dump(order), oid),
            )
        return order

    def finalize_order_approval(
        self,
        order_id: str | int,
        *,
        actor_id: str,
        invite_link: str,
    ) -> dict[str, Any]:
        oid = str(order_id)
        admin = str(actor_id)
        now_dt = datetime.now(UTC)
        now = now_dt.isoformat()
        if not str(invite_link or "").startswith(("https://t.me/", "https://telegram.me/", "tg://")):
            raise ValueError("INVITE_LINK_INVALID")
        with self.engine.transaction() as cursor:
            sql = "SELECT * FROM v8_vip_orders WHERE id=?"
            if self.engine.dialect.name == "postgres":
                sql += " FOR UPDATE"
            row = cursor.execute(sql, (oid,)).fetchone()
            if not row:
                raise ValueError("ORDER_NOT_FOUND")
            order = self._decode(row)
            if str(row["status"]) == ORDER_APPROVED:
                return order
            if str(row["status"]) != ORDER_APPROVING or str(order.get("processing_by") or "") != admin:
                raise ValueError("ORDER_APPROVAL_CLAIM_LOST")
            stored_invite = str(order.get("processing_invite_link") or "")
            if stored_invite and stored_invite != str(invite_link):
                raise ValueError("ORDER_APPROVAL_INVITE_CONFLICT")
            receipt_key = str(row.get("receipt_key") or "")
            receipt_attached = False
            if receipt_key:
                receipt = cursor.execute(
                    "SELECT id,status,order_id FROM v8_receipts WHERE id=? AND user_id=?",
                    (receipt_key, str(row.get("user_id") or "")),
                ).fetchone()
                receipt_attached = bool(
                    receipt and str(receipt.get("order_id") or "") == oid and str(receipt.get("status") or "") == "attached"
                )
            assert_manual_payment_evidence(order, receipt_attached=receipt_attached if int(round(float(row.get("amount_toman") or 0))) > 0 else None)
            assert_transition(ORDER_APPROVING, ORDER_APPROVED)
            expires_at = self._grant_entitlement_in_cursor(cursor, order, now_dt, invite_link=invite_link)
            order.update({
                "status": ORDER_APPROVED,
                "approved_at": now,
                "approved_by": admin,
                "updated_at": now,
                "status_changed_by": admin,
                "processing_by": None,
                "processing_started_at": None,
                "processing_invite_link": None,
                "processing_invite_created_at": None,
                "invite_link": invite_link,
                "expires_at": expires_at,
                "verification_status": "approved_manual",
                "verification_verified": True,
                "manual_reviewed_at": now,
                "manual_reviewed_by": admin,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='approved',updated_at=?,approved_at=?,payload=? WHERE id=? AND status='approving'",
                (now, now, json_dump(order), oid),
            )
            if cursor.rowcount != 1:
                raise ValueError("ORDER_APPROVAL_CONFLICT")
        return order

    def reject_order(self, order_id: str | int, *, actor_id: str, reason: str) -> dict[str, Any]:
        oid = str(order_id)
        admin = str(actor_id)
        clean_reason = str(reason or "").strip()
        if len(clean_reason) < 3:
            raise ValueError("REJECTION_REASON_REQUIRED")
        now = utc_iso()
        with self.engine.transaction() as cursor:
            sql = "SELECT * FROM v8_vip_orders WHERE id=?"
            if self.engine.dialect.name == "postgres":
                sql += " FOR UPDATE"
            row = cursor.execute(sql, (oid,)).fetchone()
            if not row:
                raise ValueError("ORDER_NOT_FOUND")
            order = self._decode(row)
            if str(row["status"]) != ORDER_PENDING:
                raise ValueError("ORDER_NOT_PENDING")
            assert_transition(ORDER_PENDING, ORDER_REJECTED)
            order.update({
                "status": ORDER_REJECTED,
                "rejection_reason": clean_reason[:1000],
                "rejected_at": now,
                "rejected_by": admin,
                "updated_at": now,
                "status_changed_by": admin,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='rejected',updated_at=?,payload=? WHERE id=? AND status='pending'",
                (now, json_dump(order), oid),
            )
            if cursor.rowcount != 1:
                raise ValueError("ORDER_REJECTION_CONFLICT")
        return order

    def recover_stale_approval_claims(self, *, lease_seconds: int | None = None) -> list[dict[str, Any]]:
        """Claim stale approvals for safe recovery.

        Claims without a persisted invite can return to pending immediately. A
        claim with a one-use invite is transferred to a system recovery owner
        and remains ``approving`` until Telegram confirms that the invite was
        revoked. This prevents a second administrator from approving while an
        old access link may still be valid.
        """
        lease = max(60, int(lease_seconds or os.getenv("VIP_APPROVAL_LEASE_SECONDS", "300") or 300))
        now_dt = datetime.now(UTC)
        now = now_dt.isoformat()
        recovery_owner = "system:approval-recovery"
        candidates: list[dict[str, Any]] = []
        with self.engine.transaction() as cursor:
            rows = cursor.execute("SELECT * FROM v8_vip_orders WHERE status='approving'").fetchall()
            for row in rows:
                order = self._decode(row)
                try:
                    started = datetime.fromisoformat(str(order.get("processing_started_at") or "").replace("Z", "+00:00"))
                    if started.tzinfo is None:
                        started = started.replace(tzinfo=UTC)
                except (TypeError, ValueError):
                    started = datetime.fromtimestamp(0, UTC)
                if started > now_dt - timedelta(seconds=lease):
                    continue
                invite = str(order.get("processing_invite_link") or "")
                if not invite:
                    recovered = dict(order)
                    order.update({
                        "status": ORDER_PENDING,
                        "processing_by": None,
                        "processing_started_at": None,
                        "processing_invite_link": None,
                        "processing_invite_created_at": None,
                        "approval_last_error": "stale approval lease recovered",
                        "approval_last_failed_at": now,
                        "updated_at": now,
                    })
                    cursor.execute(
                        "UPDATE v8_vip_orders SET status='pending',updated_at=?,payload=? WHERE id=? AND status='approving'",
                        (now, json_dump(order), str(row["id"])),
                    )
                    if cursor.rowcount == 1:
                        recovered["recovery_completed"] = True
                        candidates.append(recovered)
                    continue

                current_owner = str(order.get("processing_by") or "")
                if current_owner == recovery_owner:
                    # A previous recovery worker crashed. Reclaim only after its
                    # own lease has expired, preserving the invite for retry.
                    pass
                order.update({
                    "recovery_original_processing_by": order.get("recovery_original_processing_by") or current_owner,
                    "processing_by": recovery_owner,
                    "processing_started_at": now,
                    "approval_last_error": "stale invite awaiting Telegram revocation",
                    "updated_at": now,
                })
                cursor.execute(
                    "UPDATE v8_vip_orders SET updated_at=?,payload=? WHERE id=? AND status='approving'",
                    (now, json_dump(order), str(row["id"])),
                )
                if cursor.rowcount == 1:
                    candidate = dict(order)
                    candidate["recovery_completed"] = False
                    candidates.append(candidate)
        return candidates

    def complete_stale_approval_recovery(
        self,
        order_id: str | int,
        *,
        invite_revoked: bool,
        error: str = "",
    ) -> dict[str, Any] | None:
        """Finish a system-owned stale approval recovery after Telegram revoke."""
        oid = str(order_id)
        owner = "system:approval-recovery"
        now = utc_iso()
        with self.engine.transaction() as cursor:
            row = cursor.execute("SELECT * FROM v8_vip_orders WHERE id=?", (oid,)).fetchone()
            if not row:
                return None
            order = self._decode(row)
            if str(row.get("status") or "") != ORDER_APPROVING or str(order.get("processing_by") or "") != owner:
                return order
            if not invite_revoked:
                order.update({
                    "processing_started_at": now,
                    "approval_last_error": str(error or "Telegram invite revocation failed")[:500],
                    "approval_last_failed_at": now,
                    "updated_at": now,
                })
                cursor.execute(
                    "UPDATE v8_vip_orders SET updated_at=?,payload=? WHERE id=? AND status='approving'",
                    (now, json_dump(order), oid),
                )
                return order
            assert_transition(ORDER_APPROVING, ORDER_PENDING)
            order.update({
                "status": ORDER_PENDING,
                "processing_by": None,
                "processing_started_at": None,
                "processing_invite_link": None,
                "processing_invite_created_at": None,
                "recovery_original_processing_by": None,
                "approval_last_error": "stale invite revoked; order returned to review",
                "approval_last_failed_at": now,
                "updated_at": now,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='pending',updated_at=?,payload=? WHERE id=? AND status='approving'",
                (now, json_dump(order), oid),
            )
            if cursor.rowcount != 1:
                raise ValueError("ORDER_APPROVAL_RECOVERY_CONFLICT")
        return order

    def list_entitlements(self, *, user_id: int | str | None = None) -> list[dict[str, Any]]:
        with self.engine.transaction(read_only=True) as cursor:
            if user_id is None:
                rows = cursor.execute("SELECT * FROM v8_vip_entitlements ORDER BY user_id").fetchall()
            else:
                rows = cursor.execute("SELECT * FROM v8_vip_entitlements WHERE user_id=?", (str(user_id),)).fetchall()
        output: list[dict[str, Any]] = []
        now = datetime.now(UTC)
        for row in rows:
            data = json_load(row.get("payload"), {}) or {}
            data.update({key: value for key, value in row.items() if key != "payload"})
            try:
                data["active"] = str(row.get("status")) == "active" and datetime.fromisoformat(str(row["expires_at"]).replace("Z", "+00:00")) > now
            except Exception:
                data["active"] = False
            output.append(data)
        return output

    def entitlement_for_user(self, user_id: int | str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_vip_entitlements WHERE user_id=?", (str(user_id),)).fetchone()
        if not row: return None
        data = json_load(row.get("payload"), {}) or {}; data.update({key: value for key, value in row.items() if key != "payload"})
        try: active = str(row["status"]) == "active" and datetime.fromisoformat(str(row["expires_at"]).replace("Z", "+00:00")) > datetime.now(UTC)
        except Exception: active = False
        data["active"] = active
        return data

    def _grant_entitlement_in_cursor(
        self,
        cursor: Any,
        order: dict[str, Any],
        now_dt: datetime,
        *,
        invite_link: str = "",
    ) -> str:
        uid = str(order["user_id"])
        pricing = order.get("pricing") if isinstance(order.get("pricing"), dict) else {}
        duration_days = max(1, min(int(pricing.get("duration_days") or order.get("duration_days") or 30), 3650))
        current = cursor.execute("SELECT * FROM v8_vip_entitlements WHERE user_id=?", (uid,)).fetchone()
        base = now_dt
        if current and str(current.get("status")) == "active":
            try:
                existing_expiry = datetime.fromisoformat(str(current["expires_at"]).replace("Z", "+00:00"))
                if existing_expiry > base:
                    base = existing_expiry
            except (TypeError, ValueError):
                pass
        expires = base + timedelta(days=duration_days)
        payload = {
            "user_id": uid,
            "plan_id": order.get("plan_id"),
            "order_id": order["id"],
            "status": "active",
            "starts_at": now_dt.isoformat(),
            "expires_at": expires.isoformat(),
            "duration_days": duration_days,
            "invite_link": str(invite_link or ""),
        }
        cursor.execute(
            """INSERT INTO v8_vip_entitlements(user_id,plan_id,order_id,status,starts_at,expires_at,updated_at,payload)
               VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET plan_id=excluded.plan_id,
               order_id=excluded.order_id,status=excluded.status,starts_at=excluded.starts_at,
               expires_at=excluded.expires_at,updated_at=excluded.updated_at,payload=excluded.payload""",
            (
                uid, str(order.get("plan_id") or "") or None, order["id"], "active", now_dt.isoformat(),
                expires.isoformat(), now_dt.isoformat(), json_dump(payload),
            ),
        )
        return expires.isoformat()

    def create_order(self, user_id: int | str, payload: dict[str, Any]) -> dict[str, Any]:
        now = utc_iso()
        order = {
            **payload,
            "id": str(payload.get("id") or new_id("ord")),
            "user_id": str(user_id),
            "status": str(payload.get("status") or "pending"),
            "payment_method": str(payload.get("payment_method") or ""),
            "amount_toman": float(payload.get("amount_toman") or payload.get("payable_toman") or 0),
            "usdt_amount": float(payload.get("usdt_amount") or 0),
            "created_at": str(payload.get("created_at") or now),
            "updated_at": now,
        }
        tx = str(order.get("transaction_hash") or "").strip() or None
        with self.engine.transaction() as cursor:
            if tx:
                duplicate = cursor.execute("SELECT id FROM v8_vip_orders WHERE transaction_hash=?", (tx,)).fetchone()
                if duplicate:
                    raise ValueError("TRANSACTION_HASH_ALREADY_USED")
            cursor.execute(
                """INSERT INTO v8_vip_orders(id,user_id,plan_id,status,payment_method,amount_toman,usdt_amount,
                   quote_id,transaction_hash,receipt_key,created_at,updated_at,approved_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (order["id"],order["user_id"],str(order.get("plan_id") or "") or None,order["status"],
                 order["payment_method"],order["amount_toman"],order["usdt_amount"],str(order.get("quote_id") or "") or None,
                 tx,str(order.get("receipt_key") or order.get("receipt_id") or "") or None,order["created_at"],now,
                 order.get("approved_at"),json_dump(order)),
            )
        return order

    def update_status(self, order_id: str | int, *, status: str, actor_id: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        target = str(status or "").strip().lower()
        if target == ORDER_REJECTED:
            return self.reject_order(order_id, actor_id=actor_id, reason=str((payload or {}).get("rejection_reason") or ""))
        if target != ORDER_CANCELLED:
            raise ValueError("ORDER_STATUS_UPDATE_FORBIDDEN")
        oid = str(order_id)
        now = utc_iso()
        with self.engine.transaction() as cursor:
            sql = "SELECT * FROM v8_vip_orders WHERE id=?"
            if self.engine.dialect.name == "postgres":
                sql += " FOR UPDATE"
            row = cursor.execute(sql, (oid,)).fetchone()
            if not row:
                raise ValueError("ORDER_NOT_FOUND")
            order = self._decode(row)
            if str(row["status"]) not in {ORDER_PENDING, ORDER_NEEDS_RECEIPT}:
                raise ValueError("ORDER_CANNOT_BE_CANCELLED")
            assert_transition(str(row["status"]), ORDER_CANCELLED)
            order.update({
                **(payload or {}),
                "status": ORDER_CANCELLED,
                "updated_at": now,
                "status_changed_by": str(actor_id),
                "cancelled_at": now,
            })
            cursor.execute(
                "UPDATE v8_vip_orders SET status='cancelled',updated_at=?,payload=? WHERE id=?",
                (now, json_dump(order), oid),
            )
        return order

    def get(self, order_id: str | int, *, user_id: int | str | None = None) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            if user_id is None:
                row = cursor.execute("SELECT * FROM v8_vip_orders WHERE id=?", (str(order_id),)).fetchone()
            else:
                row = cursor.execute("SELECT * FROM v8_vip_orders WHERE id=? AND user_id=?", (str(order_id),str(user_id))).fetchone()
        return self._decode(row) if row else None

    def list_for_user(self, user_id: int | str, *, cursor: str | None = None, limit: int = 30, status: str = "") -> dict[str, Any]:
        size = max(1,min(int(limit or 30),100)); clauses=["user_id=?"]; params:list[Any]=[str(user_id)]
        if status: clauses.append("status=?"); params.append(str(status))
        decoded=decode_cursor(cursor)
        if decoded:
            clauses.append("(created_at < ? OR (created_at = ? AND id < ?))"); params.extend([decoded[0],decoded[0],decoded[1]])
        params.append(size+1)
        with self.engine.transaction(read_only=True) as db:
            rows=db.execute(f"SELECT * FROM v8_vip_orders WHERE {' AND '.join(clauses)} ORDER BY created_at DESC,id DESC LIMIT ?",params).fetchall()  # nosec B608
        more=len(rows)>size; rows=rows[:size]; items=[self._decode(row) for row in rows]
        nxt=encode_cursor(str(rows[-1]["created_at"]),str(rows[-1]["id"])) if more and rows else None
        return {"items":items,"next_cursor":nxt,"limit":size}


    def get_receipt_admin(self, receipt_id: str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_receipts WHERE id=?", (str(receipt_id),)).fetchone()
        return self._decode_receipt(row) if row else None

    def list_all_orders(self, *, cursor: str | None = None, limit: int = 50, status: str = "", query: str = "") -> dict[str, Any]:
        size = max(1, min(int(limit or 50), 100))
        clauses = ["1=1"]
        params: list[Any] = []
        if status:
            clauses.append("status=?")
            params.append(str(status))
        needle = str(query or "").strip()
        if needle:
            like = f"%{needle}%"
            clauses.append("(id LIKE ? OR user_id LIKE ? OR COALESCE(plan_id,'') LIKE ? OR COALESCE(transaction_hash,'') LIKE ?)")
            params.extend([like, like, like, like])
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(created_at < ? OR (created_at = ? AND id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(
                f"SELECT * FROM v8_vip_orders WHERE {' AND '.join(clauses)} ORDER BY created_at DESC,id DESC LIMIT ?",  # nosec B608
                params,
            ).fetchall()
        more = len(rows) > size
        rows = rows[:size]
        items = [self._decode(row) for row in rows]
        next_cursor = encode_cursor(str(rows[-1]["created_at"]), str(rows[-1]["id"])) if more and rows else None
        return {"items": items, "next_cursor": next_cursor, "limit": size}

    def approved_sales_count(self, plan_id: str | int | None = None) -> int:
        with self.engine.transaction(read_only=True) as cursor:
            if plan_id is None:
                row=cursor.execute("SELECT COUNT(*) AS count FROM v8_vip_orders WHERE status='approved'").fetchone()
            else:
                row=cursor.execute("SELECT COUNT(*) AS count FROM v8_vip_orders WHERE status='approved' AND plan_id=?",(str(plan_id),)).fetchone()
        return int((row or {}).get("count") or 0)

    @staticmethod
    def _decode(row: dict[str, Any]) -> dict[str, Any]:
        data=json_load(row.get("payload"),{}) or {}
        data.update({k:row.get(k) for k in row if k!="payload"})
        data["amount_toman"] = int(round(float(row.get("amount_toman") or 0)))
        data["price"] = data["amount_toman"]
        data["usdt_amount"] = float(row.get("usdt_amount") or 0)
        data.setdefault("order_id", str(row.get("id") or ""))
        return data
