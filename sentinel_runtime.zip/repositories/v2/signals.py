from __future__ import annotations

from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import content_hash, decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso
from modules.signal_status import normalize_signal_status, signal_is_final, signal_status_rank


class SignalRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def upsert(self, signal: dict[str, Any]) -> dict[str, Any]:
        signal_id = str(signal.get("id") or "").strip()
        if not signal_id:
            raise ValueError("SIGNAL_ID_REQUIRED")
        now = utc_iso()
        with self.engine.transaction() as cursor:
            previous_db = cursor.execute("SELECT payload FROM v8_signals WHERE id=?", (signal_id,)).fetchone()
            previous = json_load(previous_db.get("payload"), {}) if previous_db else None
            previous = previous if isinstance(previous, dict) else None

            created = str(signal.get("created_at") or (previous or {}).get("created_at") or now)
            # A retry without an explicit source update timestamp must remain
            # semantically identical; otherwise every retry creates a fake
            # revision solely because the server clock changed.
            explicit_updated = signal.get("updated_at") or signal.get("result_updated_at")
            updated = str(explicit_updated or (previous or {}).get("updated_at") or created)
            raw_number = signal.get("display_number") or signal.get("number")
            display_number = int(raw_number or (signal_id if signal_id.isdigit() else 0))
            row = {
                **(previous or {}),
                **signal,
                "id": signal_id,
                "display_number": display_number,
                "symbol": str(signal.get("symbol") or (previous or {}).get("symbol") or "").upper().replace("/", ""),
                "side": str(signal.get("side") or signal.get("direction") or (previous or {}).get("side") or "").upper(),
                "status": normalize_signal_status(signal.get("status") or (previous or {}).get("status") or "open"),
                "market_category": str(signal.get("market_category") or signal.get("market") or (previous or {}).get("market_category") or ""),
                "created_at": created,
                "updated_at": updated,
            }
            previous_hash = content_hash(previous) if previous is not None else ""
            current_hash = content_hash(row)
            if previous_hash == current_hash:
                row["revision"] = self._revision_count_in_cursor(cursor, signal_id)
                return row

            cursor.execute(
                """INSERT INTO v8_signals(id,display_number,symbol,side,status,market_category,created_at,updated_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET display_number=excluded.display_number,symbol=excluded.symbol,
                   side=excluded.side,status=excluded.status,market_category=excluded.market_category,
                   updated_at=excluded.updated_at,payload=excluded.payload""",
                (signal_id,row["display_number"],row["symbol"],row["side"],row["status"],row["market_category"],
                 created,updated,json_dump(row)),
            )
            revision = self._revision_count_in_cursor(cursor, signal_id) + 1
            keys = sorted(set((previous or {}).keys()) | set(row.keys()))
            changed = [key for key in keys if (previous or {}).get(key) != row.get(key)]
            revision_payload = {
                "signal_id": signal_id, "revision": revision, "changed_at": updated,
                "change_type": "created" if previous is None else "updated", "changed_fields": changed,
                "before": previous, "after": row, "previous_hash": previous_hash or None, "current_hash": current_hash,
            }
            cursor.execute(
                """INSERT INTO v8_signal_revisions(id,signal_id,revision_number,changed_at,changed_by,change_type,
                   previous_hash,current_hash,changed_fields,payload) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (new_id("rev"), signal_id, revision, updated, str(signal.get("updated_by") or signal.get("admin_id") or "") or None,
                 revision_payload["change_type"], previous_hash or None, current_hash, json_dump(changed), json_dump(revision_payload)),
            )
            if signal_is_final(row):
                result_payload = {
                    "signal_id": signal_id, "status": row["status"],
                    "result_r": row.get("result_r", row.get("r_multiple")),
                    "result_pips": row.get("result_pips", row.get("pips")), "drawdown_r": row.get("drawdown_r"),
                    "closed_at": row.get("closed_at") or updated, "signal_hash": current_hash,
                    "evidence": row.get("evidence") or row.get("result_evidence") or {},
                }
                evidence_hash = content_hash(result_payload)
                result_payload["evidence_hash"] = evidence_hash
                cursor.execute(
                    """INSERT INTO v8_signal_outcomes(signal_id,status,result_r,result_pips,drawdown_r,closed_at,evidence_hash,payload)
                       VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(signal_id) DO UPDATE SET status=excluded.status,
                       result_r=excluded.result_r,result_pips=excluded.result_pips,drawdown_r=excluded.drawdown_r,
                       closed_at=excluded.closed_at,evidence_hash=excluded.evidence_hash,payload=excluded.payload""",
                    (signal_id, row["status"], self._float_or_none(result_payload["result_r"]),
                     self._float_or_none(result_payload["result_pips"]), self._float_or_none(result_payload["drawdown_r"]),
                     str(result_payload["closed_at"]), evidence_hash, json_dump(result_payload)),
                )
            row["revision"] = revision
            return row

    @staticmethod
    def _revision_count_in_cursor(cursor: Any, signal_id: str) -> int:
        result = cursor.execute(
            "SELECT COUNT(*) AS total FROM v8_signal_revisions WHERE signal_id=?", (signal_id,)
        ).fetchone() or {}
        return int(result.get("total") or 0)

    def get(self, signal_id: str | int) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_signals WHERE id=?", (str(signal_id),)).fetchone()
        return self._decode(row) if row else None

    def delete(self, signal_id: str | int) -> bool:
        """Delete a signal and its normalized dependent records atomically.

        The schema intentionally keeps explicit foreign keys without database-
        specific cascade clauses.  Deleting dependants first prevents SQLite
        and PostgreSQL from rejecting an otherwise valid administrative delete.
        """
        target = str(signal_id)
        with self.engine.transaction() as cursor:
            exists = cursor.execute("SELECT id FROM v8_signals WHERE id=?", (target,)).fetchone()
            if not exists:
                return False
            cursor.execute("DELETE FROM v8_signal_outcomes WHERE signal_id=?", (target,))
            cursor.execute("DELETE FROM v8_signal_revisions WHERE signal_id=?", (target,))
            cursor.execute("DELETE FROM v8_signals WHERE id=?", (target,))
            return cursor.rowcount > 0

    def list(self, *, cursor: str | None = None, limit: int = 30, symbol: str = "", status: str = "",
             market: str = "", search: str = "") -> dict[str, Any]:
        size = max(1, min(int(limit or 30), 100))
        clauses = ["1=1"]
        params: list[Any] = []
        if symbol:
            clauses.append("symbol=?")
            params.append(str(symbol).upper().replace("/", ""))
        if status:
            clean_status = normalize_signal_status(status)
            if clean_status == "active":
                clauses.append("status NOT IN ('closed','stopped','win','loss','cancelled','expired','manual_close','no_entry')")
            else:
                clauses.append("status=?")
                params.append(clean_status)
        if market:
            clauses.append("market_category=?")
            params.append(str(market))
        if search:
            clean = f"%{str(search).strip().upper()}%"
            clauses.append("(UPPER(symbol) LIKE ? OR CAST(display_number AS TEXT) LIKE ?)")
            params.extend([clean, clean])
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(created_at < ? OR (created_at = ? AND id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(
                f"SELECT * FROM v8_signals WHERE {' AND '.join(clauses)} ORDER BY created_at DESC,id DESC LIMIT ?",  # nosec B608
                params,
            ).fetchall()
        has_more = len(rows) > size
        rows = rows[:size]
        # Preserve the database keyset order. Reordering inside a page breaks
        # cursor pagination and can create apparent gaps/duplicates. Higher-level
        # read services may group active/final signals after collecting pages.
        items = [self._decode(row) for row in rows]
        next_cursor = encode_cursor(str(rows[-1]["created_at"]), str(rows[-1]["id"])) if has_more and rows else None
        return {"items": items, "next_cursor": next_cursor, "limit": size}

    def revision_count(self, signal_id: str | int) -> int:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT COUNT(*) AS total FROM v8_signal_revisions WHERE signal_id=?", (str(signal_id),)).fetchone() or {}
        return int(row.get("total") or 0)

    def revisions(self, signal_id: str | int | None = None, *, cursor: str | None = None, limit: int = 50) -> dict[str, Any]:
        size = max(1, min(int(limit or 50), 100))
        clauses: list[str] = []
        params: list[Any] = []
        if signal_id is not None:
            clauses.append("signal_id=?")
            params.append(str(signal_id))
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(changed_at < ? OR (changed_at = ? AND id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(
                f"SELECT * FROM v8_signal_revisions{where} ORDER BY changed_at DESC,id DESC LIMIT ?",  # nosec B608
                params,
            ).fetchall()
        more = len(rows) > size
        rows = rows[:size]
        items: list[dict[str, Any]] = []
        for db_row in rows:
            data = json_load(db_row.get("payload"), {}) or {}
            data.update({key: value for key, value in db_row.items() if key != "payload"})
            data["changed_fields"] = json_load(db_row.get("changed_fields"), []) or []
            items.append(data)
        next_cursor = encode_cursor(str(rows[-1]["changed_at"]), str(rows[-1]["id"])) if more and rows else None
        return {"items": items, "next_cursor": next_cursor, "limit": size}

    def replay(self, signal_id: str | int) -> dict[str, Any]:
        signal = self.get(signal_id)
        if not signal:
            raise ValueError("SIGNAL_NOT_FOUND")
        revisions = self.revisions(signal_id, limit=100)
        ordered = sorted(revisions["items"], key=lambda item: int(item.get("revision_number") or item.get("revision") or 0))
        with self.engine.transaction(read_only=True) as cursor:
            outcome_row = cursor.execute("SELECT * FROM v8_signal_outcomes WHERE signal_id=?", (str(signal_id),)).fetchone()
        outcome = None
        if outcome_row:
            outcome = json_load(outcome_row.get("payload"), {}) or {}
            outcome.update({key: value for key, value in outcome_row.items() if key != "payload"})
        return {"signal": signal, "timeline": ordered, "outcome": outcome, "revision_count": len(ordered)}

    def track_record(self, *, cursor: str | None = None, limit: int = 30, symbol: str = "", market: str = "") -> dict[str, Any]:
        size = max(1, min(int(limit or 30), 100))
        clauses = ["1=1"]
        params: list[Any] = []
        if symbol:
            clauses.append("s.symbol=?")
            params.append(str(symbol).upper().replace("/", ""))
        if market:
            clauses.append("s.market_category=?")
            params.append(str(market))
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(o.closed_at < ? OR (o.closed_at = ? AND o.signal_id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(
                f"""SELECT o.*,s.display_number,s.symbol,s.side,s.market_category,s.created_at,s.updated_at
                    FROM v8_signal_outcomes o JOIN v8_signals s ON s.id=o.signal_id
                    WHERE {' AND '.join(clauses)} ORDER BY o.closed_at DESC,o.signal_id DESC LIMIT ?""",  # nosec B608
                params,
            ).fetchall()
            summary = db.execute(
                """SELECT COUNT(*) AS sample_size,
                   SUM(CASE WHEN status IN ('tp','win') OR COALESCE(result_r,0)>0 THEN 1 ELSE 0 END) AS wins,
                   SUM(CASE WHEN status IN ('stopped','loss') OR COALESCE(result_r,0)<0 THEN 1 ELSE 0 END) AS losses,
                   COALESCE(AVG(result_r),0) AS average_r,
                   COALESCE(MIN(result_r),0) AS worst_r,
                   COALESCE(MAX(result_r),0) AS best_r
                   FROM v8_signal_outcomes"""
            ).fetchone() or {}
        more = len(rows) > size
        rows = rows[:size]
        items: list[dict[str, Any]] = []
        for db_row in rows:
            data = json_load(db_row.get("payload"), {}) or {}
            data.update({key: value for key, value in db_row.items() if key != "payload"})
            items.append(data)
        next_cursor = encode_cursor(str(rows[-1]["closed_at"]), str(rows[-1]["signal_id"])) if more and rows else None
        sample = int(summary.get("sample_size") or 0)
        wins = int(summary.get("wins") or 0)
        return {
            "items": items, "next_cursor": next_cursor, "limit": size,
            "summary": {
                "sample_size": sample, "wins": wins, "losses": int(summary.get("losses") or 0),
                "win_rate": round(wins / sample * 100, 2) if sample else 0.0,
                "average_r": float(summary.get("average_r") or 0),
                "best_r": float(summary.get("best_r") or 0), "worst_r": float(summary.get("worst_r") or 0),
            },
        }

    @staticmethod
    def _float_or_none(value: Any) -> float | None:
        if value in (None, ""):
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _decode(row: dict[str, Any]) -> dict[str, Any]:
        data = json_load(row.get("payload"), {}) or {}
        data.update({
            "id": str(row["id"]), "display_number": int(row["display_number"]), "symbol": row["symbol"],
            "side": row["side"], "status": row["status"], "market_category": row["market_category"],
            "created_at": str(row["created_at"]), "updated_at": str(row["updated_at"]),
        })
        return data
