from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import time
from dataclasses import dataclass
from threading import RLock
from typing import Any

from config import SETTINGS

logger = logging.getLogger(__name__)
_REDIS: Any = None
_DISABLED_UNTIL = 0.0
_LOCK = RLock()
_LOCAL: dict[str, tuple[float, dict[str, Any]]] = {}


@dataclass(frozen=True)
class Reservation:
    state: str
    token: str = ""
    response: dict[str, Any] | None = None


def _client() -> Any:
    global _REDIS, _DISABLED_UNTIL
    if not SETTINGS.redis_url or time.monotonic() < _DISABLED_UNTIL:
        return None
    if _REDIS is not None:
        return _REDIS
    try:
        import redis

        timeout = max(0.2, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "1.5") or 1.5))
        _REDIS = redis.Redis.from_url(
            SETTINGS.redis_url,
            decode_responses=True,
            socket_connect_timeout=timeout,
            socket_timeout=timeout,
            health_check_interval=30,
            max_connections=max(2, int(os.getenv("REDIS_MAX_CONNECTIONS", "30") or 30)),
            retry_on_timeout=True,
        )
        _REDIS.ping()
        return _REDIS
    except Exception as exc:  # pragma: no cover - external service
        _REDIS = None
        _DISABLED_UNTIL = time.monotonic() + 60
        logger.warning("Redis idempotency unavailable; using transactional fallback: %s", exc.__class__.__name__)
        return None


def _key(user_id: int | str, request_id: str) -> str:
    digest = hashlib.sha256(f"{user_id}:{request_id}".encode("utf-8")).hexdigest()
    return f"sentinel:idem:{digest}"


def _decode(raw: str | bytes | None) -> dict[str, Any] | None:
    if not raw:
        return None
    try:
        value = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def reserve(
    user_id: int | str,
    request_id: str,
    *,
    action: str,
    fingerprint: str,
    ttl_seconds: int = 86_400,
) -> Reservation:
    """Reserve an idempotency key across replicas.

    Redis is a fast coordination layer. The canonical transactional record is
    still written alongside the business mutation, so a Redis outage cannot
    silently permit conflicting payloads.
    """
    if not request_id:
        return Reservation("disabled")
    token = secrets.token_urlsafe(18)
    payload = {
        "state": "pending",
        "token": token,
        "action": action,
        "fingerprint": fingerprint,
        "created_at": int(time.time()),
    }
    ttl = max(60, min(int(ttl_seconds), 7 * 86_400))
    client = _client()
    if client is not None:
        key = _key(user_id, request_id)
        try:
            if client.set(key, json.dumps(payload, separators=(",", ":")), nx=True, ex=ttl):
                return Reservation("new", token=token)
            existing = _decode(client.get(key)) or {}
            if existing.get("action") != action or existing.get("fingerprint") != fingerprint:
                return Reservation("conflict")
            if existing.get("state") == "done" and isinstance(existing.get("response"), dict):
                return Reservation("replay", response=dict(existing["response"]))
            return Reservation("in_progress")
        except Exception as exc:  # pragma: no cover - external service
            logger.warning("Redis idempotency reserve failed: %s", exc.__class__.__name__)
    # Local coordination is only an optimization. The database transaction is
    # authoritative and shared when PostgreSQL is configured.
    key = _key(user_id, request_id)
    now = time.monotonic()
    with _LOCK:
        for stale, (expires, _value) in list(_LOCAL.items()):
            if expires <= now:
                _LOCAL.pop(stale, None)
        existing = _LOCAL.get(key)
        if existing:
            value = existing[1]
            if value.get("action") != action or value.get("fingerprint") != fingerprint:
                return Reservation("conflict")
            if value.get("state") == "done" and isinstance(value.get("response"), dict):
                return Reservation("replay", response=dict(value["response"]))
            return Reservation("in_progress")
        _LOCAL[key] = (now + ttl, payload)
    return Reservation("new", token=token)


def complete(
    user_id: int | str,
    request_id: str,
    *,
    action: str,
    fingerprint: str,
    token: str,
    response: dict[str, Any],
    ttl_seconds: int = 86_400,
) -> None:
    if not request_id:
        return
    value = {
        "state": "done",
        "token": token,
        "action": action,
        "fingerprint": fingerprint,
        "response": response,
        "completed_at": int(time.time()),
    }
    ttl = max(60, min(int(ttl_seconds), 7 * 86_400))
    key = _key(user_id, request_id)
    client = _client()
    if client is not None:
        try:
            current = _decode(client.get(key)) or {}
            if current.get("token") == token or current.get("state") == "done":
                client.set(key, json.dumps(value, separators=(",", ":"), default=str), ex=ttl)
                return
        except Exception as exc:  # pragma: no cover - external service
            logger.warning("Redis idempotency completion failed: %s", exc.__class__.__name__)
    with _LOCK:
        current = _LOCAL.get(key)
        if not current or current[1].get("token") == token:
            _LOCAL[key] = (time.monotonic() + ttl, value)


def abort(user_id: int | str, request_id: str, *, token: str) -> None:
    if not request_id or not token:
        return
    key = _key(user_id, request_id)
    client = _client()
    if client is not None:
        try:
            current = _decode(client.get(key)) or {}
            if current.get("state") == "pending" and current.get("token") == token:
                client.delete(key)
        except Exception as exc:  # pragma: no cover - external service
            logger.debug("Redis idempotency abort failed: %s", exc.__class__.__name__)
    with _LOCK:
        current = _LOCAL.get(key)
        if current and current[1].get("state") == "pending" and current[1].get("token") == token:
            _LOCAL.pop(key, None)


def backend_status() -> dict[str, Any]:
    return {
        "backend": "redis" if _client() is not None else "transactional",
        "redis_configured": bool(SETTINGS.redis_url),
        "local_reservations": len(_LOCAL),
    }


def reset_for_tests() -> None:
    global _REDIS, _DISABLED_UNTIL
    with _LOCK:
        _LOCAL.clear()
    _REDIS = None
    _DISABLED_UNTIL = 0.0
