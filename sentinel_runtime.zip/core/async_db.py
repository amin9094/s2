from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from core.async_runtime import run_blocking
from core.db import (
    database_catalog,
    query_db_records,
    read_db_record,
    read_db_section,
    snapshot,
    upsert_db_record,
    with_db,
    with_db_section,
    with_db_sections,
)

T = TypeVar("T")


async def async_snapshot() -> dict[str, Any]:
    """Read an isolated database snapshot without blocking Telegram's event loop."""
    return await run_blocking(snapshot)


async def async_with_db(fn: Callable[[dict[str, Any]], T]) -> T:
    """Execute a transactional mutation in a worker thread.

    The canonical database lock still serializes commits, while unrelated Telegram
    updates and network calls remain responsive.
    """
    return await run_blocking(with_db, fn)


async def async_read_db_section(section_key: str) -> Any:
    return await run_blocking(read_db_section, section_key)


async def async_read_db_record(section_key: str, record_key: int | str) -> Any | None:
    return await run_blocking(read_db_record, section_key, record_key)


async def async_upsert_db_record(section_key: str, record_key: int | str, payload: Any) -> Any:
    return await run_blocking(upsert_db_record, section_key, record_key, payload)


async def async_with_db_section(section_key: str, fn: Callable[[Any], T]) -> T:
    return await run_blocking(with_db_section, section_key, fn)


async def async_with_db_sections(section_keys: tuple[str, ...] | list[str], fn: Callable[[dict[str, Any]], T]) -> T:
    return await run_blocking(with_db_sections, section_keys, fn)


async def async_query_db_records(
    section_key: str,
    *,
    user_id: int | str | None = None,
    status: str | None = None,
    limit: int = 100,
    newest_first: bool = True,
) -> list[Any]:
    return await run_blocking(
        query_db_records,
        section_key,
        user_id=user_id,
        status=status,
        limit=limit,
        newest_first=newest_first,
    )


async def async_database_catalog() -> dict[str, Any]:
    return await run_blocking(database_catalog)
