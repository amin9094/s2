from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
from dataclasses import dataclass
from threading import RLock
from typing import Any

from config import SETTINGS
from core.runtime_topology import replica_count

LOGGER = logging.getLogger(__name__)
_LOCK = RLock()
_LOCAL: dict[str, tuple[int, float]] = {}
_REDIS_CLIENT: Any | None = None
_REDIS_CLIENT_LOCK: asyncio.Lock | None = None
_REDIS_CLIENT_LOOP: Any | None = None
_REDIS_SCRIPT_ACQUIRE = """
local current = tonumber(redis.call('GET', KEYS[1]) or '0')
if current >= tonumber(ARGV[1]) then return 0 end
current = redis.call('INCR', KEYS[1])
redis.call('EXPIRE', KEYS[1], tonumber(ARGV[2]))
return current
"""
_REDIS_SCRIPT_RELEASE = """
local current = tonumber(redis.call('GET', KEYS[1]) or '0')
if current <= 1 then redis.call('DEL', KEYS[1]); return 0 end
return redis.call('DECR', KEYS[1])
"""


def _key(scope: str, value: str) -> str:
    digest = hashlib.sha256(value.encode()).hexdigest()[:32]
    return f"sentinel:connections:{scope}:{digest}"


async def _redis() -> Any | None:
    global _REDIS_CLIENT, _REDIS_CLIENT_LOCK, _REDIS_CLIENT_LOOP
    if not SETTINGS.redis_url:
        return None
    loop = asyncio.get_running_loop()
    if _REDIS_CLIENT_LOCK is None or _REDIS_CLIENT_LOOP is not loop:
        _REDIS_CLIENT_LOCK = asyncio.Lock()
        _REDIS_CLIENT_LOOP = loop
    async with _REDIS_CLIENT_LOCK:
        if _REDIS_CLIENT is not None:
            return _REDIS_CLIENT
        try:
            import redis.asyncio as redis
            _REDIS_CLIENT = redis.Redis.from_url(
                SETTINGS.redis_url,
                decode_responses=True,
                socket_connect_timeout=1.5,
                socket_timeout=2.0,
                health_check_interval=30,
                max_connections=max(8, int(os.getenv("REDIS_MAX_CONNECTIONS", "64") or 64)),
            )
            return _REDIS_CLIENT
        except Exception:
            _REDIS_CLIENT = None
            return None


async def _discard_redis(client: Any) -> None:
    global _REDIS_CLIENT
    if client is _REDIS_CLIENT:
        _REDIS_CLIENT = None
    try:
        await client.aclose()
    except Exception:
        LOGGER.debug("Redis connection-limit client close failed", exc_info=True)


async def close_connection_limit_client() -> None:
    global _REDIS_CLIENT
    client, _REDIS_CLIENT = _REDIS_CLIENT, None
    if client is not None:
        try:
            await client.aclose()
        except Exception:
            LOGGER.debug("Redis connection-limit client close during shutdown failed", exc_info=True)


@dataclass
class ConnectionLease:
    keys: tuple[str, ...]
    redis_client: Any | None = None
    released: bool = False

    async def release(self) -> None:
        if self.released:
            return
        self.released = True
        if self.redis_client is not None:
            for key in self.keys:
                try:
                    await self.redis_client.eval(_REDIS_SCRIPT_RELEASE, 1, key)
                except Exception:
                    LOGGER.debug("Redis connection-limit release failed for %s", key, exc_info=True)
            return
        now = time.monotonic()
        with _LOCK:
            for key in self.keys:
                current, expiry = _LOCAL.get(key, (0, now))
                if current <= 1 or expiry <= now:
                    _LOCAL.pop(key, None)
                else:
                    _LOCAL[key] = (current - 1, expiry)


async def acquire_connection_limits(limits: tuple[tuple[str, str, int], ...], *, ttl_seconds: int = 90) -> ConnectionLease | None:
    """Atomically-ish acquire bounded connection counters.

    Redis makes limits shared across replicas. The local fallback is bounded and
    used only for development or explicitly allowed single-replica staging.
    """
    normalized = tuple((_key(scope, value), max(1, int(limit))) for scope, value, limit in limits)
    client = await _redis()
    acquired: list[str] = []
    if client is not None:
        try:
            for key, limit in normalized:
                result = int(await client.eval(_REDIS_SCRIPT_ACQUIRE, 1, key, limit, max(10, ttl_seconds)))
                if result <= 0:
                    for previous in acquired:
                        await client.eval(_REDIS_SCRIPT_RELEASE, 1, previous)
                    return None
                acquired.append(key)
            return ConnectionLease(tuple(acquired), redis_client=client)
        except Exception:
            for previous in acquired:
                try:
                    await client.eval(_REDIS_SCRIPT_RELEASE, 1, previous)
                except Exception:
                    LOGGER.debug("Redis connection-limit rollback failed for %s", previous, exc_info=True)
            await _discard_redis(client)
            replicas = replica_count()
            if (
                os.getenv("RAILWAY_PROJECT_ID")
                and replicas > 1
                and os.getenv("ALLOW_LOCAL_RATE_LIMIT", "false").lower()
                not in {"1", "true", "yes", "on"}
            ):
                return None
    now = time.monotonic()
    with _LOCK:
        for key, _ in normalized:
            current, expiry = _LOCAL.get(key, (0, now))
            if expiry <= now:
                _LOCAL.pop(key, None)
        for key, limit in normalized:
            current, _ = _LOCAL.get(key, (0, now + ttl_seconds))
            if current >= limit:
                return None
        for key, _ in normalized:
            current, _ = _LOCAL.get(key, (0, now + ttl_seconds))
            _LOCAL[key] = (current + 1, now + ttl_seconds)
    return ConnectionLease(tuple(key for key, _ in normalized))


def reset_connection_limits_for_tests() -> None:
    global _REDIS_CLIENT
    _REDIS_CLIENT = None
    with _LOCK:
        _LOCAL.clear()
