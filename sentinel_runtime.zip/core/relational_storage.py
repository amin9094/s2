from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

RELATIONAL_STORAGE_VERSION = 1

# Every non-user section is routed to one explicit domain table. The table
# names are fixed constants (never derived from user input), which keeps the
# SQL layer safe and makes operations/backups easy to inspect.
DOMAIN_TABLES: dict[str, str] = {
    "commerce": "commerce_records",
    "signals": "signal_records",
    "crm": "crm_records",
    "market": "market_records",
    "channels": "channel_records",
    "content": "content_records",
    "support": "support_records",
    "security": "security_records",
    "system": "system_records",
}

USER_ACCOUNT_SECTION = "users"
USER_PROFILE_SECTION = "user_profiles"
USER_MEMBERSHIP_SECTION = "vip_users"
USER_BALANCE_SECTIONS = {"user_points", "affiliate_balances"}
USER_PREFERENCE_SECTIONS = {
    "user_notification_preferences",
    "economic_calendar_preferences",
    "user_watchlists",
    "personal_risk_profiles",
    "rules_acceptances",
    "trading_accounts",
    "behavioral_insights",
    "miniapp_onboarding",
}
USER_RECORD_SECTIONS = {
    "user_referrals",
    "user_rewards",
    "user_missions",
    "user_signal_choices",
    "user_activity",
    "point_history",
    "education_access",
    "trade_journal",
    "journal_admin_notes",
    "privacy_requests",
    "user_bans",
    "discount_security",
    "public_channel_attribution_users",
    "user_positions",
    "position_audit",
    "signal_revision_acknowledgements",
}

COMMERCE_SECTIONS = {
    "vip_settings",
    "vip_orders",
    "education_orders",
    "discount_codes",
    "discount_history",
    "discount_events",
    "discount_security_settings",
    "affiliate_commissions",
    "reward_requests",
    "payment_reconciliations",
    "payment_reconciliation_settings",
    "checkout_quotes",
    "receipt_uploads",
}
SIGNAL_SECTIONS = {
    "signals",
    "signal_archive",
    "signal_cycle",
    "scheduled_signals",
    "signal_approvals",
    "signal_tracking_proposals",
    "signal_versions",
    "signal_revisions",
    "signal_outcome_events",
    "signal_live_cards",
    "signal_replays",
    "signal_share_cards",
    "smart_followups",
    "kpi_trader_tasks",
    "kpi_trader_submissions",
    "kpi_trader_score_ledger",
    "kpi_business_outcomes",
    "kpi_trader_settings",
}
CRM_SECTIONS = {
    "crm_profiles",
    "crm_activities",
    "crm_automation_log",
    "automation_settings",
    "automation_log",
    "automation_outbox",
    "automation_outbox_index",
    "automation_contact_log",
    "marketing_campaigns",
    "campaign_events",
    "campaign_audience_snapshots",
}
MARKET_SECTIONS = {
    "price_alerts",
    "price_alert_history",
    "price_alert_deliveries",
    "market_intelligence",
    "economic_calendar",
    "economic_calendar_notifications",
    "provider_health",
    "market_regime_history",
}
CHANNEL_SECTIONS = {
    "broadcasts",
    "broadcast_queue",
    "channel_management",
    "broadcast_settings",
    "public_channel_links",
    "public_channel_link_events",
}
CONTENT_SECTIONS = {
    "lessons",
    "faq",
    "contests",
    "chart_contest",
    "candle_contest",
    "contest_history",
    "missions",
    "league_settings",
    "league_seasons",
    "league_history",
}
SUPPORT_SECTIONS = {
    "tickets",
    "support_settings",
    "support_canned_replies",
    "support_internal_notes",
    "faq_feedback",
}
SECURITY_SECTIONS = {
    "privacy_log",
    "approval_settings",
    "pending_admin_actions",
    "admin_logs",
    "delegated_admins",
    "admin_shifts",
    "shift_handoffs",
    "security_settings",
    "privacy_settings",
    "incidents",
    "incident_settings",
}
SYSTEM_SECTIONS = {
    "schema_version",
    "operations",
    "enterprise_control",
    "notification_defaults",
    "backup_settings",
    "health_settings",
    "referral_settings",
    "retention_events",
    "retention_settings",
    "trust_center",
    "runtime_safety",
    "rules_settings",
    "market_session_settings",
    "settings",
    "next_ids",
    "miniapp_event_stream",
    "operations_daily_briefs",
    "growth_experiments",
    "experiment_assignments",
    "experiment_events",
}


@dataclass(frozen=True)
class SectionRecord:
    record_key: str
    position: int
    user_id: str
    status: str
    created_at: str
    updated_at: str
    payload: Any


def json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True, allow_nan=False)


def section_checksum(value: Any) -> str:
    return hashlib.sha256(json_text(value).encode("utf-8")).hexdigest()


def container_type(value: Any) -> str:
    if isinstance(value, dict):
        return "dict"
    if isinstance(value, list):
        return "list"
    return "scalar"


def section_domain(section_key: str) -> str:
    if section_key in COMMERCE_SECTIONS:
        return "commerce"
    if section_key in SIGNAL_SECTIONS:
        return "signals"
    if section_key in CRM_SECTIONS:
        return "crm"
    if section_key in MARKET_SECTIONS:
        return "market"
    if section_key in CHANNEL_SECTIONS:
        return "channels"
    if section_key in CONTENT_SECTIONS:
        return "content"
    if section_key in SUPPORT_SECTIONS:
        return "support"
    if section_key in SECURITY_SECTIONS:
        return "security"
    return "system"


def is_user_section(section_key: str) -> bool:
    return section_key in {
        USER_ACCOUNT_SECTION,
        USER_PROFILE_SECTION,
        USER_MEMBERSHIP_SECTION,
        *USER_BALANCE_SECTIONS,
        *USER_PREFERENCE_SECTIONS,
        *USER_RECORD_SECTIONS,
    }


def _string(value: Any, limit: int = 500) -> str:
    return str(value or "")[:limit]


def _metadata(payload: Any) -> tuple[str, str, str, str]:
    if not isinstance(payload, dict):
        return "", "", "", ""
    user_id = _string(payload.get("user_id") or payload.get("telegram_id") or payload.get("owner_id"), 64)
    status = _string(payload.get("status") or payload.get("state"), 64)
    created_at = _string(payload.get("created_at") or payload.get("date") or payload.get("timestamp"), 64)
    updated_at = _string(
        payload.get("updated_at")
        or payload.get("approved_at")
        or payload.get("closed_at")
        or payload.get("result_updated_at"),
        64,
    )
    return user_id, status, created_at, updated_at


def iter_section_records(value: Any) -> Iterable[SectionRecord]:
    if isinstance(value, dict):
        for position, (key, payload) in enumerate(value.items()):
            user_id, status, created_at, updated_at = _metadata(payload)
            yield SectionRecord(str(key), position, user_id, status, created_at, updated_at, payload)
        return
    if isinstance(value, list):
        for position, payload in enumerate(value):
            user_id, status, created_at, updated_at = _metadata(payload)
            yield SectionRecord(str(position), position, user_id, status, created_at, updated_at, payload)
        return
    user_id, status, created_at, updated_at = _metadata(value)
    yield SectionRecord("__root__", 0, user_id, status, created_at, updated_at, value)


def reconstruct_section(kind: str, rows: Iterable[tuple[str, int, Any]]) -> Any:
    ordered = sorted(rows, key=lambda row: (int(row[1]), str(row[0])))
    if kind == "dict":
        return {str(key): payload for key, _position, payload in ordered}
    if kind == "list":
        return [payload for _key, _position, payload in ordered]
    if not ordered:
        return None
    return ordered[0][2]


def user_id_from_key_or_payload(record_key: str, payload: Any) -> str:
    if str(record_key).isdigit():
        return str(record_key)
    if isinstance(payload, dict):
        candidate = payload.get("user_id") or payload.get("telegram_id") or payload.get("owner_id")
        if candidate is not None:
            return str(candidate)
    return str(record_key)


def display_name(payload: Any) -> str:
    if not isinstance(payload, dict):
        return ""
    return _string(
        payload.get("full_name")
        or payload.get("name")
        or " ".join(filter(None, [payload.get("first_name"), payload.get("last_name")])),
        200,
    )
