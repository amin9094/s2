from __future__ import annotations

import asyncio
import functools
import os
import queue
import threading
import time
from collections.abc import Callable
from concurrent.futures import Executor, Future
from typing import Any, TypeVar

T = TypeVar("T")
_MAX_BLOCKING = max(2, min(64, int(os.getenv("BLOCKING_IO_MAX_CONCURRENCY", "16") or 16)))
_DEFAULT_TIMEOUT = max(1.0, min(120.0, float(os.getenv("BLOCKING_IO_TIMEOUT_SECONDS", "20") or 20)))
_ACQUIRE_TIMEOUT = max(0.1, min(30.0, float(os.getenv("BLOCKING_IO_ACQUIRE_TIMEOUT_SECONDS", "3") or 3)))
_SEMAPHORE: asyncio.Semaphore | None = None
_SEMAPHORE_LOOP: asyncio.AbstractEventLoop | None = None


class _DaemonExecutor(Executor):
    """Small bounded daemon worker pool.

    ``ThreadPoolExecutor`` registers non-daemon workers with CPython's global
    executor shutdown hook. A dependency stuck in an uninterruptible blocking
    call can therefore keep a Railway deploy/restart alive after the bot has
    completed its own shutdown. Sentinel already bounds outstanding blocking
    work with an asyncio semaphore, so a compact daemon pool is sufficient and
    lets the process exit even when the OS/library cannot cancel a worker.
    """

    def __init__(self, max_workers: int):
        self._max_workers = max(1, int(max_workers))
        self._queue: queue.Queue[tuple[Future[Any], Callable[[], Any]] | None] = queue.Queue()
        self._lock = threading.Lock()
        self._shutdown = False
        self._threads: list[threading.Thread] = []
        for index in range(self._max_workers):
            thread = threading.Thread(
                target=self._worker,
                name=f"sentinel-blocking-{index + 1}",
                daemon=True,
            )
            thread.start()
            self._threads.append(thread)

    def _worker(self) -> None:
        while True:
            item = self._queue.get()
            try:
                if item is None:
                    return
                future, call = item
                if not future.set_running_or_notify_cancel():
                    continue
                try:
                    result = call()
                except BaseException as exc:  # Future must preserve worker errors.
                    future.set_exception(exc)
                else:
                    future.set_result(result)
            finally:
                self._queue.task_done()

    def submit(self, fn: Callable[..., T], /, *args: Any, **kwargs: Any) -> Future[T]:
        with self._lock:
            if self._shutdown:
                raise RuntimeError("blocking executor has been shut down")
            future: Future[T] = Future()
            self._queue.put((future, functools.partial(fn, *args, **kwargs)))
            return future

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False) -> None:
        with self._lock:
            if self._shutdown:
                threads = list(self._threads)
            else:
                self._shutdown = True
                threads = list(self._threads)
                if cancel_futures:
                    retained: list[tuple[Future[Any], Callable[[], Any]] | None] = []
                    while True:
                        try:
                            item = self._queue.get_nowait()
                        except queue.Empty:
                            break
                        try:
                            if item is not None:
                                item[0].cancel()
                            else:
                                retained.append(item)
                        finally:
                            self._queue.task_done()
                    for item in retained:
                        self._queue.put(item)
                for _ in threads:
                    self._queue.put(None)
        if wait:
            for thread in threads:
                thread.join()

    def join_bounded(self, timeout: float) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout))
        for thread in list(self._threads):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            thread.join(remaining)
        return not any(thread.is_alive() for thread in self._threads)


_EXECUTOR: _DaemonExecutor | None = None
_EXECUTOR_LOCK = threading.Lock()


def _executor() -> _DaemonExecutor:
    global _EXECUTOR
    if _EXECUTOR is not None:
        return _EXECUTOR
    with _EXECUTOR_LOCK:
        if _EXECUTOR is None:
            _EXECUTOR = _DaemonExecutor(_MAX_BLOCKING)
        return _EXECUTOR


def shutdown_blocking_executor(*, wait_seconds: float = 0.5) -> bool:
    """Stop accepting new blocking work without letting stuck workers block exit.

    Returns ``True`` when every daemon worker exited inside the bounded grace
    period. ``False`` is safe: remaining workers are daemon threads and cannot
    keep the Railway process alive during restart/deploy.
    """
    global _EXECUTOR
    with _EXECUTOR_LOCK:
        executor, _EXECUTOR = _EXECUTOR, None
    if executor is None:
        return True
    executor.shutdown(wait=False, cancel_futures=True)
    return executor.join_bounded(wait_seconds)


def _semaphore() -> asyncio.Semaphore:
    global _SEMAPHORE, _SEMAPHORE_LOOP
    loop = asyncio.get_running_loop()
    if _SEMAPHORE is None or _SEMAPHORE_LOOP is not loop:
        _SEMAPHORE = asyncio.Semaphore(_MAX_BLOCKING)
        _SEMAPHORE_LOOP = loop
    return _SEMAPHORE


def _release_permit(limit: asyncio.Semaphore, loop: asyncio.AbstractEventLoop) -> None:
    if loop.is_closed():
        return
    loop.call_soon_threadsafe(limit.release)


async def run_blocking(
    function: Callable[..., T],
    /,
    *args: Any,
    timeout: float | None = None,
    acquire_timeout: float | None = None,
    **kwargs: Any,
) -> T:
    """Run synchronous I/O outside the event loop with bounded admission.

    A Python thread cannot be force-cancelled safely. If the caller times out or
    is cancelled, the concurrency permit remains held until the underlying call
    actually exits. The daemon pool additionally guarantees a permanently stuck
    native call cannot prevent process shutdown.
    """
    limit = _semaphore()
    effective_timeout = _DEFAULT_TIMEOUT if timeout is None else max(0.1, float(timeout))
    effective_acquire = _ACQUIRE_TIMEOUT if acquire_timeout is None else max(0.1, float(acquire_timeout))

    try:
        await asyncio.wait_for(limit.acquire(), timeout=effective_acquire)
    except TimeoutError as exc:
        raise TimeoutError("blocking I/O capacity exhausted") from exc

    loop = asyncio.get_running_loop()
    concurrent_future = _executor().submit(function, *args, **kwargs)
    future = asyncio.wrap_future(concurrent_future, loop=loop)
    release_deferred = False
    try:
        return await asyncio.wait_for(asyncio.shield(future), timeout=effective_timeout)
    except (TimeoutError, asyncio.CancelledError):
        release_deferred = True
        concurrent_future.add_done_callback(lambda _future: _release_permit(limit, loop))
        raise
    finally:
        if not release_deferred:
            limit.release()
