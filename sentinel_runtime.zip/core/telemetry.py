from __future__ import annotations

import logging
from typing import Any

from config import SETTINGS

logger = logging.getLogger(__name__)
_CONFIGURED = False


def configure_telemetry() -> bool:
    """Enable Sentry only when a DSN is explicitly configured."""
    global _CONFIGURED
    if _CONFIGURED:
        return True
    if not SETTINGS.sentry_dsn:
        return False
    try:
        import sentry_sdk

        sentry_sdk.init(
            dsn=SETTINGS.sentry_dsn,
            environment=SETTINGS.sentry_environment,
            release=f"sentinel@{SETTINGS.release_version}",
            traces_sample_rate=SETTINGS.sentry_traces_sample_rate,
            send_default_pii=False,
            max_breadcrumbs=100,
        )
        _CONFIGURED = True
        logger.info("Sentry telemetry enabled for environment=%s", SETTINGS.sentry_environment)
        return True
    except Exception:
        logger.exception("Could not initialize Sentry telemetry")
        return False


def capture_exception(error: BaseException, **context: Any) -> None:
    if not SETTINGS.sentry_dsn:
        return
    try:
        import sentry_sdk

        with sentry_sdk.push_scope() as scope:
            for key, value in context.items():
                scope.set_extra(str(key), value)
            sentry_sdk.capture_exception(error)
    except Exception:
        logger.debug("Could not submit exception to telemetry", exc_info=True)
