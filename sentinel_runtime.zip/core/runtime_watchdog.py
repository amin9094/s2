from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

_LOCK = threading.Lock()
_THREAD: threading.Thread | None = None
_STOP = threading.Event()


def _truthy(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "true" if default else "false")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _heartbeat_age_seconds(path: Path) -> float | None:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        timestamp = datetime.fromisoformat(
            str(raw.get("updated_at") or raw.get("timestamp") or "").replace("Z", "+00:00")
        )
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=UTC)
        return max(0.0, (datetime.now(UTC) - timestamp.astimezone(UTC)).total_seconds())
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def _terminate_for_recovery(reason: str) -> None:
    """Force a non-zero process exit so the platform restart policy can recover it.

    ``os._exit`` is intentional: this watchdog lives outside the asyncio event
    loop specifically so it can recover a process whose loop is deadlocked and
    therefore cannot execute normal shutdown callbacks.
    """
    logger.critical("Runtime watchdog forcing process restart: %s", reason)
    os._exit(70)  # noqa: PLW1510 -- intentional hard recovery from a deadlocked runtime


def start_runtime_watchdog(
    *,
    heartbeat_file: Path,
    heartbeat_max_age_seconds: int,
    application_running: Callable[[], bool],
) -> None:
    global _THREAD
    if not _truthy("RUNTIME_WATCHDOG_ENABLED", True):
        logger.info("Runtime watchdog disabled by RUNTIME_WATCHDOG_ENABLED")
        return
    with _LOCK:
        if _THREAD is not None and _THREAD.is_alive():
            return
        _STOP.clear()
        interval = max(5.0, min(60.0, float(os.getenv("RUNTIME_WATCHDOG_INTERVAL_SECONDS", "15") or 15)))
        grace = max(30.0, min(900.0, float(os.getenv("RUNTIME_WATCHDOG_STARTUP_GRACE_SECONDS", "180") or 180)))
        max_age = max(
            45.0,
            float(heartbeat_max_age_seconds),
            float(os.getenv("RUNTIME_WATCHDOG_HEARTBEAT_MAX_AGE_SECONDS", "180") or 180),
        )
        failure_limit = max(2, min(10, int(os.getenv("RUNTIME_WATCHDOG_FAILURE_LIMIT", "3") or 3)))
        started_at = time.monotonic()

        def worker() -> None:
            consecutive_failures = 0
            while not _STOP.wait(interval):
                if time.monotonic() - started_at < grace:
                    continue
                reasons: list[str] = []
                try:
                    app_running = bool(application_running())
                except Exception as exc:  # defensive: watchdog must never die silently
                    app_running = False
                    reasons.append(f"application-state-error:{exc.__class__.__name__}")
                if not app_running:
                    reasons.append("telegram-application-not-running")

                try:
                    from core.miniapp_server import is_running as health_server_running
                    if not health_server_running():
                        reasons.append("health-server-thread-not-running")
                except Exception as exc:
                    reasons.append(f"health-server-state-error:{exc.__class__.__name__}")

                age = _heartbeat_age_seconds(Path(heartbeat_file))
                if age is None:
                    reasons.append("heartbeat-missing-or-invalid")
                elif age > max_age:
                    reasons.append(f"heartbeat-stale:{age:.1f}s>{max_age:.1f}s")

                if reasons:
                    consecutive_failures += 1
                    logger.error(
                        "Runtime watchdog unhealthy pass %s/%s: %s",
                        consecutive_failures,
                        failure_limit,
                        ", ".join(reasons),
                    )
                    if consecutive_failures >= failure_limit:
                        _terminate_for_recovery(";".join(reasons))
                else:
                    if consecutive_failures:
                        logger.info("Runtime watchdog recovered after %s unhealthy pass(es)", consecutive_failures)
                    consecutive_failures = 0

        _THREAD = threading.Thread(target=worker, name="sentinel-runtime-watchdog", daemon=True)
        _THREAD.start()
        logger.info(
            "Runtime watchdog started interval=%ss grace=%ss heartbeat_max_age=%ss failure_limit=%s",
            interval,
            grace,
            max_age,
            failure_limit,
        )


def stop_runtime_watchdog() -> None:
    global _THREAD
    with _LOCK:
        thread = _THREAD
        _THREAD = None
        _STOP.set()
    if thread is not None and thread is not threading.current_thread():
        thread.join(timeout=3)
    _STOP.clear()
