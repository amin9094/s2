from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable
from typing import Any

from telegram import Update
from telegram.ext import BaseUpdateProcessor

from core.async_runtime import run_blocking
from core.logging_context import reset_correlation_id, set_correlation_id
from core.observability import increment


class KeyedUpdateProcessor(BaseUpdateProcessor):
    """Process unrelated users concurrently while preserving per-user ordering.

    ConversationHandler state and financial workflows remain serialized for the
    same Telegram user/chat, but slow requests from one user no longer block
    every other user.
    """

    def __init__(self, max_concurrent_updates: int = 8) -> None:
        super().__init__(max(1, int(max_concurrent_updates)))
        self._locks: dict[str, tuple[asyncio.Lock, float]] = {}
        self._guard = asyncio.Lock()

    @staticmethod
    def _key(update: object) -> str:
        if isinstance(update, Update):
            if update.effective_user is not None:
                return f"user:{update.effective_user.id}"
            if update.effective_chat is not None:
                return f"chat:{update.effective_chat.id}"
            return f"update:{update.update_id}"
        return "global"

    async def initialize(self) -> None:
        return None

    async def shutdown(self) -> None:
        async with self._guard:
            self._locks.clear()

    async def _lock_for(self, key: str) -> asyncio.Lock:
        now = time.monotonic()
        async with self._guard:
            row = self._locks.get(key)
            if row is None:
                lock = asyncio.Lock()
                self._locks[key] = (lock, now)
            else:
                lock = row[0]
                self._locks[key] = (lock, now)
            if len(self._locks) > 10_000:
                stale = [name for name, (candidate, touched) in self._locks.items() if not candidate.locked() and now - touched > 3600]
                for name in stale[:5_000]:
                    self._locks.pop(name, None)
            return lock

    async def do_process_update(self, update: object, coroutine: Awaitable[Any]) -> None:
        key = self._key(update)
        lock = await self._lock_for(key)
        update_id = getattr(update, "update_id", "unknown")
        token = set_correlation_id(f"telegram:{update_id}:{key}")
        try:
            async with lock:
                if isinstance(update, Update):
                    from core.telegram_update_outcome import clear_update_failure
                    clear_update_failure(update.update_id)
                try:
                    await coroutine
                except Exception as exc:
                    if isinstance(update, Update):
                        from core.telegram_update_store import mark_failed
                        status = await run_blocking(mark_failed, update.update_id, exc.__class__.__name__, timeout=5)
                        increment(f"telegram_updates_{status}_total")
                    raise
                else:
                    if isinstance(update, Update):
                        from core.telegram_update_outcome import consume_update_failure
                        failure = consume_update_failure(update.update_id)
                        if failure:
                            from core.telegram_update_store import mark_failed
                            status = await run_blocking(mark_failed, update.update_id, failure, timeout=5)
                            increment(f"telegram_updates_{status}_total")
                        else:
                            from core.telegram_update_store import mark_done
                            await run_blocking(mark_done, update.update_id, timeout=5)
                            increment("telegram_updates_processed_total")
        finally:
            if isinstance(update, Update):
                from core.telegram_update_outcome import clear_update_failure
                clear_update_failure(update.update_id)
            reset_correlation_id(token)
