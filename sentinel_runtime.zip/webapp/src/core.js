const APP_VERSION = '8.30.0';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
let tg = window.Telegram?.WebApp;
const state = { lang: ['fa', 'en'].includes(localStorage.getItem('sentinelLanguage')) ? localStorage.getItem('sentinelLanguage') : 'fa', page: 'home', csrf: '', preview: false, online: false, busy: 0, modalReturn: null, modalSubmit: null, mainButtonHandler: null, telegramNavigationInstalled: false, telegramBackMode: 'none', resources: {}, loaded: new Set(), signalFilter: 'all', signalAccessFilter: 'all', signalQuery: '', feedFilter: 'all', tradeHubTab: 'overview', journalFilter: 'all', journalQuery: '', orderFilter: 'all', ticketFilter: 'all', selectedAccount: null, eventSource: null, eventReconnectTimer: null, eventFailureCount: 0, pollTimer: null, livePriceTimer: null, adminSignalQuote: null, lastEventId: Number(sessionStorage.getItem('sentinelLastEventId') || 0), pageSize: 24 };
const resourceInflight = new Map(), actionInflight = new Map();
let overviewInflight = null;
const I18N = {
    fa: { home: 'خانه', signals: 'سیگنال‌ها', risk: 'ریسک', journal: 'ژورنال', more: 'بیشتر', welcome: 'خوش آمدید', member: 'عضو SENTINEL', secure: 'اتصال امن برقرار است', offline: 'اتصال قطع است', loading: 'در حال بارگذاری…', retry: 'تلاش مجدد', activeSignals: 'سیگنال فعال', openRisk: 'ریسک باز', dailyRisk: 'ریسک امروز', journalWin: 'برد ژورنال', decisionCenter: 'مرکز تصمیم سیگنال', riskOS: 'سیستم‌عامل ریسک', tradeJournal: 'ژورنال هوشمند', trust: 'شفافیت عملکرد', viewAll: 'مشاهده همه', details: 'جزئیات', execute: 'ثبت ورود واقعی', skip: 'رد کردن', watch: 'زیرنظر', late: 'ورود دیرهنگام', copy: 'کپی سطوح', account: 'حساب', entry: 'نقطه ورود', stop: 'حد ضرر', volume: 'حجم', riskPercent: 'درصد ریسک', confirmExecution: 'تأیید می‌کنم این اطلاعات اجرای واقعی معامله است', override: 'عبور آگاهانه از هشدار', overrideReason: 'دلیل عبور از هشدار', submit: 'ثبت', cancel: 'انصراف', close: 'بستن', save: 'ذخیره', addAccount: 'افزودن حساب', editAccount: 'ویرایش حساب', whatIf: 'شبیه‌ساز بدترین سناریو', correlation: 'تمرکز هم‌بستگی', positions: 'پوزیشن‌های باز', noData: 'اطلاعاتی برای نمایش وجود ندارد', market: 'مرکز بازار', calendar: 'تقویم اقتصادی', calendarSettings: 'تنظیمات تقویم', calendarAlerts: 'اعلان رویدادها', actualAlerts: 'اعلان نتیجه واقعی', currencies: 'ارزها', minImpact: 'حداقل اهمیت', reminderMinutes: 'یادآوری پیش از خبر', vip: 'اشتراک VIP', support: 'پشتیبانی', orders: 'سفارش‌ها', settings: 'تنظیمات', trackRecord: 'Verified Track Record', replay: 'بازپخش و کالبدشکافی', share: 'کارت اشتراک شفاف', marketRegime: 'رژیم بازار', onboarding: 'راه‌اندازی هوشمند', experience: 'سطح تجربه', goal: 'هدف اصلی', riskTolerance: 'تحمل ریسک', completeSetup: 'تکمیل راه‌اندازی', revisions: 'تغییرات سیگنال', success: 'عملیات با موفقیت انجام شد', error: 'خطایی رخ داد', positionOpened: 'معامله با ریسک واقعی ثبت شد', archived: 'رکورد بایگانی شد', newTrade: 'معامله دستی جدید', exportCsv: 'خروجی CSV', importCsv: 'ورود CSV', closeTrade: 'بستن معامله', partialClose: 'خروج بخشی', price: 'قیمت', updated: 'به‌روزرسانی', selectPlan: 'انتخاب پلن', paymentMethod: 'روش پرداخت', coupon: 'کد تخفیف', getQuote: 'دریافت مبلغ قطعی', uploadReceipt: 'بارگذاری رسید', transactionHash: 'TXID', payable: 'مبلغ قابل پرداخت', expires: 'اعتبار تا', createTicket: 'تیکت جدید', language: 'زبان', rules: 'قوانین', acceptRules: 'پذیرش قوانین', preview: 'حالت پیش‌نمایش', openFromTelegram: 'برای داده واقعی، مینی‌اپ را از تلگرام باز کنید.', searchSignals: 'جست‌وجوی نماد یا شماره سیگنال', all: 'همه', open: 'باز', closed: 'بسته', forex: 'فارکس', crypto: 'کریپتو', green: 'مجاز', yellow: 'احتیاط', red: 'غیرمجاز', copyDone: 'کپی شد', refreshDone: 'اطلاعات تازه شد', accountDisabled: 'برای محاسبه حجم، حساب و مدیریت ریسک را فعال کنید.', noSignals: 'سیگنالی مطابق فیلتر پیدا نشد.', costs: 'هزینه‌ها', behavior: 'تحلیل رفتاری', lateLossRate: 'نرخ زیان ورود دیرهنگام', slippage: 'میانگین انحراف ورود', safetyGate: 'دروازه ایمنی پیش از معامله', currentPrice: 'قیمت فعلی', distance: 'فاصله تا Entry', nearbyNews: 'اخبار نزدیک', history: 'تاریخچه تغییرات', evidenceHash: 'هش شواهد', ack: 'مشاهده و تأیید', status: 'وضعیت', reason: 'دلیل', name: 'نام', balance: 'موجودی', equity: 'اکویتی', timezone: 'منطقه زمانی', accountType: 'نوع حساب', personal: 'شخصی', propChallenge: 'چالش پراپ', propFunded: 'Funded', demo: 'دمو', maxDailyRisk: 'حداکثر ریسک روزانه', maxOpenRisk: 'حداکثر ریسک باز', dailyLoss: 'حد ضرر روزانه', totalLoss: 'حد ضرر کل', profitTarget: 'هدف سود', riskEnabled: 'مدیریت ریسک فعال', journalNote: 'یادداشت', setup: 'ستاپ', emotion: 'حالت روانی', tags: 'برچسب‌ها', pnlPercent: 'سود/زیان درصدی', pnlAmount: 'سود/زیان مبلغی', fees: 'کارمزد', commission: 'کمیسیون', swap: 'سواپ', exitPrice: 'قیمت خروج', file: 'فایل', ticketSubject: 'موضوع', message: 'پیام', priority: 'اولویت', logout: 'خروج از نشست', notAvailable: 'در دسترس نیست', globalSearch: 'جست‌وجوی سراسری', searchPlaceholder: 'سیگنال، سفارش، تیکت یا ژورنال را جست‌وجو کنید', notifications: 'مرکز اعلان هوشمند', resubmit: 'ارسال مجدد', orderDetails: 'جزئیات سفارش', brokerImport: 'ورود گزارش MT5/بروکر', todayActions: 'اقدام‌های امروز', maintenance: 'این قابلیت توسط مدیر غیرفعال شده است', appVersion: 'نسخه برنامه', currency: 'ارز', closeFraction: 'درصد بستن', symbol: 'نماد', side: 'جهت', sample: 'نمونه', winRate: 'نرخ برد', averageR: 'میانگین R', maxDrawdown: 'بیشترین افت', normal: 'عادی', high: 'مهم', accepted: 'پذیرفته شده', pending: 'در انتظار', adminConsole: 'کنسول عملیات مدیر', dailyBrief: 'گزارش روزانه عملیات', shiftHandoff: 'تحویل شیفت', experimentLab: 'آزمایشگاه رشد', newHandoff: 'تحویل شیفت جدید', newExperiment: 'آزمایش جدید', acknowledge: 'دریافت شد', complete: 'تکمیل', hypothesis: 'فرضیه', primaryMetric: 'شاخص اصلی', minimumSample: 'حداقل نمونه', reloadApp: 'بارگذاری نسخه جدید' },
    en: { home: 'Home', signals: 'Signals', risk: 'Risk', journal: 'Journal', more: 'More', welcome: 'Welcome', member: 'SENTINEL member', secure: 'Secure connection active', offline: 'Connection lost', loading: 'Loading…', retry: 'Retry', activeSignals: 'Active signals', openRisk: 'Open risk', dailyRisk: 'Today risk', journalWin: 'Journal win rate', decisionCenter: 'Signal Decision Center', riskOS: 'Personal Risk OS', tradeJournal: 'Smart Journal', trust: 'Verified Track Record', viewAll: 'View all', details: 'Details', execute: 'Confirm real execution', skip: 'Skip', watch: 'Watch', late: 'Late entry', copy: 'Copy levels', account: 'Account', entry: 'Entry', stop: 'Stop', volume: 'Volume', riskPercent: 'Risk percent', confirmExecution: 'I confirm these are my real execution details', override: 'Conscious risk override', overrideReason: 'Override reason', submit: 'Submit', cancel: 'Cancel', close: 'Close', save: 'Save', addAccount: 'Add account', editAccount: 'Edit account', whatIf: 'Worst-case simulator', correlation: 'Correlation concentration', positions: 'Open positions', noData: 'No data to display', market: 'Market Center', calendar: 'Economic Calendar', calendarSettings: 'Calendar settings', calendarAlerts: 'Event alerts', actualAlerts: 'Actual-result alerts', currencies: 'Currencies', minImpact: 'Minimum impact', reminderMinutes: 'Reminder before event', vip: 'VIP Subscription', support: 'Support', orders: 'Orders', settings: 'Settings', trackRecord: 'Verified Track Record', replay: 'Signal Replay & Post-Mortem', share: 'Transparent Share Card', marketRegime: 'Market Regime', onboarding: 'Smart Onboarding', experience: 'Experience level', goal: 'Primary goal', riskTolerance: 'Risk tolerance', completeSetup: 'Complete setup', revisions: 'Signal revisions', success: 'Done successfully', error: 'Something went wrong', positionOpened: 'Position recorded with actual risk', archived: 'Record archived', newTrade: 'New manual trade', exportCsv: 'Export CSV', importCsv: 'Import CSV', closeTrade: 'Close trade', partialClose: 'Partial close', price: 'Price', updated: 'Updated', selectPlan: 'Select plan', paymentMethod: 'Payment method', coupon: 'Coupon', getQuote: 'Get binding quote', uploadReceipt: 'Upload receipt', transactionHash: 'TXID', payable: 'Payable amount', expires: 'Expires', createTicket: 'New ticket', language: 'Language', rules: 'Rules', acceptRules: 'Accept rules', preview: 'Preview mode', openFromTelegram: 'Open the Mini App from Telegram for live data.', searchSignals: 'Search symbol or signal number', all: 'All', open: 'Open', closed: 'Closed', forex: 'Forex', crypto: 'Crypto', green: 'Allowed', yellow: 'Caution', red: 'Blocked', copyDone: 'Copied', refreshDone: 'Data refreshed', accountDisabled: 'Enable your account and risk settings to calculate position size.', noSignals: 'No signals match the selected filters.', costs: 'Costs', behavior: 'Behavioral review', lateLossRate: 'Late-entry loss rate', slippage: 'Average entry slippage', safetyGate: 'Pre-trade safety gate', currentPrice: 'Current price', distance: 'Distance to entry', nearbyNews: 'Nearby news', history: 'Revision history', evidenceHash: 'Evidence hash', ack: 'Acknowledge', status: 'Status', reason: 'Reason', name: 'Name', balance: 'Balance', equity: 'Equity', timezone: 'Timezone', accountType: 'Account type', personal: 'Personal', propChallenge: 'Prop challenge', propFunded: 'Prop funded', demo: 'Demo', maxDailyRisk: 'Max daily risk', maxOpenRisk: 'Max open risk', dailyLoss: 'Daily loss limit', totalLoss: 'Total loss limit', profitTarget: 'Profit target', riskEnabled: 'Risk management enabled', journalNote: 'Note', setup: 'Setup', emotion: 'Emotion', tags: 'Tags', pnlPercent: 'PnL percent', pnlAmount: 'PnL amount', fees: 'Fees', commission: 'Commission', swap: 'Swap', exitPrice: 'Exit price', file: 'File', ticketSubject: 'Subject', message: 'Message', priority: 'Priority', logout: 'Log out', notAvailable: 'Unavailable', globalSearch: 'Global search', searchPlaceholder: 'Search signals, orders, tickets or journal', notifications: 'Smart notification center', resubmit: 'Resubmit', orderDetails: 'Order details', brokerImport: 'Import MT5/broker statement', todayActions: 'Today actions', maintenance: 'This feature is disabled by the administrator.', appVersion: 'App version', currency: 'Currency', closeFraction: 'Close fraction', symbol: 'Symbol', side: 'Side', sample: 'Sample', winRate: 'Win rate', averageR: 'Average R', maxDrawdown: 'Max drawdown', normal: 'Normal', high: 'High', accepted: 'Accepted', pending: 'Pending', adminConsole: 'Admin Operations Console', dailyBrief: 'Daily operations brief', shiftHandoff: 'Shift handoff', experimentLab: 'Growth Experiment Lab', newHandoff: 'New handoff', newExperiment: 'New experiment', acknowledge: 'Acknowledge', complete: 'Complete', hypothesis: 'Hypothesis', primaryMetric: 'Primary metric', minimumSample: 'Minimum sample', reloadApp: 'Load new version' }
};
const t = k => I18N[state.lang]?.[k] ?? I18N.fa[k] ?? k;
const ui = (fa, en) => state.lang === 'fa' ? fa : en;
const UI_EN_EXACT = {
    'مسابقه': 'Contest',
    'مسابقه‌ها': 'Contests',
    'پیش‌بینی قیمت': 'Price prediction',
    'مسابقه چارت': 'Chart challenge',
    'مسابقه کندل': 'Candle challenge',
    'جهت بازار بعد از خبر': 'News direction',
    'نزدیک‌ترین قیمت برنده است': 'Closest price wins',
    'جهت بعدی بازار را انتخاب کنید': 'Choose the next market direction',
    'قیمت بسته‌شدن کندل را حدس بزنید': 'Predict the candle close',
    'حرکت بازار بعد از خبر را پیش‌بینی کنید': 'Predict the post-news move',
    'صعودی': 'Bullish',
    'نزولی': 'Bearish',
    'خنثی': 'Flat',
    'رنج': 'Range',
    'برنده': 'Winner',
    'پایان‌یافته': 'Completed',
    'رتبه': 'Rank',
    'نتایج اخیر من': 'My recent results',
    'فقط مسابقه‌هایی که در آن‌ها شرکت کرده‌اید': 'Only contests you joined',
    'پاسخ را وارد کنید.': 'Enter your answer.',
    'پاسخ مسابقه با موفقیت ثبت شد.': 'Contest entry submitted.',
    'قبلاً در این مسابقه پاسخ ثبت کرده‌اید.': 'You already entered this contest.',
    'زمان مسابقه تمام شده یا دیگر فعال نیست.': 'This contest is no longer active.',
    'ثبت پاسخ انجام نشد.': 'Could not submit the entry.',
    'پاسخ واردشده معتبر نیست.': 'The submitted answer is invalid.',
    'مالک سیستم': 'System owner', 'مدیر': 'Administrator', 'عضو VIP': 'VIP member', 'عضو عمومی': 'Public member',
    'عمومی': 'Public', 'خصوصی': 'Private', 'کریپتو': 'Crypto', 'فارکس': 'Forex', 'قفل': 'Locked',
    'مرکز فرمان معامله‌گری': 'Trading Command Center', 'سیگنال، بازار، ریسک و ژورنال شما در یک نمای زنده و محافظت‌شده.': 'Your signals, market, risk and journal in one live protected view.',
    'مشاهده سیگنال‌ها': 'View signals', 'مرکز معامله': 'Trading Center', 'محافظ فعال': 'Protection active',
    'سیگنال عمومی': 'Public signals', 'اتاق VIP': 'VIP Room', 'سیگنال‌های اختصاصی زنده': 'Live exclusive signals', 'برای دسترسی اشتراک تهیه کنید': 'Subscribe to unlock access',
    'وضعیت محافظت حساب': 'Account protection status', 'محافظت‌شده': 'Protected', 'ریسک باز': 'Open risk', 'ظرفیت روزانه': 'Daily capacity', 'معامله باز': 'open trades', 'نرخ برد ژورنال': 'journal win rate',
    'بازار زنده': 'Live market', 'قیمت و واچ‌لیست': 'Prices and watchlist', 'محاسبه حجم': 'Position sizing', 'معاملات من': 'My trades', 'ژورنال و نتیجه': 'Journal and outcomes', 'اعلان‌ها': 'Notifications', 'کنترل بدون مزاحمت': 'Quiet controls',
    'سیگنال‌های تازه': 'Recent signals', 'عمومی و VIP بر اساس دسترسی حساب': 'Public and VIP based on account access', 'مشاهده همه': 'View all',
    'انتخاب': 'Decision', 'منتظر تصمیم شما': 'Waiting for your decision', 'جزئیات': 'Details', 'بگیرش': 'Take it', 'نمی‌گیرم': 'Skip',
    'این سیگنال بسته شده است': 'This signal is closed', 'فقط مشخص کنید آن را گرفته بودید یا نگرفته بودید؛ معامله جدیدی باز نمی‌شود.': 'Record whether you took it; no new position will be opened.',
    'این تصمیم قفل شده و رکورد تکراری ایجاد نمی‌شود.': 'This decision is locked and will not be duplicated.', 'بگیرش و ثبت کن': 'Take and journal',
    'چارت نتیجه نهایی سیگنال': 'Final signal result chart', 'مدرک تصویری نتیجه نهایی': 'Final result evidence',
    'وضعیت، مدرک نتیجه و چارت تحلیل در اسلایدهای جداگانه': 'Status, result evidence and analysis chart in separate slides',
    'مرکز سیگنال SENTINEL': 'SENTINEL Signal Center', 'تفکیک عمومی، VIP، فارکس و کریپتو؛ هر تصمیم مستقیم به ژورنال و مربی ریسک متصل است.': 'Public, VIP, Forex and Crypto signals; every decision connects directly to your journal and risk coach.',
    'همه بازارها': 'All markets', 'باز': 'Open', 'بسته': 'Closed', 'اتاق سیگنال VIP': 'VIP Signal Room', 'مشاهده پلن‌ها': 'View plans', 'نماد یا شماره سیگنال': 'Symbol or signal number',
    'گرفته شد و در ژورنال ثبت شد': 'Taken and journaled', 'تصمیم ثبت شد': 'Decision recorded', 'بررسی': 'Review',
    'نبض زنده کانال': 'Live Channel Pulse', 'سیگنال، خبر و اعلان هم‌زمان با تلگرام': 'Signals, news and announcements synchronized with Telegram', 'زنده': 'Live', 'اعلان دستگاه': 'Device notifications',
    'همه': 'All', 'سیگنال': 'Signal', 'خبر و بازار': 'News & market', 'اعلان': 'Announcement', 'تحلیل بازار': 'Market analysis', 'انتشار': 'Publication',
    'نمای کلی': 'Overview', 'تمرین معامله': 'Paper trading', 'نگهبان Prop': 'Prop Guardian', 'مربی ریسک': 'Risk Coach', 'مرکز معامله و محافظت': 'Trading & Protection Center',
    'حساب آزمایشی، قوانین Prop و رفتار معاملاتی در سه بخش روشن و مستقل.': 'Paper accounts, Prop rules and trading behavior in three clear sections.',
    'حساب تمرینی': 'Paper account', 'انضباط': 'Discipline', 'ریسک سیگنال': 'Signal risk', 'ثبت و مدیریت تمام TPها': 'Record and manage all take-profit levels', 'کنترل نقض قوانین': 'Control rule breaches', 'تحلیل سیگنال‌های گرفته‌شده': 'Analyze taken signals', 'قبل از ورود': 'Before entry',
    'حساب آزمایشی و همه سناریوهای خروج در یکجا': 'Paper account and every exit scenario in one place', 'حساب جدید': 'New account', 'معامله جدید': 'New trade', 'لغو': 'Cancelled', 'باقی‌مانده': 'remaining',
    'فاصله تا نقض قانون و آمادگی چالش': 'Distance to rule breach and challenge readiness', 'قوانین این حساب هنوز تنظیم نشده است.': 'Rules are not configured for this account yet.', 'فعال‌کردن الگوی استاندارد': 'Enable standard template', 'ضرر روزانه': 'Daily loss', 'افت کل': 'Total drawdown', 'هدف سود': 'Profit target', 'هیچ نقض فعالی ثبت نشده است.': 'No active breach is recorded.',
    'مربی رفتار و ریسک': 'Behavior & Risk Coach', 'متصل به سیگنال‌های گرفته‌شده و ژورنال واقعی شما': 'Connected to taken signals and your real journal', 'تحلیل مجدد': 'Run analysis again', 'الگوی پرخطر واضحی دیده نشد.': 'No clear high-risk pattern was detected.',
    'ساخت حساب آزمایشی': 'Create paper account', 'نام حساب': 'Account name', 'سرمایه اولیه': 'Starting balance', 'ساخت حساب': 'Create account', 'حساب ساخته شد': 'Account created',
    'ثبت معامله آزمایشی': 'Record paper trade', 'حساب': 'Account', 'نماد': 'Symbol', 'جهت': 'Side', 'ورود': 'Entry', 'حد ضرر': 'Stop loss', 'تارگت‌ها': 'Targets', 'ریسک درصدی': 'Risk percent', 'ثبت معامله': 'Record trade', 'معامله ثبت شد': 'Trade recorded',
    'تغییر حد ضرر': 'Move stop loss', 'SL جدید': 'New SL', 'دلیل': 'Reason', 'ذخیره': 'Save', 'وضعیت معامله به‌روزرسانی شد': 'Trade status updated', 'نگهبان Prop فعال شد': 'Prop Guardian enabled',
    'مرکز کاربر': 'User Center', 'فید کانال': 'Channel feed', 'سیگنال، خبر و اعلان زنده': 'Live signals, news and announcements', 'مرکز تمرین و ریسک': 'Trading Practice & Risk', 'جست‌وجو در تمام داده‌های شخصی': 'Search all personal data', 'خبرهای مهم هفته': 'Important news this week', 'عملکرد قابل راستی‌آزمایی': 'Verifiable performance', 'تغییرات سیگنال‌های گرفته‌شده': 'Changes to taken signals', 'زبان، قوانین و نشست': 'Language, rules and session', 'تیکت و پاسخ‌ها': 'Tickets and replies',
    'مرکز اختصاصی ادمین': 'Admin Workspace', 'این بخش فقط با نقش و مجوز ادمین از سمت سرور باز می‌شود.': 'This area opens only with a server-authorized admin role.', 'عملیات، Audit، شیفت و کنترل سامانه': 'Operations, audit, shifts and system control', 'دسترسی‌های کاربر و ادمین کاملاً از هم جدا شده‌اند.': 'User and admin permissions are fully separated.',
    'مرکز کامل عملیات ادمین': 'Full Admin Command Center', 'عملیات واقعی و مجاز': 'authorized executable actions', 'هر گزینه مستقیماً از رجیستری مشترک ربات و مینی‌اپ اجرا می‌شود.': 'Every option runs through the shared bot and Mini App registry.', 'جست‌وجوی عملیات': 'Search actions', 'نام ماژول یا عملیات...': 'Module or action...', 'سایر': 'Other',
    'دسترسی موردنیاز': 'Required permission', 'داده ورودی JSON': 'JSON payload', 'عملیات با موفقیت انجام شد.': 'Operation completed successfully.', 'عملیات ناموفق بود': 'Operation failed', 'دریافت اطلاعات': 'Load data', 'اجرا': 'Run', 'ثبت و اجرا': 'Submit and run', 'بارگذاری پنل ادمین ناموفق بود': 'Admin panel failed to load', 'اتصال، دسترسی یا وضعیت سرور را بررسی کنید.': 'Check connectivity, permissions and server health.',
    'مرکز مدیریت ساده و عملیاتی': 'Simple Operations Center', 'پرداخت منتظر': 'Pending payments', 'تیکت نیازمند پاسخ': 'Tickets awaiting reply', 'سیگنال در صف': 'Signals queued', 'دسترسی فعال': 'Active access', 'همه ابزارهای ادمین': 'All admin tools', 'صف ارسال سیگنال': 'Signal delivery queue', 'گزارش ممیزی': 'Audit log',
    'دسترسی کاربران': 'User access', 'مینی‌اپ برای کاربران روشن است.': 'The Mini App is enabled for users.', 'مینی‌اپ برای کاربران خاموش است؛ دسترسی ادمین حفظ شده.': 'The Mini App is disabled for users; admin access remains available.', 'خاموش‌کردن': 'Disable', 'روشن‌کردن': 'Enable', 'همگام‌سازی اطلاعات': 'Reconcile data', 'تطبیق دوباره': 'Reconcile again',
    'دوره‌های نام‌دار سیگنال': 'Named signal periods', 'دوره فعلی': 'Current period', 'با بستن دوره، تاریخچه و سیگنال‌ها حذف نمی‌شوند.': 'Closing a period does not delete its history or signals.', 'کل سیگنال': 'Total signals', 'برد': 'Wins', 'باخت': 'Losses', 'نرخ برد': 'Win rate', 'آرشیو و گزارش دوره‌ها': 'Period archive and reports', 'شروع دوره جدید': 'Start new period', 'بستن و شروع دوره جدید': 'Close and start new period', 'فقط بستن دوره': 'Close period only',
    'رسیدهای منتظر بررسی': 'Receipts awaiting review', 'کاربر': 'User', 'بررسی رسید': 'Review receipt', 'تیکت‌های نیازمند پاسخ': 'Tickets awaiting reply', 'بازکردن و پاسخ': 'Open and reply', 'ابزارها و جزئیات پیشرفته': 'Advanced tools and details', 'سلامت سیستم': 'System health', 'قالب سیگنال': 'Signal template', 'بارگذاری': 'Upload', 'قالب اصلی': 'Primary template',
    'مدیریت رسیدها و پرداخت‌ها': 'Manage receipts and payments', 'رسیدها و پرداخت‌های VIP': 'VIP receipts and payments', 'منتظر بررسی': 'Pending review', 'در حال تأیید': 'Approving', 'تأییدشده': 'Approved', 'ردشده': 'Rejected', 'منقضی': 'Expired', 'بازکردن رسید و بررسی': 'Open receipt and review', 'مشاهده و بررسی': 'View and review', 'مبلغ': 'Amount', 'رسید': 'Receipt', 'پیوست‌شده': 'Attached', 'ندارد': 'Missing', '✅ رسید پیوست شده': '✅ Receipt attached', '⚠️ بدون رسید': '⚠️ No receipt', 'محاسبه‌گر دقیق حجم و مارجین SENTINEL': 'SENTINEL precise position and margin calculator', 'بودجه ریسک': 'Risk budget', 'ظرفیت مارجین': 'Margin capacity',
    'بازار، شفافیت، اعلان، اشتراک و پشتیبانی در یک مرکز.': 'Market, transparency, notifications, subscriptions and support in one center.', 'قیمت‌ها و واچ‌لیست': 'Prices and watchlist', 'آمار واقعی و هش شواهد': 'Verified statistics and evidence hash', 'تغییرات پوزیشن‌های Taken': 'Changes to taken positions', 'فیلتر بازار، ساعات سکوت و خلاصه‌ها': 'Market filters, quiet hours and digests', 'پلن‌ها و پرداخت امن': 'Plans and secure payment', 'پیگیری، لغو و ارسال مجدد': 'Track, cancel and resubmit', 'تیکت و پاسخ‌ها': 'Tickets and replies', 'تحویل شیفت، گزارش روزانه و آزمایش‌های رشد': 'Shift handoff, daily brief and growth experiments',
    'در انتظار ادمین': 'Waiting for admin', 'پاسخ داده شد': 'Answered', 'پشتیبانی یکپارچه ربات و مینی‌اپ': 'Unified bot and Mini App support', 'تمام پاسخ‌ها در هر دو محیط هم‌زمان ثبت و اطلاع‌رسانی می‌شوند.': 'All replies are recorded and delivered in both environments.', 'پاسخ ادمین آماده است': 'Admin reply is ready', 'در انتظار بررسی پشتیبانی': 'Waiting for support review', 'بستن تیکت': 'Close ticket', 'تیکت بسته است': 'Ticket is closed', 'بازگشایی': 'Reopen',
    'اعلان سیستم در این دستگاه پشتیبانی نمی‌شود': 'System notifications are not supported on this device', 'اعلان دستگاه فعال شد': 'Device notifications enabled', 'مجوز اعلان داده نشد': 'Notification permission was not granted',
    'لغو TP': 'Cancel TP', 'سر‌به‌سر': 'Break even', 'تغییر SL': 'Move SL', 'لغو معامله': 'Cancel trade', 'لغوشده': 'Cancelled', 'بدون نقض فعال': 'No active breach',
    'اطلاعات ورود تلگرام دریافت نشد.': 'Telegram login data was not received.', 'ورود امن تلگرام تکمیل نشده است': 'Secure Telegram login is incomplete', 'ورود به SENTINEL تکمیل نشد': 'SENTINEL login was not completed', 'این صفحه را کامل ببندید.': 'Close this page completely.', 'به گفت‌وگوی ربات برگردید.': 'Return to the bot chat.', 'تلاش دوباره': 'Try again', 'بستن مینی‌اپ': 'Close Mini App', 'جزئیات تشخیص': 'Diagnostic details', 'Telegram WebView شناسایی شد؛ اطلاعات امضاشده هنوز نرسیده است.': 'Telegram WebView was detected, but signed data has not arrived yet.', 'این صفحه خارج از محیط Web App تلگرام باز شده است.': 'This page was opened outside Telegram Web App.', 'در حال دریافت مجوز تلگرام…': 'Requesting Telegram authorization…', 'در حال بررسی ورود امن تلگرام…': 'Checking secure Telegram login…',
    'در حال برقراری اتصال امن…': 'Establishing secure connection…', 'حالت پیش‌نمایش': 'Preview mode', 'برای داده واقعی، از دکمه Mini App ربات وارد شوید.': 'Open the Mini App from the bot for live data.', 'در حال انجام…': 'Working…', 'برای اجرای SENTINEL باید JavaScript فعال باشد.': 'JavaScript must be enabled to run SENTINEL.',
    'بازگشت': 'Back', 'انصراف': 'Cancel', 'ارسال': 'Send', 'تأیید': 'Confirm', 'رد پرداخت': 'Reject payment', 'تأیید پرداخت': 'Approve payment', 'پاسخ مدیر': 'Admin reply', 'پیام کاربر': 'User message', 'شما': 'You', 'فایل ضمیمه': 'Attachment',
    'فعال': 'Active', 'غیرفعال': 'Disabled', 'در انتظار': 'Pending', 'ارسال‌شده': 'Sent', 'در حال انتشار': 'Publishing', 'ناموفق': 'Failed', 'شکست دائمی': 'Permanently failed', 'در انتظار تلاش مجدد': 'Waiting to retry',
    'آخرین همگام‌سازی': 'Last sync', 'قدیمی': 'Stale', 'در دسترس نیست': 'Unavailable', 'اطلاعاتی برای نمایش وجود ندارد': 'No data to display', 'قیمت فعلی': 'Current price', 'فاصله تا Entry': 'Distance to entry', 'نزدیک‌ترین تارگت': 'Nearest target', 'قیمت داخل محدوده ورود است': 'Price is inside the entry zone', 'سطوح Entry را وارد کنید': 'Enter entry levels', 'رسیده': 'Reached', 'فاصله': 'distance', 'R نامشخص': 'R unavailable',
    'نماد را وارد کنید تا ردیاب چندمنبعی فعال شود.': 'Enter a symbol to activate multi-source tracking.', 'در حال دریافت بهترین قیمت از APIهای فعال…': 'Fetching the best price from active APIs…', 'ارسال سیگنال با ردیاب زنده': 'Publish signal with live tracker', 'ورودها': 'Entries', 'مقصد': 'Destination', 'کانال عمومی': 'Public channel', 'کانال VIP': 'VIP channel', 'هر دو کانال': 'Both channels', 'تایم‌فریم': 'Timeframe', 'دریافت قیمت و محاسبه فاصله‌ها': 'Fetch price and calculate distances', 'یادداشت/تحلیل': 'Note / analysis', 'اعتبارسنجی و انتشار': 'Validate and publish',
    'انتشار اعلان کانال': 'Publish channel announcement', 'عنوان': 'Title', 'متن اعلان': 'Announcement text', 'ثبت و انتشار': 'Save and publish', 'اعلان در صف پایدار انتشار قرار گرفت': 'Announcement was added to the durable delivery queue',
    'دوره‌های سیگنال و گزارش عملکرد': 'Signal periods and performance', 'تاریخچه دائمی دوره‌ها': 'Permanent period history', 'بستن دوره فقط آن را آرشیو می‌کند؛ سیگنال‌ها، نتایج و PDF آن باقی می‌مانند.': 'Closing only archives the period; its signals, results and PDF remain available.', 'فقط بستن دوره فعلی': 'Close current period only', 'تغییر نام': 'Rename', 'نام دوره': 'Period name', 'دریافت PDF کامل': 'Download full PDF', 'بازگشت به دوره‌ها': 'Back to periods',
    'دروازه ایمنی پیش از معامله': 'Pre-trade safety gate', 'اخبار نزدیک': 'Nearby news', 'تاریخچه تغییرات': 'Revision history', 'تقویم اقتصادی هنوز همگام نشده است.': 'The economic calendar has not been synchronized yet.', 'خبر مهم مرتبطی در بازه نزدیک این سیگنال وجود ندارد.': 'No relevant high-impact news is near this signal.', 'ثبت اولیه سیگنال': 'Initial signal',
    'برای محاسبه دقیق ریسک، ابتدا یک حساب معاملاتی انتخاب یا ایجاد کنید.': 'Select or create a trading account before calculating risk.', 'همه کنترل‌های فعال ریسک با موفقیت پاس شدند.': 'All active risk controls passed.', 'محدودیت زیان روزانه اجازه ورود نمی‌دهد.': 'The daily loss limit blocks this entry.', 'محدودیت افت کل حساب اجازه ورود نمی‌دهد.': 'The total drawdown limit blocks this entry.', 'ریسک باز حساب از سقف مجاز عبور می‌کند.': 'The account open risk would exceed its limit.', 'تعداد معاملات باز به سقف مجاز رسیده است.': 'The maximum number of open trades has been reached.', 'اطلاعات حساب قدیمی است و باید تازه‌سازی شود.': 'Account data is stale and must be refreshed.', 'اعتماد داده‌های حساب برای تصمیم قطعی کافی نیست.': 'Account data confidence is too low for a definitive decision.'
};
Object.assign(UI_EN_EXACT, {
    "گفت‌وگو و فرمان به Gemini": "Chat and command Gemini",
    "فرمان‌های مجاز ادمین اصلی مستقیم اجرا می‌شوند؛ کد تخفیف و دسترسی ادمین همیشه تأیید انسانی می‌خواهند.": "Allowed primary-admin commands execute directly; discounts and admin access always require human approval.",
    "اجرای خودکار متوقف است؛ فرمان‌ها برای تأیید انسانی در صف می‌مانند.": "Automatic execution is stopped; commands stay queued for human approval.",
    "فرمان‌های شما پس از کنترل مجوز برای تأیید ادمین اصلی ارسال می‌شوند.": "Your permission-checked commands are sent to the primary admin for approval.",
    "اتصال MT5": "Connect MT5",
    "اتصال این متاتریدر قطع شود؟": "Revoke this MetaTrader connection?",
    "اتصال کاملاً فقط‌خواندنی است و رمز حساب دریافت نمی‌شود.": "The connection is fully read-only and never asks for the account password.",
    "این حساب هنوز به MT5 متصل نیست.": "This account is not connected to MT5 yet.",
    "برنامه ریسک امروز": "Today's risk plan",
    "بروکر": "Broker",
    "تأیید برنامه": "Accept plan",
    "ثبت وضعیت قبل از معامله": "Record pre-trade state",
    "حالت": "Mode",
    "دانلود بسته": "Download package",
    "در حال حاضر هشدار فعالی وجود ندارد.": "There are no active alerts right now.",
    "ذخیره و تأیید": "Save and accept",
    "ساخت کد": "Create code",
    "ساخت کد اتصال یک‌بارمصرف": "Create one-time pairing code",
    "فقط‌خواندنی": "Read only",
    "قطع اتصال": "Revoke connection",
    "کد اتصال آماده است": "Pairing code is ready",
    "کد اتصال جدید": "New pairing code",
    "کنترل کامل ماژول‌های ربات و مینی‌اپ": "Full bot and Mini App module control",
    "صف تغییرات حساس": "Sensitive change queue",
    "بازنشانی ماژول": "Reset module",
    "تنظیمات این ماژول بازنشانی شود؟": "Reset this module's settings?",
    "روشن": "On",
    "خاموش": "Off",
    "درخواست تأیید ساخته شد.": "An approval request was created.",
    "درخواست تغییر سراسری ثبت شود؟": "Submit the global change request?",
    "درخواست حاکمیت ساخته شد.": "A governance request was created.",
    "دلیل رد:": "Rejection reason:",
    "رد": "Reject",
    "در حال بارگذاری SENTINEL": "Loading SENTINEL",
    "در حال بارگذاری و برقراری اتصال امن": "Loading and establishing a secure connection",
    "حساب کاربری": "User account",
    "تغییرات مهم سیگنال‌ها": "Important signal revisions",
    "تازه‌سازی": "Refresh",
    "تغییر زبان": "Change language",
    "نمودار خلاصه": "Summary chart",
    "فارکس و کریپتو": "Forex and Crypto",
    "ناوبری اصلی": "Main navigation",
    "خانه": "Home",
    "سیگنال‌ها": "Signals",
    "ریسک": "Risk",
    "ژورنال": "Journal",
    "بیشتر": "More",
    "خوش آمدید": "Welcome",
    "عضو SENTINEL": "SENTINEL member",
    "تمام خدمات": "All services",
    "ابزارها بر اساس کاری که می‌خواهید انجام دهید دسته‌بندی شده‌اند.": "Tools are grouped by what you want to do.",
    "معامله و تصمیم": "Trading and decisions",
    "از سیگنال تا ثبت نتیجه": "From signal to recorded outcome",
    "مرکز معامله": "Trading Center",
    "تمرین، Prop و مربی ریسک": "Paper trading, Prop and risk coaching",
    "محاسبه‌گر حجم": "Position Size Calculator",
    "ژورنال و معاملات": "Journal and Trades",
    "ورود، خروج و تحلیل": "Entries, exits and analysis",
    "قیمت و بازار": "Prices and Market",
    "واچ‌لیست و رژیم بازار": "Watchlist and market regime",
    "اشتراک و دسترسی": "Subscription and Access",
    "VIP، سفارش و پرداخت": "VIP, orders and payments",
    "اشتراک VIP": "VIP Subscription",
    "مشاهده پلن‌ها و خرید": "View plans and subscribe",
    "سفارش‌ها": "Orders",
    "رسید و وضعیت پرداخت": "Receipt and payment status",
    "نبض کانال": "Channel Pulse",
    "سیگنال، خبر و اعلان": "Signals, news and announcements",
    "اطلاعات و ارتباط": "Information and Communication",
    "اعلان، تقویم و پشتیبانی": "Notifications, calendar and support",
    "مرکز اعلان": "Notification Center",
    "فیلتر و ساعات سکوت": "Filters and quiet hours",
    "تقویم اقتصادی": "Economic Calendar",
    "خبرهای مهم بازار": "Important market news",
    "پشتیبانی": "Support",
    "تیکت و پاسخ": "Tickets and replies",
    "جست‌وجوی سراسری": "Global Search",
    "تمام اطلاعات حساب": "All account information",
    "اعتماد و حساب": "Trust and Account",
    "شفافیت، قوانین و تنظیمات": "Transparency, rules and settings",
    "عملکرد تأییدشده": "Verified Performance",
    "Track Record و شواهد": "Track Record and evidence",
    "تغییرات سیگنال": "Signal Revisions",
    "نسخه‌ها و اصلاحیه‌ها": "Versions and amendments",
    "تنظیمات حساب": "Account Settings",
    "عمومی و VIP، با تصمیم‌گیری مستقیم و ثبت خودکار در ژورنال.": "Public and VIP signals with direct decisions and automatic journal recording.",
    "همه": "All",
    "عمومی": "Public",
    "همه بازارها": "All markets",
    "باز": "Open",
    "فارکس": "Forex",
    "کریپتو": "Crypto",
    "منتظر تصمیم شما": "Waiting for your decision",
    "جزئیات": "Details",
    "بگیرش": "Take it",
    "نمی‌گیرم": "Skip",
    "فا": "FA",
    "حذف": "Delete",
    "خبر": "News",
    "مالک": "Owner",
    "نسخه": "Version",
    "وویس": "Voice message",
    "تصویر": "Image",
    "دقیقه": "minutes",
    "مسئول": "Assignee",
    "ویدئو": "Video",
    "گرفتم": "Taken",
    "تا خبر": "until event",
    "نسخه ۱": "Revision 1",
    "نگرفتم": "Skip",
    "ساخت PDF": "Generate PDF",
    "سود/زیان": "Profit/Loss",
    "فایل/PDF": "File/PDF",
    "اخبار مهم": "Important news",
    "ذخیره نام": "Save name",
    "سقف هفتگی": "Weekly limit",
    "فایل صوتی": "Audio file",
    "میز اعلان": "Announcement Desk",
    "ویرایش صف": "Edit queue",
    "ارسال پاسخ": "Send reply",
    "تحلیل شخصی": "Personal analysis",
    "مرکز کمپین": "Campaign Center",
    "هشدار قیمت": "Price alert",
    "همگام‌سازی": "Synchronize",
    "خطای انتشار": "Publishing error",
    "خلاصه هفتگی": "Weekly digest",
    "گزارش بازار": "Market report",
    "ارسال سیگنال": "Send signal",
    "از خبر گذشته": "since event",
    "خلاصه روزانه": "Daily digest",
    "روز معاملاتی": "trading days",
    "سیگنال کانال": "Channel signal",
    "نتایج سیگنال": "Signal results",
    "کنسول عملیات": "Operations Console",
    "روزهای معامله": "Trading days",
    "یادداشت داخلی": "Internal note",
    "ادمین SENTINEL": "SENTINEL Admin",
    "انتشار لغو شد.": "Publishing was cancelled.",
    "تغییر نام دوره": "Rename period",
    "دلیل رد پرداخت": "Payment rejection reason",
    "ذخیره پیش‌نویس": "Save draft",
    "کمپین ایجاد شد": "Campaign created",
    "گرفتم و ثبت کن": "Take and record",
    "در انتظار بررسی": "Awaiting review",
    "قالب‌های سیگنال": "Signal templates",
    "آخرین قیمت معتبر": "Latest valid price",
    "بازکردن و مدیریت": "Open and manage",
    "خروجی PDF ژورنال": "Journal PDF export",
    "سیگنال گرفته‌شده": "Taken signals",
    "قوانین حساب پراپ": "Prop account rules",
    "تیکت پشتیبانی باز": "Open support ticket",
    "تیکت‌های پشتیبانی": "Support tickets",
    "صف، تحویل و خطاها": "Queue, delivery and errors",
    "پرداخت و رسید VIP": "VIP payment and receipt",
    "پس‌زمینه و چیدمان": "Background and layout",
    "پشتیبانی SENTINEL": "SENTINEL Support",
    "انتشار امن اطلاعیه": "Secure announcement publishing",
    "سفارش در حال بررسی": "Order under review",
    "مرکز دقیق کمپین‌ها": "Campaign Operations Center",
    "وضعیت تمام ماژول‌ها": "Status of all modules",
    "پاسخ مدیر آماده است": "Admin reply is ready",
    "پیگیری ارسال سیگنال": "Signal delivery tracking",
    "حاکمیت، شیفت و سلامت": "Governance, shifts and health",
    "رسید را انتخاب کنید.": "Select a receipt.",
    "مدیریت کامل پشتیبانی": "Full support management",
    "مشاهده و پاسخ دوطرفه": "View and reply in both directions",
    "نکته آموزشی تحلیل‌گر": "Analyst coaching note",
    "گرفته شد · در ژورنال": "Taken · Journaled",
    "ساخت قالب قوانین پراپ": "Create Prop rules template",
    "سیگنال‌های محاسبه‌شده": "Calculated signals",
    "نمادهای موقتاً ناموفق": "Temporarily failed symbols",
    "هشدار نقض قوانین پراپ": "Prop rule breach alert",
    "تأیید یا رد از مینی‌اپ": "Approve or reject in Mini App",
    "محاسبه‌گر حجم SENTINEL": "SENTINEL Position Size Calculator",
    "مرکز اطلاع‌رسانی کانال": "Channel Communications Center",
    "همگام‌سازی فقط‌خواندنی": "Read-only synchronization",
    "دسترسی فقط‌خواندنی": "Read-only access",
    "مشاهده تیکت": "View ticket",
    "نقش در فرم اعمال شد؛ برای ثبت، ذخیره را بزنید.": "Role applied to the form; press Save to persist.",
    "وضعیت اتصال قابل مشاهده است؛ اجرای تطبیق نیازمند کنترل کامل سیستم است.": "Integration health is visible; reconciliation requires full system control.",
    "وضعیت انتشار سیگنال‌ها": "Signal publishing status",
    "این سیگنال را گرفته‌اید": "You took this signal",
    "تأیید دستی و ارسال لینک": "Manual approval and link delivery",
    "ساخت، ارسال و آمار دقیق": "Create, deliver and measure precisely",
    "مهلت پاسخ SLA گذشته است": "SLA response deadline has passed",
    "جزئیات ماژول‌های مدیریتی": "Administrative module details",
    "لغو از پنل ادمین مینی‌اپ": "Cancelled from the Mini App admin panel",
    "گزارش PDF دوره آماده شد.": "Period PDF report is ready.",
    "گزارش ممیزی قابل جست‌وجو": "Searchable audit log",
    "این سیگنال را رد کرده‌اید": "You skipped this signal",
    "سیگنال دوباره وارد صف شد.": "The signal was queued again.",
    "ویرایش مقصد و زمان انتشار": "Edit destination and publishing time",
    "متن یا فایل را اضافه کنید.": "Add text or a file.",
    "متن یا یک فایل اضافه کنید.": "Add text or a file.",
    "گزارش PDF ژورنال آماده شد.": "Journal PDF report is ready.",
    "ابتدا تصویر را انتخاب کنید.": "Select an image first.",
    "ساخت کمپین قابل‌اندازه‌گیری": "Create a measurable campaign",
    "حداقل یک ارز را انتخاب کنید.": "Select at least one currency.",
    "دسترسی، اتصال و زیرسامانه‌ها": "Access, connectivity and subsystems",
    "ظرفیت ریسک حساب تمام شده است": "The account has no remaining risk capacity",
    "SENTINEL | سیستم مدیریت معامله": "SENTINEL | Trading Management System",
    "دوره با موفقیت به‌روزرسانی شد.": "The period was updated successfully.",
    "مدیریت تیکت‌های ربات و مینی‌اپ": "Manage Bot and Mini App tickets",
    "انتشار در کانال، ربات و مینی‌اپ": "Publish to channel, Bot and Mini App",
    "بستن دوره فعلی و شروع دوره جدید": "Close current period and start a new one",
    "حداکثر حجم فایل ۱۵ مگابایت است.": "The maximum file size is 15 MB.",
    "مرکز تمرین معامله و مدیریت ریسک": "Trading Practice and Risk Management Center",
    "دوره بسته و در آرشیو نگهداری شد.": "The period was closed and retained in the archive.",
    "سیگنال در کانال و مینی‌اپ ثبت شد.": "The signal was recorded in the channel and Mini App.",
    "ظرفیت ریسک روزانه رو به پایان است": "Daily risk capacity is nearly exhausted",
    "اطلاعات فقط‌خواندنی بروکر همگام شد": "Read-only broker data was synchronized",
    "تغییر مهم سیگنال نیاز به تأیید دارد": "An important signal revision requires acknowledgement",
    "کمپین در صف پایدار انتشار قرار گرفت": "The campaign was placed in the durable publishing queue",
    "دوره فعلی بسته و دوره جدید آغاز شود؟": "Close the current period and start a new one?",
    "پروفایل معامله‌گری خود را تکمیل کنید": "Complete your trading profile",
    "انتشار از صف امن ربات در حال انجام است…": "Publishing through the Bot secure queue…",
    "برای این سیگنال قبلاً تصمیم ثبت شده است.": "A decision has already been recorded for this signal.",
    "نسخه جدید آماده است؛ برنامه را باز کنید.": "A new version is ready; reopen the app.",
    "دوره فعلی بسته شود؟ هیچ سیگنالی حذف نخواهد شد.": "Close the current period? No signals will be deleted.",
    "اطلاعات مشترک ربات و مینی‌اپ دوباره تطبیق داده شد.": "Shared Bot and Mini App data was reconciled again.",
    "ژورنال مشترک ربات و مینی‌اپ با نتیجه R و دلیل ورود.": "A shared Bot and Mini App journal with R result and entry rationale.",
    "خلاصه روشن ریسک، معاملات گرفته‌شده و ظرفیت باقی‌مانده.": "A clear summary of risk, taken trades and remaining capacity.",
    "معامله‌های شخصی و سیگنال‌های کانال در یک ژورنال مشترک.": "Personal trades and channel signals in one shared journal.",
    "هر سیگنال را با وضعیت لحظه‌ای و اثر آن روی حساب بررسی کن.": "Review every signal with live status and its effect on your account.",
    "ریسک واقعی پوزیشن‌ها، قوانین پراپ و بدترین سناریو در یک نما.": "Actual position risk, Prop rules and worst-case scenario in one view.",
    "این تصمیم قفل شده و دوباره سیگنال یا ژورنال جدید ایجاد نمی‌شود.": "This decision is locked and will not create another signal or journal entry.",
    "SENTINEL — سیستم‌عامل مستقل مدیریت سیگنال، ریسک، ژورنال و شفافیت عملکرد": "SENTINEL — independent signal, risk, journal and verified-performance operating system",
    "اول ظرفیت ریسک این هفته را ببین؛ جزئیات پیشرفته فقط در صورت نیاز باز می‌شوند.": "Check this week’s risk capacity first; advanced details open only when needed.",
    "در حال بررسی ورود امن تلگرام…": "Checking secure Telegram login…",
    "اتصال بیشتر از حد معمول طول کشید؛ تلاش در پس‌زمینه ادامه دارد.": "Connection is taking longer than expected; retry continues in the background.",
    "در حال اتصال به SENTINEL": "Connecting to SENTINEL",
    "لودر پس از ۱۰ ثانیه بسته شد. اتصال امن در پس‌زمینه ادامه دارد.": "The loader closed after 10 seconds. Secure connection continues in the background.",
    "اطلاعات ورود تلگرام هنوز دریافت نشده است؛ صفحه را ببندید و از دکمه پایین ربات دوباره وارد شوید.": "Telegram login data has not arrived yet. Close this page and reopen it from the Bot button.",
    "اطلاعات ورود تلگرام دریافت نشد؛ از دکمه Mini App داخل ربات وارد شوید.": "Telegram login data was not received. Open the Mini App from the Bot.",
    "ورود امن تلگرام تکمیل نشده است": "Secure Telegram login is incomplete",
    "ورود به SENTINEL تکمیل نشد": "SENTINEL login was not completed",
    "این صفحه را کامل ببندید.": "Close this page completely.",
    "به گفت‌وگوی ربات برگردید.": "Return to the Bot chat.",
    "دکمه SENTINEL پایین صفحه یا دکمه Mini App داخل منو را بزنید.": "Tap the SENTINEL button at the bottom or the Mini App button in the menu.",
    "تلاش دوباره": "Try again",
    "بستن مینی‌اپ": "Close Mini App",
    "جزئیات تشخیص": "Diagnostic details",
    "خبر و بازار": "News and Market",
    "تحلیل بازار": "Market Analysis",
    "عملکرد قابل راستی‌آزمایی": "Verifiable Performance",
    "مرکز کاربر": "User Center",
    "تمام ابزارها و تنظیمات در یک نمای مرتب.": "All tools and settings in one organized view.",
    "هیچ داده‌ای برای نمایش وجود ندارد.": "No data to display.",
    "بارگذاری بیشتر": "Load more",
    "عملیات با موفقیت انجام شد": "Operation completed successfully",
    "خطایی رخ داد": "Something went wrong",
    "فعال‌سازی رایگان": "Free activation",
    "در انتظار ادمین": "Waiting for admin",
    "پاسخ داده شد": "Answered",
    "بسته": "Closed",
    "پاسخ ادمین آماده است": "Admin reply is ready",
    "در انتظار بررسی پشتیبانی": "Waiting for support review",
    "بازار جهانی": "Global markets",
    "بازار ایران": "Iran market",
    "اطمینان": "Confidence",
    "نوسان": "Volatility",
    "سشن": "Session",
    "افزودن نماد به واچ‌لیست": "Add symbol to watchlist",
    "اعلان دستگاه فعال شد": "Device notifications enabled",
    "مجوز اعلان داده نشد": "Notification permission was not granted",
    "اعلان سیستم در این دستگاه پشتیبانی نمی‌شود": "System notifications are not supported on this device",
    "گرفتم / ثبت ورود": "Take / Record entry",
    "مشاهده همه": "View all",
    "آخرین محتوای کانال": "Latest channel content",
    "لغو TP": "Cancel TP",
    "سر‌به‌سر": "Break even",
    "تغییر SL": "Move SL",
    "لغو معامله": "Cancel trade",
    "ابتدا یک حساب آزمایشی بسازید.": "Create a paper account first.",
    "معاملات و تمام سناریوهای خروج": "Trades and all exit scenarios",
    "مربی رفتار و ریسک متصل به سیگنال‌ها": "Behavior and risk coach connected to signals",
    "ریسک فعال": "Active risk",
    "بدون نقض فعال": "No active breach",
    "نام حساب": "Account name",
    "حساب تمرینی": "Paper account",
    "سرمایه اولیه": "Starting balance",
    "TPها (با ویرگول)": "TPs (comma-separated)",
    "ریسک %": "Risk %",
    "SL جدید": "New SL",
    "ثبت معامله": "Record trade",
    "تیکت": "ticket",
    "دسته": "Category",
    "اولویت": "Priority",
    "شناسه مدیر مسئول": "Assigned admin ID",
    "فقط تیکت‌های عبورکرده از SLA": "Overdue SLA tickets only",
    "اعمال فیلتر": "Apply filters",
    "مدیر مسئول": "Assigned admin",
    "یادداشت‌های داخلی": "Internal notes",
    "مدیر": "Administrator",
    "تخصیص به مدیر": "Assign to admin",
    "تخصیص": "Assign",
    "اولویت و SLA": "Priority and SLA",
    "به‌روزرسانی": "Update",
    "یادداشت داخلی (برای کاربر نمایش داده نمی‌شود)": "Internal note (hidden from user)",
    "ثبت یادداشت": "Save note",
    "بازگشایی": "Reopen",
    "حساب‌ها": "Accounts",
    "همه حساب‌ها": "All accounts",
    "وضعیت": "Status",
    "از تاریخ": "From date",
    "تا تاریخ": "To date",
    "شروع سکوت": "Quiet start",
    "پایان سکوت": "Quiet end",
    "توقف موقت (ساعت)": "Pause for hours",
    "ساعات سکوت فعال": "Quiet hours enabled",
    "بازارها (forex, crypto)": "Markets (Forex, Crypto)",
    "نمادهای خاص": "Specific symbols",
    "اختیاری": "optional",
    "تأیید پرداخت فقط بر اساس رسید و بررسی دستی ادمین است.": "Payment approval is based on the receipt and manual admin review.",
    "ارسال مجدد رایگان؛ رسید لازم نیست ولی تأیید ادمین الزامی است.": "Free resubmission; no receipt is required, but admin approval is required."
});
Object.assign(UI_EN_EXACT, { 'اشتراک شما فعال است': 'Your subscription is active', 'بازار': 'Market', 'موجودی دلار': 'Balance in USD', 'قیمت ورود': 'Entry price', 'اهرم': 'Leverage', 'کارمزد رفت‌وبرگشت %': 'Round-trip fee %', 'محاسبه امن': 'Calculate safely', 'مدیریت SENTINEL': 'SENTINEL Administration', 'فقط ابزارهای مجاز برای این مدیر': 'Only tools authorized for this administrator', '2350 یا 2350,2347': '2350 or 2350,2347', 'قیمت معتبر دریافت نشد.': 'No valid price was received.', 'سیگنال از مسیر امن ربات منتشر و همان لحظه در کانال و مینی‌اپ ثبت می‌شود.': 'The signal is published through the Bot secure path and recorded instantly in the channel and Mini App.', 'هر ارسال تا نتیجه نهایی قابل ردیابی است.': 'Every delivery remains traceable through its final outcome.', 'کل': 'Total', 'زمان‌بندی': 'Scheduled', 'کمپین جدید': 'New campaign', 'مدیریت ریسک': 'Risk management', 'امکانات بیشتر': 'More tools', 'ژورنال معاملاتی': 'Trading journal' });

Object.assign(UI_EN_EXACT, {
    'استاپ': 'Stop',
    'افزودن ادمین جدید': 'Add new administrator',
    'افزودن و سطح دسترسی': 'Add and manage access',
    'افزودن و مدیریت ادمین‌ها': 'Add and manage administrators',
    'این ادمین حذف شود؟': 'Remove this administrator?',
    'این سیگنال برای همیشه حذف شود؟': 'Permanently delete this signal?',
    'بازکردن نتیجه': 'Reset result',
    'بستن بخشی': 'Partial close',
    'بستن دستی': 'Manual close',
    'تأیید مسدودی': 'Confirm ban',
    'تارگت': 'Target',
    'ثبت نتیجه': 'Set result',
    'ثبت نتیجه سیگنال': 'Set signal result',
    'جست‌وجو، VIP و مسدودی': 'Search, VIP and bans',
    'حداقل یک مجوز انتخاب کنید.': 'Select at least one permission.',
    'حذف کامل': 'Delete permanently',
    'رفع مسدودی': 'Unban',
    'ریسک‌فری': 'Break even',
    'مدیریت ادمین‌ها': 'Admin access',
    'مدیریت سیگنال‌ها': 'Manage signals',
    'مدیریت سیگنال‌های منتشرشده': 'Published signal management',
    'مدیریت و کنترل کاربران': 'User management and control',
    'مسدودسازی': 'Ban user',
    'مسدودسازی کاربر': 'Ban user',
    'نتیجه قبلی پاک و سیگنال دوباره باز شود؟': 'Clear the previous result and reopen this signal?',
    'ورود نداده': 'No entry',
    'ویرایش سیگنال': 'Edit signal',
    'ویرایش مجوزهای ادمین': 'Edit administrator permissions',
    'ویرایش، نتیجه و حذف': 'Edit, result and delete',
    'کنترل کاربران': 'User control',
    'کنسل‌شده': 'Cancelled',
    'مربی هوشمند شخصی': 'Personal AI coach',
    'مرکز فرماندهی هوش مصنوعی': 'AI Command Center',
    'مرکز هوش مصنوعی': 'AI Center',
    'مدیریت انسانی پلن‌های VIP': 'Human VIP plan management',
    'مدیریت پلن‌های VIP': 'VIP plan management',
    'ساخت پلن جدید': 'Create new plan',
    'ساخت پلن': 'Create plan',
    'ویرایش پلن': 'Edit plan',
    'ذخیره تغییرات': 'Save changes',
    'فروش': 'Sales',
    'مخاطب': 'Audience',
    'روز': 'days',
    'تأیید انسانی': 'Human approval',
    'رد پیشنهاد': 'Reject proposal',
    'این پیشنهاد فقط پس از تأیید انسانی اجرا شود؟': 'Execute this proposal only after human approval?',
    'پلن بدون سابقه فروش حذف شود؟': 'Delete this plan only if it has no sales history?',
    'AI کاربران: فقط VIP': 'User AI: VIP only',
    'AI کاربران: همه': 'User AI: everyone',
    'برای همه کاربران فعال': 'Available to all users',
    'فقط کاربران VIP': 'VIP users only',
    'بررسی هوشمند حساب': 'Smart account review',
    'تست زنده انجام شد': 'Live test completed',
    'حالت دسترسی کاربران بین فقط VIP و همه تغییر کند؟': 'Switch user AI access between VIP only and everyone?',
    'گزارش روزانه مدیر': 'Daily manager report',
    'اجرای ابزارها با کلید اضطراری متوقف شده است.': 'Tool execution is stopped by the emergency switch.',
    'اجرای دستورات Gemini فعال شود؟': 'Enable Gemini tool execution?',
    'اجرای دستورات Gemini فوراً متوقف شود؟': 'Immediately stop Gemini tool execution?',
    'تأیید ادمین': 'Approve admin',
    'تأیید و اجرا': 'Approve and execute',
    'دستورات ادمین اصلی بدون تأیید اضافه اجرا می‌شوند.': 'Primary-admin commands execute without extra confirmation.',
    'دستورات شما برای تأیید ادمین اصلی ارسال می‌شوند.': 'Your commands are sent to the primary admin for approval.',
    'دلیل رد ادمین:': 'Administrator rejection reason:',
    'دلیل رد دستور:': 'Command rejection reason:',
    'رد درخواست': 'Reject request',
    'رد دستور': 'Reject command',
    '⛔ توقف اجرای AI': '⛔ Stop AI execution',
    '✅ فعال‌کردن اجرای AI': '✅ Enable AI execution',
    'اطلاعات مبلغ پرداخت ناقص است؛ دوباره تلاش کنید.': 'Payment quote data is incomplete; please try again.',
    'تنظیمات پرداخت و پیش‌فرض VIP': 'VIP payment and default settings',
    'ذخیره تنظیمات': 'Save settings',
    'سیگنال بسته شده': 'Signal closed',
    'شماره کارت، نام و قیمت پیش‌فرض': 'Card number, owner name and default price',
    'نمایش مبلغ و اطلاعات پرداخت': 'Show amount and payment information',
    'پلن‌ها و تنظیمات پرداخت VIP': 'VIP plans and payment settings'
});

Object.assign(UI_EN_EXACT, {
    "استاپ لاس": "Stop loss",
    "بریک ایون شد": "Moved to break-even",
    "بستن بخشی انجام شد": "Partial close executed",
    "به‌دلیل بسته‌شدن سیگنال دیگر امکان ثبت «گرفتم / نگرفتم» وجود ندارد.": "Take / skip is disabled because the signal is closed.",
    "تارگت ثبت شد": "Target reached",
    "تمام تارگت‌ها کامل شد": "All targets reached",
    "تی پی ۱": "TP1",
    "تی پی ۱ خورد": "TP1 hit",
    "تی پی ۲": "TP2",
    "تی پی ۲ خورد": "TP2 hit",
    "حد ضرر فعال شد": "Stop loss hit",
    "رخداد": "events",
    "زیان ثبت شد": "Loss recorded",
    "سود کامل ثبت شد": "Full profit booked",
    "سیگنال بسته شده است": "Signal is closed",
    "سیگنال دستی بسته شد": "Signal manually closed",
    "سیگنال لغو شد": "Signal cancelled",
    "سیگنال منقضی شد": "Signal expired",
    "فول تی پی": "Full TP",
    "قالب سیگنال فعال": "Live signal card",
    "نقطه ورود فعال شد": "Entry activated",
    "ورود فعال شد": "Entry hit",
    "ورودی فعال نشد": "No entry",
    "با ثبت معاملات بیشتر، الگوهای رفتاری دقیق‌تر می‌شوند.": "More journal entries will improve behavioral pattern detection."
});

const UI_EN_DYNAMIC_PATTERNS = [
    [/^(.+)\s+فارکس\s*·\s*(.+)\s+کریپتو$/u, '$1 Forex · $2 Crypto'],
    [/^(.+)%\s+ظرفیت روزانه$/u, '$1% daily capacity'],
    [/^(.+)\s+معامله باز\s*·\s*(.+)%\s+نرخ برد ژورنال$/u, '$1 open trades · $2% journal win rate'],
    [/^(.+)\s*·\s*فارکس$/u, '$1 · Forex'],
    [/^(.+)\s*·\s*کریپتو$/u, '$1 · Crypto'],
    [/^فارکس\s*·\s*(.+)$/u, 'Forex · $1'],
    [/^کریپتو\s*·\s*(.+)$/u, 'Crypto · $1'],
    [/^(.+)\s+دقیقه$/u, '$1 minutes'],
    [/^(.+)\s+تا خبر$/u, '$1 until event'],
    [/^(.+)\s+از خبر گذشته$/u, '$1 since event'],
    [/^نسخه\s+(.+)$/u, 'Revision $1'],
    [/^(.+)\s+روز معاملاتی$/u, '$1 trading days'],
    [/^(.+)\s+سیگنال$/u, '$1 signals'],
    [/^(.+)\s+تیکت$/u, '$1 tickets'],
    [/^(.+)\s+عملیات واقعی و مجاز$/u, '$1 authorized executable actions'],
    [/^(.+)\s+معامله باز$/u, '$1 open trades']
];
function translateUiText(value) {
    const raw = String(value ?? '');
    if (state.lang !== 'en' || !/[\u0600-\u06ff]/u.test(raw)) return raw;
    const leading = raw.match(/^\s*/u)?.[0] || '';
    const trailing = raw.match(/\s*$/u)?.[0] || '';
    const trimmed = raw.trim();
    const key = Object.keys(I18N.fa).find(k => I18N.fa[k] === trimmed);
    let translated = key ? I18N.en[key] : UI_EN_EXACT[trimmed];
    if (!translated) {
        for (const [pattern, replacement] of UI_EN_DYNAMIC_PATTERNS) {
            if (pattern.test(trimmed)) { translated = trimmed.replace(pattern, replacement); break; }
        }
    }
    return translated ? `${leading}${translated}${trailing}` : raw;
}
const uiOriginalText = new WeakMap();
const uiOriginalAttrs = new WeakMap();
function localizeUiTree(root = document) {
    const target = root?.nodeType ? root : document;
    const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    for (const node of textNodes) {
        const parent = node.parentElement;
        if (!parent || ['SCRIPT', 'STYLE', 'CODE', 'PRE'].includes(parent.tagName) || parent.closest('[data-preserve-language]')) continue;
        if (!uiOriginalText.has(node) && /[\u0600-\u06ff]/.test(node.nodeValue || '')) uiOriginalText.set(node, node.nodeValue);
        if (state.lang === 'en') node.nodeValue = translateUiText(uiOriginalText.get(node) ?? node.nodeValue);
        else if (uiOriginalText.has(node)) node.nodeValue = uiOriginalText.get(node);
    }
    const elements = target.nodeType === Node.ELEMENT_NODE ? [target, ...target.querySelectorAll('*')] : [...document.querySelectorAll('*')];
    for (const el of elements) {
        if (el.closest?.('[data-preserve-language]')) continue;
        let originals = uiOriginalAttrs.get(el);
        for (const attr of ['aria-label', 'placeholder', 'title', 'alt']) {
            if (!el.hasAttribute?.(attr)) continue;
            const value = el.getAttribute(attr) || '';
            if (!originals && /[\u0600-\u06ff]/.test(value)) { originals = {}; uiOriginalAttrs.set(el, originals); }
            if (originals && originals[attr] == null && /[\u0600-\u06ff]/.test(value)) originals[attr] = value;
            if (state.lang === 'en' && originals?.[attr] != null) el.setAttribute(attr, translateUiText(originals[attr]));
            else if (state.lang === 'fa' && originals?.[attr] != null) el.setAttribute(attr, originals[attr]);
        }
    }
}
let uiLocalizationObserver = null;
function ensureUiLocalizationObserver() {
    if (uiLocalizationObserver || !document.body) return;
    uiLocalizationObserver = new MutationObserver(records => {
        if (state.lang !== 'en') return;
        for (const record of records) for (const node of record.addedNodes) if (node.nodeType === Node.ELEMENT_NODE || node.nodeType === Node.TEXT_NODE) localizeUiTree(node);
    });
    uiLocalizationObserver.observe(document.body, { childList: true, subtree: true });
}
const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
const num = (v, d = 2) => { const n = Number(v); return Number.isFinite(n) ? new Intl.NumberFormat(state.lang === 'fa' ? 'fa-IR' : 'en-US', { maximumFractionDigits: d }).format(n) : '—'; };
const pct = (v, d = 2) => `${num(v, d)}%`;
const money = (v, c = 'USD') => { const n = Number(v); if (!Number.isFinite(n))
    return '—'; return `${num(n, 2)} ${esc(c)}`; };
const date = v => { if (!v)
    return '—'; const d = new Date(v); return Number.isNaN(d.getTime()) ? '—' : new Intl.DateTimeFormat(state.lang === 'fa' ? 'fa-IR' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' }).format(d); };
const icon = id => `<svg aria-hidden="true"><use href="#i-${id}"/></svg>`;
const unwrap = r => r?.ok && Object.prototype.hasOwnProperty.call(r, 'data') ? r.data : r;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const FEATURE_KEY = { signals: 'signals', risk: 'portal', journal: 'journal', market: 'watchlists', calendar: 'calendar', vip: 'subscriptions', orders: 'subscriptions', support: 'support', notifications: 'notify', track: 'signals', revisions: 'signals' };
function featureEnabled(key) { const module = FEATURE_KEY[key] || key; const row = state.resources.overview?.features?.[module]; return !row || row.enabled !== false; }
function disabledPanel() { return `<div class="panel"><div class="empty">${icon('lock')}<h2>${esc(t('notAvailable'))}</h2><p>${esc(t('maintenance'))}</p></div></div>`; }
function featureDisabledModal() { openModal('FEATURE', t('notAvailable'), disabledPanel(), []); }
function setBusy(on, label = t('loading')) { state.busy += on ? 1 : -1; state.busy = Math.max(0, state.busy); const el = $('#busyOverlay'); el.hidden = !state.busy; if (label)
    $('span', el).textContent = label; }
function toast(message, type = '') { const el = $('#toast'); el.textContent = message; el.className = `toast ${type}`; requestAnimationFrame(() => el.classList.add('show')); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2600); }
function errorSummary(message) { const el = $('#errorSummary'); el.textContent = message; el.hidden = !message; if (message)
    el.focus(); }
function setConnection(mode, text) { const el = $('#connectionBar'); el.className = `connection-bar ${mode}`; $('span', el).textContent = text || ({ online: t('secure'), offline: t('offline'), loading: t('loading') }[mode]); state.online = mode === 'online'; }
let authRefreshInflight = null;
async function renewAuthenticatedSession() { if (authRefreshInflight)
    return authRefreshInflight; authRefreshInflight = (async () => { try {
        const auth = await request('./api/v1/auth/session', { authRecovery: false }, 6500);
        if (!auth?.csrf_token)
            throw new Error('CSRF_REFRESH_FAILED');
        state.csrf = auth.csrf_token;
        return auth;
    }
    catch {
        const initData = await waitForTelegramInitData(1800);
        if (!initData)
            throw Object.assign(new Error(state.lang === 'fa' ? 'برای تمدید نشست، مینی‌اپ را دوباره از تلگرام باز کنید.' : 'Reopen the Mini App from Telegram to renew your session.'), { code: 'INIT_DATA_MISSING' });
        const auth = await request('./api/v1/auth/bootstrap', { method: 'POST', headers: { 'X-Telegram-Init-Data': initData }, authRecovery: false }, 20000);
        if (!auth?.csrf_token)
            throw new Error('CSRF_REFRESH_FAILED');
        state.csrf = auth.csrf_token;
        return auth;
    } })(); try {
        return await authRefreshInflight;
    }
    finally {
        authRefreshInflight = null;
    } }
async function request(path, options = {}, timeout = 20000) { const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), timeout); const { authRecovery = true, ...fetchOptions } = options; try {
    const headers = { Accept: 'application/json', ...(fetchOptions.headers || {}) };
    if (state.lang)
        headers['Accept-Language'] = state.lang;
    if (options.csrf && state.csrf)
        headers['X-CSRF-Token'] = state.csrf;
    const res = await fetch(path, { credentials: 'include', ...fetchOptions, headers, signal: ctl.signal });
    const text = await res.text();
    let body = {};
    try {
        body = text ? JSON.parse(text) : {};
    }
    catch {
        body = { error: { code: 'INVALID_RESPONSE', message: text.slice(0, 180) } };
    }
    if (!res.ok || body?.ok === false) {
        const err = body?.error || {};
        const e = new Error(err.message || err.code || `HTTP ${res.status}`);
        e.code = err.code || `HTTP_${res.status}`;
        e.requestId = err.request_id || res.headers.get('X-Request-ID');
        throw e;
    }
    setConnection('online');
    return unwrap(body);
}
catch (err) {
    if (err.name === 'AbortError')
        err.message = state.lang === 'fa' ? 'زمان پاسخ سرور تمام شد.' : 'Request timed out.';
    if (authRecovery && !String(path).includes('/api/v1/auth/') && ['UNAUTHORIZED', 'CSRF_INVALID'].includes(String(err?.code || ''))) {
        await renewAuthenticatedSession();
        return request(path, { ...options, authRecovery: false }, timeout);
    }
    if (!navigator.onLine)
        setConnection('offline');
    throw err;
}
finally {
    clearTimeout(timer);
} }
async function action(name, payload = {}, showBusy = true) { const flightKey = `${name}:${JSON.stringify(payload)}`; if (actionInflight.has(flightKey))
    return actionInflight.get(flightKey); if (showBusy)
    setBusy(true); const requestId = `${name}:${Date.now()}:${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}`; const task = request(`./api/v1/actions/${encodeURIComponent(name)}`, { method: 'POST', csrf: true, headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId }, body: JSON.stringify({ payload, request_id: requestId }) }, 30000); actionInflight.set(flightKey, task); try {
    const envelope = await task;
    return envelope && typeof envelope === 'object' && Object.prototype.hasOwnProperty.call(envelope, 'action') && Object.prototype.hasOwnProperty.call(envelope, 'data') ? envelope.data : envelope;
}
finally {
    actionInflight.delete(flightKey);
    if (showBusy)
        setBusy(false);
} }
function telegramInitDataFromLocation() { for (const raw of [location.hash.slice(1), location.search.slice(1)]) {
    if (!raw)
        continue;
    try {
        const value = new URLSearchParams(raw).get('tgWebAppData');
        if (value && value.includes('hash='))
            return value;
    }
    catch { }
} return ''; }
async function waitForTelegramInitData(timeout = 6000) { const deadline = Date.now() + timeout; do {
    tg = window.Telegram?.WebApp || tg;
    const value = String(tg?.initData || telegramInitDataFromLocation() || '').trim();
    if (value)
        return value;
    await sleep(120);
} while (Date.now() < deadline); return ''; }
function handleTelegramBack() {
    if (!$('#modalLayer')?.hidden) {
        closeModal();
        return;
    }
    // No in-app route owns Back at the root. Releasing the bridge lets
    // Telegram/Android handle the system Back gesture normally.
    releaseTelegramNavigation(true);
}
function syncTelegramNavigation() {
    tg = window.Telegram?.WebApp || tg;
    try {
        tg?.disableClosingConfirmation?.();
        tg?.enableVerticalSwipes?.();
        const modalOpen = Boolean($('#modalLayer') && !$('#modalLayer').hidden);
        state.telegramBackMode = modalOpen ? 'modal' : 'none';
        if (modalOpen) {
            if (!state.telegramNavigationInstalled) {
                tg?.BackButton?.offClick?.(handleTelegramBack);
                tg?.BackButton?.onClick?.(handleTelegramBack);
                state.telegramNavigationInstalled = true;
            }
            tg?.BackButton?.show?.();
            if (state.mainButtonHandler) {
                tg?.MainButton?.offClick?.(state.mainButtonHandler);
                tg?.MainButton?.onClick?.(state.mainButtonHandler);
                tg?.MainButton?.show?.();
            }
        }
        else {
            tg?.BackButton?.offClick?.(handleTelegramBack);
            state.telegramNavigationInstalled = false;
            tg?.BackButton?.hide?.();
            tg?.MainButton?.hide?.();
        }
    }
    catch { }
}
function installTelegramNavigation() {
    tg = window.Telegram?.WebApp || tg;
    if (!tg?.BackButton) return;
    syncTelegramNavigation();
}
function releaseTelegramNavigation(detach = false) {
    tg = window.Telegram?.WebApp || tg;
    try {
        tg?.disableClosingConfirmation?.();
        tg?.enableVerticalSwipes?.();
        tg?.BackButton?.hide?.();
        tg?.MainButton?.hide?.();
        if (state.mainButtonHandler) tg?.MainButton?.offClick?.(state.mainButtonHandler);
        state.telegramBackMode = 'none';
        if (detach) {
            tg?.BackButton?.offClick?.(handleTelegramBack);
            state.telegramNavigationInstalled = false;
        }
    }
    catch { }
}
function prepareTelegramChrome() { tg = window.Telegram?.WebApp || tg; tg?.ready?.(); tg?.expand?.(); try {
    tg?.setHeaderColor?.('#03080d');
    tg?.setBackgroundColor?.('#03080d');
    tg?.setBottomBarColor?.('#03080d');
    tg?.disableClosingConfirmation?.();
    tg?.enableVerticalSwipes?.();
    tg?.BackButton?.hide?.();
    installTelegramNavigation();
}
catch { } }
async function activateAuthenticatedShell(auth) { state.preview = false; state.csrf = auth?.csrf_token || ''; state.loaded.clear(); $('#app')?.classList.remove('auth-required'); $('#previewBanner').hidden = true; errorSummary(''); await loadOverview(true); finishSplash(); renderChrome(); connectEvents(); startLivePricePolling(); await applyDeepLink(); setTimeout(maybeShowOnboarding, 360); setTimeout(async () => { try {
    const feed = await loadResource('feed', true);
    checkFeedUpdates(feed?.items || [], true);
    if (state.page === 'home')
        renderHome();
}
catch { } }, 40); }
async function authenticateWithTelegram(initData) { const auth = await request('./api/v1/auth/bootstrap', { method: 'POST', headers: { 'X-Telegram-Init-Data': initData } }, 20000); await activateAuthenticatedShell(auth); }
async function signedSessionAuth() { return request('./api/v1/auth/session', {}, 6500); }
async function resumeSignedSession() { const auth = await signedSessionAuth(); await activateAuthenticatedShell(auth); }
function isRecoverableTelegramAuthError(err) { return ['INIT_DATA_MISSING', 'INIT_DATA_EXPIRED', 'INIT_DATA_REPLAYED', 'RATE_LIMITED'].includes(String(err?.code || '')); }
function renderAccessGate(err) { state.preview = true; state.online = false; state.eventSource?.close?.(); state.eventSource = null; clearInterval(state.livePriceTimer); const message = err?.message || 'اطلاعات ورود تلگرام دریافت نشد.'; const code = err?.code || 'INIT_DATA_MISSING'; $('#app').classList.add('auth-required'); $('#previewBanner').hidden = true; errorSummary(''); setConnection('offline', 'ورود امن تلگرام تکمیل نشده است'); $('#page-home').innerHTML = `<section class="auth-gate" aria-labelledby="authGateTitle"><div class="auth-gate-icon">${icon('shield')}</div><small>SECURE TELEGRAM ACCESS</small><h1 id="authGateTitle">ورود به SENTINEL تکمیل نشد</h1><p>${esc(message)}</p><ol><li>این صفحه را کامل ببندید.</li><li>به گفت‌وگوی ربات برگردید.</li><li>دکمه <strong>SENTINEL</strong> پایین صفحه یا دکمه Mini App داخل منو را بزنید.</li></ol><div class="auth-gate-actions"><button class="button primary" type="button" data-auth-retry>${icon('refresh')} تلاش دوباره</button>${tg?.close ? `<button class="button secondary" type="button" data-close-app>بستن مینی‌اپ</button>` : ''}</div><details><summary>جزئیات تشخیص</summary><code>${esc(code)}</code><span>${tg ? 'Telegram WebView شناسایی شد؛ اطلاعات امضاشده هنوز نرسیده است.' : 'این صفحه خارج از محیط Web App تلگرام باز شده است.'}</span></details></section>`; $$('.page').forEach(el => el.classList.toggle('active', el.dataset.page === 'home')); finishSplash(); }
async function retryTelegramAuthentication() { setBusy(true, 'در حال دریافت مجوز تلگرام…'); try {
    prepareTelegramChrome();
    const initData = await waitForTelegramInitData(6000);
    if (initData) {
        await authenticateWithTelegram(initData);
        return;
    }
    try {
        await resumeSignedSession();
        return;
    }
    catch { }
    renderAccessGate(Object.assign(new Error('اطلاعات ورود تلگرام هنوز دریافت نشده است؛ صفحه را ببندید و از دکمه پایین ربات دوباره وارد شوید.'), { code: 'INIT_DATA_MISSING' }));
}
catch (err) {
    renderAccessGate(err);
}
finally {
    setBusy(false);
} }
async function bootstrap() { prepareTelegramChrome(); setConnection('loading', 'در حال بررسی ورود امن تلگرام…'); const immediate = String(tg?.initData || telegramInitDataFromLocation() || '').trim(); let recoverableError = null; if (immediate) {
    try {
        await authenticateWithTelegram(immediate);
        return;
    }
    catch (err) {
        if (isRecoverableTelegramAuthError(err)) {
            recoverableError = err;
            try {
                await resumeSignedSession();
                return;
            }
            catch { }
        }
        else {
            renderAccessGate(err);
            return;
        }
    }
} const sessionTask = signedSessionAuth().then(auth => ({ ok: true, auth })).catch(error => ({ ok: false, error })); const initData = await waitForTelegramInitData(); if (initData) {
    try {
        await authenticateWithTelegram(initData);
        return;
    }
    catch (err) {
        if (isRecoverableTelegramAuthError(err)) {
            recoverableError = err;
            try {
                const session = await sessionTask;
                if (session.ok) {
                    await activateAuthenticatedShell(session.auth);
                    return;
                }
            }
            catch { }
        }
        else {
            renderAccessGate(err);
            return;
        }
    }
} const session = await sessionTask; if (session.ok) {
    await activateAuthenticatedShell(session.auth);
    return;
} const lateInit = await waitForTelegramInitData(4000); if (lateInit && lateInit !== immediate) {
    try {
        await authenticateWithTelegram(lateInit);
        return;
    }
    catch (err) {
        if (!isRecoverableTelegramAuthError(err)) {
            renderAccessGate(err);
            return;
        }
        recoverableError = err;
    }
} renderAccessGate(recoverableError || Object.assign(new Error('اطلاعات ورود تلگرام دریافت نشد؛ از دکمه Mini App داخل ربات وارد شوید.'), { code: 'INIT_DATA_MISSING' })); }
const SPLASH_DURATION_MS = 4000;
let splashAppReady = false, splashVideoDone = false, splashDeadlineElapsed = false, splashReleased = false, splashDeadlineTimer = null;
function freezeBackgroundVideo() { const video = $('#appBackgroundVideo'); if (!video)
    return; video.dataset.finished = 'true'; video.pause(); if (Number.isFinite(video.duration) && video.duration > .08) {
    try {
        video.currentTime = Math.max(0, video.duration - .06);
    }
    catch { }
} }
function startBackgroundVideo() { const layer = $('#ambientVideoLayer'), video = $('#appBackgroundVideo'); layer?.classList.add('active'); if (!video || video.dataset.finished === 'true')
    return; const source = video.querySelector('source[data-src]'); if (source && !source.src) {
    source.src = source.dataset.src || '';
    video.load();
} video.muted = true; video.defaultMuted = true; video.playsInline = true; video.currentTime = 0; const play = video.play(); if (play?.catch)
    play.catch(() => { freezeBackgroundVideo(); }); }
function resumeBackgroundVideo() { const video = $('#appBackgroundVideo'); if (!video || video.dataset.finished === 'true' || document.hidden)
    return; const remaining = Number.isFinite(video.duration) ? video.duration - video.currentTime : 1; if (remaining > .12) {
    const play = video.play();
    if (play?.catch)
        play.catch(() => { });
}
else
    freezeBackgroundVideo(); }
function maybeReleaseSplash() { if (splashReleased || !splashDeadlineElapsed)
    return; splashReleased = true; clearTimeout(splashDeadlineTimer); const app = $('#app'), splash = $('#splash'); if (app)
    app.hidden = false; startBackgroundVideo(); if (!splash)
    return; splash.classList.add('done'); splash.remove(); }
function markSplashVideoDone() { splashVideoDone = true; }
function prepareMotionExperience() { const intro = $('#loadingVideo'), background = $('#appBackgroundVideo'); background?.addEventListener('ended', freezeBackgroundVideo); background?.addEventListener('error', freezeBackgroundVideo, { once: true }); const startedAt = performance.now(); const releaseAtFourSeconds = () => { const remaining = SPLASH_DURATION_MS - (performance.now() - startedAt); if (remaining > 20) {
        splashDeadlineTimer = setTimeout(releaseAtFourSeconds, remaining);
        return;
    } splashDeadlineElapsed = true; maybeReleaseSplash(); }; splashDeadlineTimer = setTimeout(releaseAtFourSeconds, SPLASH_DURATION_MS); if (!intro)
    return; intro.muted = true; intro.defaultMuted = true; intro.playsInline = true; intro.currentTime = 0; intro.addEventListener('ended', markSplashVideoDone, { once: true }); intro.addEventListener('error', markSplashVideoDone, { once: true }); const play = intro.play(); if (play?.catch)
    play.catch(() => { }); }
function finishSplash() { splashAppReady = true; maybeReleaseSplash(); }
function demoOverview() { return { user: { first_name: 'SENTINEL', language: 'fa' }, account: { active_signals: 4, vip_active: false, points: 120 }, risk: { accounts: [{ id: 1, name: 'Primary Account', currency: 'USD', balance: 10000, equity: 10000, type: 'personal', is_default: true, risk_enabled: true }], default_account: { id: 1, name: 'Primary Account', currency: 'USD', balance: 10000, equity: 10000 }, account_exposure: { open_risk_percent: 1.2, daily_risk_percent: 1.2, remaining_daily_risk_percent: 1.8, open_trades: 1 }, prop: { status: 'safe' }, what_if: { all_stops_loss_amount: -120, worst_case_drawdown_percent: 1.2 }, correlation: { clusters: [] } }, journal_stats: { win_rate: 64.3, closed: 28, pnl_sum: 12.8, max_drawdown: 3.4 }, revision_count: 1, features: {}, today_actions: [{ type: 'revision', priority: 'high', count: 1, target: 'revisions' }], notifications: { signals: true, results: true, news: true, calendar: true, support: true, alerts: true, quiet_enabled: true, quiet_start: '23:00', quiet_end: '07:00', timezone: 'Asia/Tehran', markets: [], symbols: [] }, bot_username: 'SENTINEL_bot', recent_signals: [{ id: 1, display_number: 318, symbol: 'XAUUSD', side: 'buy', entry: '2418–2421', stop: '2409', targets: ['2432', '2444'], risk: '1', status: 'open', risk_reward: '2.4', quote: { price: 2420.4, updated_at: new Date().toISOString() }, entry_state: { missed: false, risk_reward: 2.3 }, choice: {} }], commerce: { plans: [], payment: {} }, rules: { accepted: true }, onboarding: { completed: true, recommendation: { home_mode: 'professional' } }, generated_at: new Date().toISOString() }; }
function renderFatal(err) { $('#page-home').innerHTML = `<div class="panel"><div class="empty">${icon('alert')}<h2>${esc(t('error'))}</h2><p>${esc(err.message)}</p><button class="button" data-reload>${esc(t('retry'))}</button></div></div>`; }
async function loadOverview(force = false) { if (state.preview)
    return state.resources.overview; if (!force && state.loaded.has('overview'))
    return state.resources.overview; if (overviewInflight)
    return overviewInflight; overviewInflight = (async () => { const data = await request('./api/v1/overview'); state.resources.overview = data; const savedLanguage = localStorage.getItem('sentinelLanguage'); state.lang = ['fa', 'en'].includes(savedLanguage) ? savedLanguage : (data.user?.language === 'en' ? 'en' : 'fa'); state.loaded.add('overview'); if (!state.selectedAccount)
    state.selectedAccount = data.risk?.default_account?.id || null; applyLanguage(); return data; })(); try {
    return await overviewInflight;
}
finally {
    overviewInflight = null;
} }
function resourceRoute(key, cursor = '', force = false) { const q = new URLSearchParams({ limit: String(state.pageSize) }); if (cursor)
    q.set('cursor', String(cursor)); if (force && ['signals', 'market'].includes(key))
    q.set('live', '1'); if (key === 'signals') {
    if (state.signalFilter === 'open')
        q.set('status', 'open');
    if (['forex', 'crypto'].includes(state.signalFilter))
        q.set('market', state.signalFilter);
    if (['public', 'vip'].includes(state.signalAccessFilter))
        q.set('scope', state.signalAccessFilter);
    if (state.signalQuery.trim())
        q.set('q', state.signalQuery.trim());
} if (key === 'journal') {
    if (state.journalFilter !== 'all')
        q.set('status', state.journalFilter);
    if (state.journalQuery.trim())
        q.set('q', state.journalQuery.trim());
} if (key === 'orders' && state.orderFilter !== 'all')
    q.set('status', state.orderFilter); if (key === 'tickets' && state.ticketFilter !== 'all')
    q.set('status', state.ticketFilter); const routes = { signals: `./api/v1/signals?${q}`, risk: `./api/v1/risk${state.selectedAccount ? `?account_id=${state.selectedAccount}` : ''}`, journal: `./api/v1/journal?${q}`, feed: './api/v1/feed?limit=60', expansion: './api/v1/expansion', market: `./api/v1/market${force ? '?live=1' : ''}`, calendar: `./api/v1/calendar?${q}`, orders: `./api/v1/orders?${q}`, tickets: `./api/v1/tickets?${q}`, contests: './api/v1/contests', track: `./api/v1/track-record?${q}`, revisions: './api/v1/revisions', adminOps: './api/v1/admin/operations', adminAudit: './api/v1/admin/audit?limit=50', adminExperiments: './api/v1/admin/experiments', adminCampaigns: './api/v1/admin/campaigns?limit=50', adminOrders: './api/v1/admin/orders?limit=50', adminTickets: './api/v1/admin/tickets?limit=50', adminTemplates: './api/v1/admin/signal-templates', adminIntegration: './api/v1/admin/integration', adminPlatform: './api/v1/admin/platform', adminCapabilities: './api/v1/admin/capabilities', adminSignalCycles: './api/v1/admin/signal-cycles?limit=100', adminSignalJobs: './api/v1/admin/signal-jobs?limit=50', adminUsers: './api/v1/admin/users?limit=100', adminAdmins: './api/v1/admin/admins', adminSignals: './api/v1/admin/signals?limit=100', ai: './api/v1/ai?limit=30', adminAI: './api/v1/admin/ai?limit=50', adminVipPlans: './api/v1/admin/vip-plans' }; return routes[key] || ''; }
async function loadResource(key, force = false, append = false) { if (state.preview)
    return state.resources[key]; const existing = state.resources[key]; if (append && existing?.next_cursor == null)
    return existing; if (!force && !append && state.loaded.has(key))
    return existing; const cursor = append ? String(existing?.next_cursor || '') : '', route = resourceRoute(key, cursor, force); if (!route)
    return null; const flightKey = `${key}:${route}:${append ? 'append' : 'replace'}`; if (resourceInflight.has(flightKey))
    return resourceInflight.get(flightKey); const task = (async () => { const data = await request(route); if (append && existing && Array.isArray(existing.items) && Array.isArray(data.items)) {
    const known = new Set(existing.items.map(x => String(x.id)));
    state.resources[key] = { ...existing, ...data, items: [...existing.items, ...data.items.filter(x => !known.has(String(x.id)))] };
}
else
    state.resources[key] = data; state.loaded.add(key); return state.resources[key]; })(); resourceInflight.set(flightKey, task); try {
    return await task;
}
finally {
    resourceInflight.delete(flightKey);
} }
function moreButton(key, data) { return data?.next_cursor != null ? `<div class="pagination-actions"><button class="button secondary" data-load-more="${key}">${state.lang === 'fa' ? 'بارگذاری بیشتر' : 'Load more'} · ${num((data.items || []).length, 0)}/${num(data.total || 0, 0)}</button></div>` : ''; }
async function loadMore(key) { setBusy(true); try {
    await loadResource(key, false, true);
    if (key === 'signals')
        await renderSignals();
    else if (key === 'journal')
        await renderJournal();
    else if (key === 'calendar')
        calendarModal();
    else if (key === 'orders')
        ordersModal();
    else if (key === 'tickets')
        supportModal();
    else if (key === 'track')
        trackModal();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function applyDeepLink() { const params = new URLSearchParams(location.search); const start = (tg?.initDataUnsafe?.start_param || params.get('tgWebAppStartParam') || params.get('startapp') || '').trim(); const explicitPage = params.has('page'), explicitOpen = params.has('open'); let page = params.get('page') || 'home', open = params.get('open') || ''; const signal = params.get('signal') || (start.startsWith('signal_') ? start.slice(7) : ''); if (start && ['home', 'signals', 'risk', 'journal', 'more'].includes(start))
    page = start; if (!['home', 'signals', 'risk', 'journal', 'more'].includes(page))
    page = 'home'; await navigate(page, false); if (signal)
    await openSignal(signal);
else if (open)
    await openMore(open);
else if (!start && !explicitPage && !explicitOpen && state.resources.overview?.onboarding?.completed)
    await openMore('feed'); }
function maybeShowOnboarding() { const o = state.resources.overview || {}; if (!state.preview && !o.onboarding?.completed && o.rules?.accepted !== false && !location.search.includes('signal='))
    onboardingModal(); }
function onboardingModal() { const o = state.resources.overview?.onboarding || {}, a = state.resources.overview?.risk?.default_account || {}; openModal('SENTINEL SETUP', t('onboarding'), `<form id="onboardingForm" novalidate><div class="notice info"><strong>${state.lang === 'fa' ? 'راه‌اندازی یک‌باره حساب' : 'One-time account setup'}</strong><p>${state.lang === 'fa' ? 'این اطلاعات در حساب شما ذخیره می‌شود و در ورودهای بعدی دوباره پرسیده نخواهد شد.' : 'These details are saved to your account and will not be requested again.'}</p></div><div class="form-grid"><div class="field"><label for="onboardAccountName">${state.lang === 'fa' ? 'نام حساب' : 'Account name'}</label><input id="onboardAccountName" required minlength="2" maxlength="80" value="${esc(o.account_name || a.name || (state.lang === 'fa' ? 'حساب 1' : 'Account 1'))}"></div><div class="field"><label for="onboardBalance">${esc(t('balance'))} (USD)</label><input id="onboardBalance" inputmode="decimal" min="1" required value="${esc(o.balance || o.account_size || a.balance || '')}" placeholder="10000"></div><div class="field"><label for="onboardEquity">${esc(t('equity'))} (USD)</label><input id="onboardEquity" inputmode="decimal" min="1" required value="${esc(o.equity || a.equity || o.balance || o.account_size || '')}" placeholder="10000"></div><div class="field"><label for="onboardProfessional">${state.lang === 'fa' ? 'تریدر حرفه‌ای هستید؟' : 'Professional trader?'}</label><select id="onboardProfessional" required><option value="no" ${!o.professional ? 'selected' : ''}>${state.lang === 'fa' ? 'خیر' : 'No'}</option><option value="yes" ${o.professional ? 'selected' : ''}>${state.lang === 'fa' ? 'بله' : 'Yes'}</option></select></div><div class="field"><label for="onboardExperience">${esc(t('experience'))}</label><select id="onboardExperience" required><option value="beginner" ${o.experience === 'beginner' ? 'selected' : ''}>${state.lang === 'fa' ? 'مبتدی' : 'Beginner'}</option><option value="intermediate" ${!o.experience || o.experience === 'intermediate' ? 'selected' : ''}>${state.lang === 'fa' ? 'متوسط' : 'Intermediate'}</option><option value="advanced" ${o.experience === 'advanced' ? 'selected' : ''}>${state.lang === 'fa' ? 'حرفه‌ای' : 'Advanced'}</option><option value="professional" ${o.experience === 'professional' ? 'selected' : ''}>${state.lang === 'fa' ? 'تریدر حرفه‌ای' : 'Professional trader'}</option></select></div><div class="field"><label for="onboardMarket">${esc(t('market'))}</label><select id="onboardMarket"><option value="both" ${!o.market || o.market === 'both' ? 'selected' : ''}>Forex + Crypto</option><option value="forex" ${o.market === 'forex' ? 'selected' : ''}>Forex</option><option value="crypto" ${o.market === 'crypto' ? 'selected' : ''}>Crypto</option></select></div><div class="field"><label for="onboardRisk">${esc(t('riskTolerance'))}</label><select id="onboardRisk"><option value="conservative" ${o.risk_tolerance === 'conservative' ? 'selected' : ''}>${state.lang === 'fa' ? 'محافظه‌کار' : 'Conservative'}</option><option value="balanced" ${!o.risk_tolerance || o.risk_tolerance === 'balanced' ? 'selected' : ''}>${state.lang === 'fa' ? 'متعادل' : 'Balanced'}</option><option value="aggressive" ${o.risk_tolerance === 'aggressive' ? 'selected' : ''}>${state.lang === 'fa' ? 'تهاجمی کنترل‌شده' : 'Controlled aggressive'}</option></select></div><div class="field"><label for="onboardGoal">${esc(t('goal'))}</label><select id="onboardGoal" required><option value="signals" ${!o.goal || o.goal === 'signals' ? 'selected' : ''}>${state.lang === 'fa' ? 'دریافت و مدیریت سیگنال' : 'Signal decisions'}</option><option value="education" ${o.goal === 'education' ? 'selected' : ''}>${state.lang === 'fa' ? 'آموزش' : 'Education'}</option><option value="prop" ${o.goal === 'prop' ? 'selected' : ''}>Prop Firm</option><option value="journal" ${o.goal === 'journal' ? 'selected' : ''}>${state.lang === 'fa' ? 'ژورنال و تحلیل شخصی' : 'Journal & analytics'}</option></select></div></div></form>`, [{ label: t('completeSetup'), kind: 'primary', action: async () => { const f = $('#onboardingForm'); if (!f?.reportValidity())
            return; const balance = Number($('#onboardBalance').value), equity = Number($('#onboardEquity').value); if (!(balance > 0 && equity > 0)) {
            toast(state.lang === 'fa' ? 'موجودی و Equity باید بیشتر از صفر باشند.' : 'Balance and equity must be greater than zero.', 'error');
            return;
        } setBusy(true); try {
            const result = await action('onboarding_update', { account_name: $('#onboardAccountName').value.trim(), balance, equity, account_size: balance, professional: $('#onboardProfessional').value === 'yes', experience: $('#onboardProfessional').value === 'yes' ? 'professional' : $('#onboardExperience').value, market: $('#onboardMarket').value, risk_tolerance: $('#onboardRisk').value, goal: $('#onboardGoal').value, currency: 'USD' }, false);
            state.resources.overview = { ...(state.resources.overview || {}), onboarding: { ...(result.onboarding || {}), completed: true }, risk: { ...(state.resources.overview?.risk || {}), default_account: result.account, accounts: [result.account] } };
            state.selectedAccount = result.account?.id || state.selectedAccount;
            closeModal();
            invalidate('overview', 'risk');
            await loadOverview(true);
            renderChrome();
            renderHome();
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
function actionTarget(item) { const target = item?.target || ''; if (['risk', 'signals', 'journal', 'home', 'more'].includes(target))
    return `data-page-target="${target}"`; return `data-open="${esc(target)}"`; }

