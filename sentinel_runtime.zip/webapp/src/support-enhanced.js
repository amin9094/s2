/* SENTINEL v8.12 unified support UI. Loaded after the legacy views so these
 * functions become the single user/admin presentation boundary. */
function supportAttachmentLabel(att) { const type = String(att?.type || 'document'); const labels = { photo: state.lang === 'fa' ? 'تصویر' : 'Image', video: state.lang === 'fa' ? 'ویدئو' : 'Video', voice: state.lang === 'fa' ? 'وویس' : 'Voice', audio: state.lang === 'fa' ? 'فایل صوتی' : 'Audio', document: state.lang === 'fa' ? 'فایل/PDF' : 'File/PDF' }; return labels[type] || labels.document; }
function supportAttachmentMarkup(att) { if (!att || typeof att !== 'object')
    return ''; const href = String(att.download_url || '').trim(), name = esc(att.file_name || supportAttachmentLabel(att)), size = Number(att.file_size || 0), sizeLabel = size ? `${(size / 1024 / 1024).toFixed(size > 1024 * 1024 ? 1 : 2)} MB` : ''; if (!href)
    return `<div class="notice warning"><strong>${esc(supportAttachmentLabel(att))}</strong><small>${name}${sizeLabel ? ` · ${sizeLabel}` : ''}</small></div>`; return `<a class="notice info support-attachment" href="${esc(href)}" target="_blank" rel="noopener"><strong>📎 ${esc(supportAttachmentLabel(att))}</strong><small>${name}${sizeLabel ? ` · ${sizeLabel}` : ''}</small></a>`; }
function supportMessageMarkup(m, adminView = false) { const isAdmin = String(m?.sender || '') === 'admin', title = adminView ? (isAdmin ? (state.lang === 'fa' ? 'پاسخ مدیر' : 'Admin reply') : (state.lang === 'fa' ? 'پیام کاربر' : 'User message')) : (isAdmin ? (state.lang === 'fa' ? 'پشتیبانی SENTINEL' : 'SENTINEL Support') : (state.lang === 'fa' ? 'شما' : 'You')); return `<div class="timeline-item ${isAdmin ? 'admin-message' : 'user-message'}"><strong>${esc(title)}</strong>${m?.text ? `<p>${esc(m.text)}</p>` : ''}${supportAttachmentMarkup(m?.attachment)}<small>${date(m?.created_at)}</small></div>`; }
async function uploadSupportAttachment(inputId) { const input = document.getElementById(inputId), file = input?.files?.[0]; if (!file)
    return null; const max = 15 * 1024 * 1024; if (file.size > max)
    throw new Error(state.lang === 'fa' ? 'حداکثر حجم فایل ۱۵ مگابایت است.' : 'Maximum file size is 15 MB.'); const form = new FormData(); form.append('file', file, file.name); return request('./api/v1/support/attachments', { method: 'POST', csrf: true, body: form }, 60000); }
function supportFileInput(id) { return `<div class="field"><label for="${id}">${state.lang === 'fa' ? 'ضمیمه اختیاری' : 'Optional attachment'}</label><input id="${id}" type="file" accept="image/jpeg,image/png,image/webp,application/pdf,video/mp4,audio/ogg,audio/mpeg,audio/mp4"><small>${state.lang === 'fa' ? 'تصویر، ویدئو، وویس، MP3 یا PDF تا ۱۵ مگابایت' : 'Image, video, voice, MP3 or PDF up to 15 MB'}</small></div>`; }
function supportModal() { const d = state.resources.tickets || {}, items = d.items || [], counts = items.reduce((a, x) => (a[x.status] = (a[x.status] || 0) + 1, a), {}); openModal('SUPPORT', t('support'), `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی یکپارچه ربات و مینی‌اپ' : 'Unified Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'پیام و فایل از هر دو محیط در یک گفت‌وگو ذخیره می‌شود و پاسخ تلگرامی نیز از صف پایدار ارسال می‌شود.' : 'Messages and files share one conversation and Telegram notifications use the durable queue.'}</p></div><div class="row-between"><button class="button" data-ticket-new>${icon('plus')}${esc(t('createTicket'))}</button><span class="status-badge info">${num(d.total || items.length, 0)} ${state.lang === 'fa' ? 'تیکت' : 'tickets'}</span></div><div class="filters" style="margin-top:13px">${['all', 'open', 'pending', 'answered', 'closed'].map(x => `<button class="filter-chip ${state.ticketFilter === x ? 'active' : ''}" data-ticket-filter="${x}">${esc(x === 'all' ? t('all') : ticketStatusLabel(x))}${x !== 'all' && counts[x] ? ` · ${num(counts[x], 0)}` : ''}</button>`).join('')}</div><div class="ticket-list" style="margin-top:13px">${items.map(x => { const messages = x.messages || [], last = messages[messages.length - 1] || {}, hasFile = messages.some(m => m?.attachment); return `<article class="ticket-card"><div class="row-between"><h3>#${num(x.id, 0)} · ${esc(x.subject)}</h3><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${esc(x.category || 'general')} · ${esc(x.priority || 'normal')} · ${date(x.updated_at || x.created_at)}</p><div class="notice ${x.waiting_for === 'user' ? 'good' : 'info'}"><strong>${x.waiting_for === 'user' ? (state.lang === 'fa' ? 'پاسخ مدیر آماده است' : 'Admin reply available') : (state.lang === 'fa' ? 'در انتظار بررسی پشتیبانی' : 'Waiting for support')}</strong>${last.text ? `<small>${esc(String(last.text).slice(0, 160))}</small>` : ''}${hasFile ? `<small>📎 ${state.lang === 'fa' ? 'دارای فایل ضمیمه' : 'Has attachment'}</small>` : ''}</div><div class="card-actions"><button class="button secondary small" data-ticket-detail="${x.id}">${esc(t('details'))} · ${num(messages.length, 0)}</button></div></article>`; }).join('') || empty()}</div>${moreButton('tickets', d)}`, []); }
function ticketNewModal() { openModal('SUPPORT', t('createTicket'), `<form id="ticketForm"><div class="form-grid"><div class="field"><label for="ticketSubject">${esc(t('ticketSubject'))}</label><input id="ticketSubject" required maxlength="200"></div><div class="field"><label for="ticketCategory">${state.lang === 'fa' ? 'دسته' : 'Category'}</label><select id="ticketCategory"><option value="general">${state.lang === 'fa' ? 'عمومی' : 'General'}</option><option value="account">${state.lang === 'fa' ? 'حساب' : 'Account'}</option><option value="payment">${state.lang === 'fa' ? 'پرداخت' : 'Payment'}</option><option value="signal">${state.lang === 'fa' ? 'سیگنال' : 'Signal'}</option><option value="education">${state.lang === 'fa' ? 'آموزش' : 'Education'}</option><option value="technical">${state.lang === 'fa' ? 'فنی' : 'Technical'}</option></select></div><div class="field"><label for="ticketPriority">${esc(t('priority'))}</label><select id="ticketPriority"><option value="low">${state.lang === 'fa' ? 'کم' : 'Low'}</option><option value="normal" selected>${state.lang === 'fa' ? 'عادی' : 'Normal'}</option><option value="high">${state.lang === 'fa' ? 'مهم' : 'High'}</option><option value="urgent">${state.lang === 'fa' ? 'فوری' : 'Urgent'}</option></select></div></div><div class="field"><label for="ticketMessage">${esc(t('message'))}</label><textarea id="ticketMessage" maxlength="4000" placeholder="${state.lang === 'fa' ? 'متن پیام یا توضیح فایل را بنویسید' : 'Write a message or file description'}"></textarea></div>${supportFileInput('ticketNewAttachment')}</form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#ticketForm'); if (!f.reportValidity())
            return; const text = $('#ticketMessage').value.trim(), hasFile = Boolean($('#ticketNewAttachment')?.files?.[0]); if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا یک فایل اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        } setBusy(true); try {
            const attachment = await uploadSupportAttachment('ticketNewAttachment');
            const row = await action('ticket_create', { subject: $('#ticketSubject').value.trim(), priority: $('#ticketPriority').value, text: text || 'فایل ضمیمه', category: $('#ticketCategory').value, attachment }, false);
            invalidate('tickets', 'overview');
            await Promise.all([loadResource('tickets', true), loadOverview(true)]);
            closeModal();
            await ticketDetail(row.id);
            toast(t('success'));
        }
        catch (err) {
            toast(localizedError?.(err) || err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function ticketDetail(id) {
    setBusy(true);
    try {
        const x = await request(`./api/v1/tickets/${encodeURIComponent(id)}`);
        const closed = x.status === 'closed', score = Number(x.satisfaction || 0);
        const replyBlock = !closed ? `<form id="ticketReplyForm"><div class="field"><label for="ticketReply">${esc(t('message'))}</label><textarea id="ticketReply" maxlength="4000"></textarea></div>${supportFileInput('ticketReplyAttachment')}<div class="card-actions"><button type="button" class="button" data-ticket-reply-enhanced="${x.id}">${esc(t('submit'))}</button><button type="button" class="button danger" data-ticket-status="${x.id}" data-status="closed">${state.lang === 'fa' ? 'بستن تیکت' : 'Close ticket'}</button></div></form>` : '';
        let closedBlock = '';
        if (closed) {
            const rating = score > 0 ? `<div class="notice good"><strong>${state.lang === 'fa' ? 'امتیاز شما به پشتیبانی' : 'Your support rating'}: ${'★'.repeat(score)}${'☆'.repeat(5 - score)}</strong></div>` : `<div class="notice info"><strong>${state.lang === 'fa' ? 'از پاسخ پشتیبانی راضی بودید؟' : 'How was the support?'}</strong><div class="card-actions">${[1, 2, 3, 4, 5].map(v => `<button class="button secondary small" data-ticket-satisfaction="${x.id}" data-score="${v}">${v} ★</button>`).join('')}</div></div>`;
            closedBlock = `<div class="notice warning"><strong>${state.lang === 'fa' ? 'تیکت بسته است' : 'Ticket is closed'}</strong><button class="button secondary small" data-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button></div>${rating}`;
        }
        openModal('TICKET', `#${x.id} · ${x.subject}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'info')}${metric(state.lang === 'fa' ? 'پیام‌ها' : 'Messages', num((x.messages || []).length, 0), '', '')}</div><div class="timeline">${(x.messages || []).map(m => supportMessageMarkup(m, false)).join('') || empty()}</div>${replyBlock}${closedBlock}`, []);
    }
    catch (err) {
        toast(localizedError?.(err) || err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}
async function loadAdminTicketsWithFilters() { const q = new URLSearchParams({ limit: '100' }), status = $('#adminTicketStatusFilter')?.value || '', priority = $('#adminTicketPriorityFilter')?.value || '', query = $('#adminTicketQuery')?.value?.trim() || '', assigned = $('#adminTicketAssignedFilter')?.value?.trim() || ''; if (status)
    q.set('status', status); if (priority)
    q.set('priority', priority); if (query)
    q.set('q', query); if (assigned)
    q.set('assigned_admin', assigned); if ($('#adminTicketOverdueFilter')?.checked)
    q.set('overdue_only', 'true'); const data = await request(`./api/v1/admin/tickets?${q}`); state.resources.adminTickets = data; state.loaded.add('adminTickets'); return data; }
async function adminTicketCenter() { setBusy(true); try {
    const d = await loadResource('adminTickets', true), rows = d?.items || [];
    openModal('ADMIN SUPPORT', state.lang === 'fa' ? 'مدیریت کامل پشتیبانی' : 'Complete support management', `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی فعال ربات و مینی‌اپ' : 'Live Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'پاسخ، فایل، تخصیص، اولویت، SLA و یادداشت داخلی از همین صفحه مدیریت می‌شوند.' : 'Reply, attachments, assignment, priority, SLA and internal notes are managed here.'}</p></div><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'جست‌وجو' : 'Search'}</label><input id="adminTicketQuery" placeholder="#123 / user / subject"></div><div class="field"><label>${state.lang === 'fa' ? 'وضعیت' : 'Status'}</label><select id="adminTicketStatusFilter"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option>${['open', 'pending', 'answered', 'closed'].map(v => `<option value="${v}">${ticketStatusLabel(v)}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'اولویت' : 'Priority'}</label><select id="adminTicketPriorityFilter"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option>${['low', 'normal', 'high', 'urgent'].map(v => `<option value="${v}">${v}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'شناسه مدیر مسئول' : 'Assigned admin ID'}</label><input id="adminTicketAssignedFilter" inputmode="numeric"></div></div><label class="check"><input id="adminTicketOverdueFilter" type="checkbox"> ${state.lang === 'fa' ? 'فقط تیکت‌های عبورکرده از SLA' : 'Only overdue SLA tickets'}</label><div class="card-actions"><button class="button primary" data-admin-ticket-filter-apply>${state.lang === 'fa' ? 'اعمال فیلتر' : 'Apply filters'}</button></div><div id="adminTicketResults">${adminTicketCards(rows)}</div>`, []);
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
function adminTicketCards(rows) { return `<div class="journal-list">${(rows || []).map(x => { const due = x.sla_due_at ? new Date(x.sla_due_at) : null, overdue = due && due.getTime() < Date.now() && x.status !== 'closed'; return `<article class="journal-card"><div class="row-between"><strong>#${num(x.id, 0)} · ${esc(x.subject || 'Support')}</strong><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${state.lang === 'fa' ? 'کاربر' : 'User'} ${esc(x.user_id)} · ${esc(x.priority || 'normal')} · ${state.lang === 'fa' ? 'مسئول' : 'Assigned'}: ${esc(x.assigned_admin || '—')}</p><small>${date(x.updated_at || x.created_at)} · ${num((x.messages || []).length, 0)} ${state.lang === 'fa' ? 'پیام' : 'messages'} · ${num(x.internal_notes_count || 0, 0)} ${state.lang === 'fa' ? 'یادداشت داخلی' : 'notes'}</small>${overdue ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'SLA عبور کرده است' : 'SLA overdue'}</strong></div>` : ''}<div class="card-actions"><button class="button primary small" data-admin-ticket="${x.id}">${state.lang === 'fa' ? 'بازکردن و مدیریت' : 'Open & manage'}</button></div></article>`; }).join('') || empty()}</div>`; }
async function adminTicketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/admin/tickets/${encodeURIComponent(id)}`), closed = x.status === 'closed', due = x.sla_due_at ? new Date(x.sla_due_at) : null, overdue = due && due.getTime() < Date.now() && !closed;
    openModal('SUPPORT ADMIN', `#${x.id} · ${x.subject || 'Support'}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(state.lang === 'fa' ? 'کاربر' : 'User', esc(x.user_id), '', 'info')}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'مدیر مسئول' : 'Assigned admin', esc(x.assigned_admin || '—'), '', 'warn')}</div>${overdue ? `<div class="notice danger"><strong>${state.lang === 'fa' ? 'مهلت پاسخ SLA گذشته است' : 'SLA response deadline has passed'}</strong><small>${date(x.sla_due_at)}</small></div>` : `<div class="notice info"><strong>SLA</strong><small>${x.sla_due_at ? date(x.sla_due_at) : '—'}</small></div>`}<div class="timeline">${(x.messages || []).map(m => supportMessageMarkup(m, true)).join('') || empty()}</div><section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'یادداشت‌های داخلی' : 'Internal notes'}</h3></div><div class="panel-body timeline">${(x.internal_notes || []).map(n => `<div class="timeline-item admin-message"><strong>${state.lang === 'fa' ? 'مدیر' : 'Admin'} ${esc(n.admin_id)}</strong><p>${esc(n.text)}</p><small>${date(n.created_at)}</small></div>`).join('') || empty()}</div></section><div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'تخصیص به مدیر' : 'Assign to admin'}</label><input id="adminTicketAssignee" inputmode="numeric" value="${esc(x.assigned_admin || '')}"><button class="button secondary small" data-admin-ticket-assign-enhanced="${x.id}">${state.lang === 'fa' ? 'تخصیص' : 'Assign'}</button></div><div class="field"><label>${state.lang === 'fa' ? 'اولویت و SLA' : 'Priority & SLA'}</label><select id="adminTicketPriorityEdit">${['low', 'normal', 'high', 'urgent'].map(v => `<option value="${v}" ${x.priority === v ? 'selected' : ''}>${v}</option>`).join('')}</select><button class="button secondary small" data-admin-ticket-priority-enhanced="${x.id}">${state.lang === 'fa' ? 'به‌روزرسانی' : 'Update'}</button></div></div><div class="field"><label>${state.lang === 'fa' ? 'یادداشت داخلی (برای کاربر نمایش داده نمی‌شود)' : 'Internal note (hidden from user)'}</label><textarea id="adminTicketInternalNote" maxlength="2000"></textarea><button class="button secondary small" data-admin-ticket-note-enhanced="${x.id}">${state.lang === 'fa' ? 'ثبت یادداشت' : 'Save note'}</button></div>${!closed ? `<form id="adminTicketReplyForm"><div class="field"><label for="adminTicketReply">${esc(t('message'))}</label><textarea id="adminTicketReply" maxlength="4000"></textarea></div>${supportFileInput('adminTicketReplyAttachment')}</form>` : ''}<div class="card-actions">${!closed ? `<button class="button primary" data-admin-ticket-reply-enhanced="${x.id}">${state.lang === 'fa' ? 'ارسال پاسخ' : 'Send reply'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="pending">${state.lang === 'fa' ? 'در انتظار بررسی' : 'Mark pending'}</button><button class="button secondary" data-admin-ticket-status="${x.id}" data-status="answered">${state.lang === 'fa' ? 'پاسخ داده شد' : 'Mark answered'}</button><button class="button danger" data-admin-ticket-status="${x.id}" data-status="closed">${esc(t('close'))}</button>` : `<button class="button secondary" data-admin-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button>`}</div>`, []);
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
function journalPdfFilterModal() { const accounts = state.resources.risk?.accounts || state.resources.overview?.risk?.accounts || []; openModal('PDF', state.lang === 'fa' ? 'خروجی PDF ژورنال' : 'Journal PDF export', `<div class="form-grid"><div class="field"><label>${state.lang === 'fa' ? 'حساب' : 'Account'}</label><select id="journalPdfAccount"><option value="">${state.lang === 'fa' ? 'همه حساب‌ها' : 'All accounts'}</option>${accounts.map(a => `<option value="${esc(a.id)}">${esc(a.name || a.id)}</option>`).join('')}</select></div><div class="field"><label>${state.lang === 'fa' ? 'وضعیت' : 'Status'}</label><select id="journalPdfStatus"><option value="">${state.lang === 'fa' ? 'همه' : 'All'}</option><option value="open">${state.lang === 'fa' ? 'باز' : 'Open'}</option><option value="closed">${state.lang === 'fa' ? 'بسته' : 'Closed'}</option></select></div><div class="field"><label>${state.lang === 'fa' ? 'از تاریخ' : 'From date'}</label><input id="journalPdfFrom" type="date"></div><div class="field"><label>${state.lang === 'fa' ? 'تا تاریخ' : 'To date'}</label><input id="journalPdfTo" type="date"></div></div>`, [{ label: state.lang === 'fa' ? 'ساخت PDF' : 'Generate PDF', kind: 'primary', action: async () => downloadJournalPdf(true) }]); }
async function downloadJournalPdf(fromModal = false) { if (!fromModal) {
    journalPdfFilterModal();
    return;
} setBusy(true); try {
    const q = new URLSearchParams({ lang: state.lang }), account = $('#journalPdfAccount')?.value || '', status = $('#journalPdfStatus')?.value || '', dateFrom = $('#journalPdfFrom')?.value || '', dateTo = $('#journalPdfTo')?.value || '';
    if (account)
        q.set('account_id', account);
    if (status)
        q.set('status', status);
    if (dateFrom)
        q.set('date_from', dateFrom);
    if (dateTo)
        q.set('date_to', dateTo);
    const response = await fetch(`./api/v1/journal/export.pdf?${q}`, { credentials: 'include', headers: { Accept: 'application/pdf' } });
    if (!response.ok) {
        let message = 'PDF_EXPORT_FAILED';
        try {
            const body = await response.json();
            message = body?.error?.message || body?.detail || message;
        }
        catch { }
        throw new Error(message);
    }
    const blob = await response.blob();
    if (!blob.size)
        throw new Error('PDF_EXPORT_EMPTY');
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url;
    a.download = `sentinel-journal-${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    closeModal();
    toast(state.lang === 'fa' ? 'گزارش PDF ژورنال آماده شد.' : 'Journal PDF downloaded.');
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    setBusy(false);
} }
async function enhancedSupportClick(e) { const el = e.target.closest('button'); if (!el)
    return; let handled = true; try {
    if (el.dataset.ticketReplyEnhanced) {
        const id = el.dataset.ticketReplyEnhanced, text = $('#ticketReply')?.value.trim() || '', hasFile = Boolean($('#ticketReplyAttachment')?.files?.[0]);
        if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا فایل را اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        }
        setBusy(true);
        const attachment = await uploadSupportAttachment('ticketReplyAttachment');
        await action('ticket_reply', { ticket_id: id, text: text || 'فایل ضمیمه', attachment }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.ticketSatisfaction) {
        setBusy(true);
        await action('ticket_satisfaction', { ticket_id: el.dataset.ticketSatisfaction, score: Number(el.dataset.score) }, false);
        invalidate('tickets');
        await loadResource('tickets', true);
        await ticketDetail(el.dataset.ticketSatisfaction);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketReplyEnhanced) {
        const id = el.dataset.adminTicketReplyEnhanced, text = $('#adminTicketReply')?.value.trim() || '', hasFile = Boolean($('#adminTicketReplyAttachment')?.files?.[0]);
        if (!text && !hasFile) {
            toast(state.lang === 'fa' ? 'متن یا فایل را اضافه کنید.' : 'Add text or a file.', 'error');
            return;
        }
        setBusy(true);
        const attachment = await uploadSupportAttachment('adminTicketReplyAttachment');
        await action('ticket_admin_reply', { ticket_id: id, text: text || 'فایل ضمیمه', attachment }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketAssignEnhanced) {
        const id = el.dataset.adminTicketAssignEnhanced, adminId = $('#adminTicketAssignee')?.value.trim();
        if (!adminId)
            return;
        setBusy(true);
        await action('ticket_admin_assign', { ticket_id: id, admin_id: adminId }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketPriorityEnhanced) {
        const id = el.dataset.adminTicketPriorityEnhanced, priority = $('#adminTicketPriorityEdit')?.value;
        setBusy(true);
        await action('ticket_admin_priority_update', { ticket_id: id, priority }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketNoteEnhanced) {
        const id = el.dataset.adminTicketNoteEnhanced, text = $('#adminTicketInternalNote')?.value.trim();
        if (!text)
            return;
        setBusy(true);
        await action('ticket_admin_internal_note', { ticket_id: id, text }, false);
        invalidate('adminTickets');
        await adminTicketDetail(id);
        toast(t('success'));
    }
    else if (el.dataset.adminTicketFilterApply !== undefined) {
        setBusy(true);
        const d = await loadAdminTicketsWithFilters();
        const target = $('#adminTicketResults');
        if (target)
            target.innerHTML = adminTicketCards(d.items || []);
    }
    else
        handled = false;
}
catch (err) {
    toast(localizedError?.(err) || err.message, 'error');
}
finally {
    if (handled) {
        e.preventDefault();
        e.stopImmediatePropagation();
        setBusy(false);
    }
} }
document.addEventListener('click', enhancedSupportClick, true);

