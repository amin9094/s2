from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from modules.market_scope import signal_market_category
from modules.outcome_engine import FINAL_SIGNAL_STATUSES, calculate_signal_outcome

CORRELATION_GROUPS: dict[str, tuple[str, ...]] = {
    "usd": ("USD", "USDT", "USDC", "XAU", "XAG", "US30", "US100", "NAS100", "SPX", "US500"),
    "eur": ("EUR", "GER40", "DE40"),
    "gbp": ("GBP", "UK100"),
    "jpy": ("JPY", "JP225"),
    "btc": ("BTC", "WBTC"),
    "eth": ("ETH", "WETH"),
}

QUOTE_ASSETS = ("USDT", "USDC", "FDUSD", "TUSD", "BUSD", "USD", "BTC", "ETH", "EUR")
FX_CODES = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "CNY"}
INDEX_FACTORS = {
    "US30": "USD_INDEX",
    "DJ30": "USD_INDEX",
    "US100": "USD_INDEX",
    "NAS100": "USD_INDEX",
    "US500": "USD_INDEX",
    "SPX500": "USD_INDEX",
    "GER40": "EUR_INDEX",
    "DE40": "EUR_INDEX",
    "UK100": "GBP_INDEX",
    "JP225": "JPY_INDEX",
}


def _decimal(value: Any) -> Decimal:
    try:
        number = Decimal(str(value or "0").strip().replace(",", ""))
    except (InvalidOperation, ValueError):
        return Decimal("0")
    return number if number.is_finite() and number > 0 else Decimal("0")


def _active(db: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        row
        for row in db.get("signals", [])
        if isinstance(row, dict) and str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES
    ]


def _compact_symbol(symbol: Any) -> str:
    return "".join(ch for ch in str(symbol or "").upper() if ch.isalnum())


def correlation_groups(symbol: Any) -> set[str]:
    compact = _compact_symbol(symbol)
    groups: set[str] = set()
    for group, needles in CORRELATION_GROUPS.items():
        if any(needle in compact for needle in needles):
            groups.add(group)
    return groups or {"other"}


def symbol_factors(symbol: Any) -> tuple[str, str | None]:
    compact = _compact_symbol(symbol)
    if compact in INDEX_FACTORS:
        return INDEX_FACTORS[compact], None
    if compact.startswith("XAU"):
        return "XAU", "USD"
    if compact.startswith("XAG"):
        return "XAG", "USD"
    if compact.startswith("WTI") or compact.startswith("USOIL"):
        return "OIL", "USD"
    if compact.startswith("BRENT") or compact.startswith("UKOIL"):
        return "BRENT", "USD"
    if len(compact) >= 6 and compact[:3] in FX_CODES and compact[3:6] in FX_CODES:
        return compact[:3], compact[3:6]
    for quote in QUOTE_ASSETS:
        if compact.endswith(quote) and len(compact) > len(quote):
            return compact[: -len(quote)], quote
    return compact or "OTHER", None


def _remaining_risk(row: dict[str, Any]) -> Decimal:
    if row.get("breakeven_at") or str(row.get("status") or "") == "breakeven":
        return Decimal("0")
    risk = _decimal(row.get("risk"))
    outcome = calculate_signal_outcome(row)
    return risk * Decimal(str(outcome.remaining_percent)) / Decimal("100")


def _risk_rows(db: dict[str, Any], pending: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    rows = list(_active(db))
    if pending:
        rows.append({**pending, "status": "pending"})
    output: list[dict[str, Any]] = []
    for row in rows:
        symbol = str(row.get("symbol") or "-").upper()
        side = str(row.get("side") or "-").lower()
        declared = _decimal(row.get("risk"))
        remaining = _remaining_risk(row)
        base, quote = symbol_factors(symbol)
        direction = Decimal("1") if side == "buy" else Decimal("-1")
        factors = {base: direction * remaining}
        if quote:
            factors[quote] = -direction * remaining
        output.append(
            {
                "signal": row,
                "symbol": symbol,
                "side": side,
                "market": signal_market_category(row),
                "declared_risk": declared,
                "remaining_risk": remaining,
                "groups": correlation_groups(symbol),
                "factors": factors,
            }
        )
    return output


def exposure_snapshot(db: dict[str, Any], pending: dict[str, Any] | None = None) -> dict[str, Any]:
    rows = _risk_rows(db, pending)
    by_market: dict[str, Decimal] = defaultdict(Decimal)
    by_symbol: dict[str, Decimal] = defaultdict(Decimal)
    by_group: dict[str, Decimal] = defaultdict(Decimal)
    by_side: dict[str, Decimal] = defaultdict(Decimal)
    factor_net: dict[str, Decimal] = defaultdict(Decimal)
    factor_gross: dict[str, Decimal] = defaultdict(Decimal)
    symbol_long: dict[str, Decimal] = defaultdict(Decimal)
    symbol_short: dict[str, Decimal] = defaultdict(Decimal)
    gross = Decimal("0")
    declared_gross = Decimal("0")
    for item in rows:
        risk = item["remaining_risk"]
        declared_gross += item["declared_risk"]
        gross += risk
        by_market[item["market"]] += risk
        by_symbol[item["symbol"]] += risk
        by_side[item["side"]] += risk
        if item["side"] == "buy":
            symbol_long[item["symbol"]] += risk
        else:
            symbol_short[item["symbol"]] += risk
        for group in item["groups"]:
            by_group[group] += risk
        for factor, signed_risk in item["factors"].items():
            factor_net[factor] += signed_risk
            factor_gross[factor] += abs(signed_risk)

    today = datetime.now(UTC).date().isoformat()
    today_new = sum(
        (
            _decimal(row.get("risk"))
            for row in db.get("signals", [])
            if isinstance(row, dict) and str(row.get("created_at") or "")[:10] == today
        ),
        Decimal("0"),
    )
    if pending:
        today_new += _decimal(pending.get("risk"))

    hedged = {
        symbol: float(min(symbol_long[symbol], symbol_short[symbol]))
        for symbol in set(symbol_long) | set(symbol_short)
        if min(symbol_long[symbol], symbol_short[symbol]) > 0
    }
    net_directional = sum((abs(value) for value in factor_net.values()), Decimal("0")) / Decimal("2")
    return {
        "total_open_risk": float(gross),
        "declared_open_risk": float(declared_gross),
        "net_directional_risk": float(net_directional),
        "daily_new_risk": float(today_new),
        "open_count": len(rows),
        "by_market": {key: float(value) for key, value in sorted(by_market.items())},
        "by_symbol": {
            key: float(value)
            for key, value in sorted(by_symbol.items(), key=lambda item: item[1], reverse=True)
        },
        "by_group": {
            key: float(value)
            for key, value in sorted(by_group.items(), key=lambda item: item[1], reverse=True)
        },
        "by_side": {key: float(value) for key, value in sorted(by_side.items())},
        "factor_net": {
            key: float(value)
            for key, value in sorted(factor_net.items(), key=lambda item: abs(item[1]), reverse=True)
        },
        "factor_gross": {
            key: float(value)
            for key, value in sorted(factor_gross.items(), key=lambda item: item[1], reverse=True)
        },
        "hedged_by_symbol": hedged,
        "remaining_risk_reduction": float(max(Decimal("0"), declared_gross - gross)),
    }


def professional_exposure_boards(
    db: dict[str, Any],
    *,
    controls: dict[str, Any] | None = None,
    pending: dict[str, Any] | None = None,
) -> dict[str, dict[str, Any]]:
    snapshot = exposure_snapshot(db, pending)
    limits = controls or {}

    def utilization(value: float, key: str, fallback: float) -> float:
        ceiling = float(limits.get(key, fallback) or fallback)
        return round(value / max(0.0001, ceiling) * 100, 2)

    factor_rows = [
        {
            "factor": factor,
            "net": net,
            "gross": float(snapshot["factor_gross"].get(factor, 0.0)),
            "direction": "long" if net > 0 else "short" if net < 0 else "flat",
        }
        for factor, net in snapshot["factor_net"].items()
    ]
    largest_factor = factor_rows[0] if factor_rows else {"factor": "-", "net": 0.0, "gross": 0.0, "direction": "flat"}
    concentration = max(snapshot["by_symbol"].values(), default=0.0) / max(
        0.0001,
        float(snapshot["total_open_risk"]),
    ) * 100
    stress = [
        {
            "scenario": f"حرکت مخالف {row['factor']}",
            "estimated_risk_r": round(abs(float(row["net"])), 4),
        }
        for row in factor_rows[:5]
    ]
    return {
        "executive": {
            "title": "خلاصه و بودجه ریسک",
            "total_open_risk": snapshot["total_open_risk"],
            "declared_open_risk": snapshot["declared_open_risk"],
            "net_directional_risk": snapshot["net_directional_risk"],
            "daily_new_risk": snapshot["daily_new_risk"],
            "open_count": snapshot["open_count"],
            "total_utilization": utilization(snapshot["total_open_risk"], "max_total_open_risk", 8.0),
            "daily_utilization": utilization(snapshot["daily_new_risk"], "max_daily_new_risk", 10.0),
            "risk_reduced": snapshot["remaining_risk_reduction"],
        },
        "markets": {
            "title": "ریسک بازارها و جهت معاملات",
            "by_market": snapshot["by_market"],
            "by_side": snapshot["by_side"],
            "market_utilization": {
                key: utilization(value, "max_market_open_risk", 5.0)
                for key, value in snapshot["by_market"].items()
            },
        },
        "symbols": {
            "title": "تمرکز نماد و پوشش هج",
            "by_symbol": snapshot["by_symbol"],
            "hedged_by_symbol": snapshot["hedged_by_symbol"],
            "largest_symbol_concentration_percent": round(concentration, 2),
            "symbol_utilization": {
                key: utilization(value, "max_symbol_open_risk", 3.0)
                for key, value in snapshot["by_symbol"].items()
            },
        },
        "factors": {
            "title": "نقشه مواجهه ارز و دارایی",
            "rows": factor_rows,
            "largest_factor": largest_factor,
        },
        "correlation_stress": {
            "title": "هم‌بستگی و سناریوی تنش",
            "by_group": snapshot["by_group"],
            "group_utilization": {
                key: utilization(value, "max_correlated_risk", 6.0)
                for key, value in snapshot["by_group"].items()
            },
            "stress_scenarios": stress,
        },
    }


@dataclass(frozen=True, slots=True)
class ExposureDecision:
    ok: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    snapshot: dict[str, Any]


def evaluate_pending_exposure(
    db: dict[str, Any],
    payload: dict[str, Any],
    controls: dict[str, Any],
) -> ExposureDecision:
    snapshot = exposure_snapshot(db, payload)
    errors: list[str] = []
    warnings: list[str] = []
    if not bool(controls.get("exposure_guard", True)):
        return ExposureDecision(True, (), (), snapshot)
    max_total = float(controls.get("max_total_open_risk", 8) or 8)
    max_market = float(controls.get("max_market_open_risk", 5) or 5)
    max_symbol = float(controls.get("max_symbol_open_risk", 3) or 3)
    max_correlated = float(controls.get("max_correlated_risk", 6) or 6)
    max_daily = float(controls.get("max_daily_new_risk", 10) or 10)
    symbol = str(payload.get("symbol") or "-").upper()
    market = signal_market_category(payload)
    if snapshot["total_open_risk"] > max_total:
        errors.append(
            f"ریسک باز کل {snapshot['total_open_risk']:.2f}% از سقف {max_total:g}% عبور می‌کند"
        )
    if snapshot["by_market"].get(market, 0.0) > max_market:
        errors.append(f"ریسک بازار {market} از سقف {max_market:g}% عبور می‌کند")
    if snapshot["by_symbol"].get(symbol, 0.0) > max_symbol:
        errors.append(f"ریسک تجمیعی {symbol} از سقف {max_symbol:g}% عبور می‌کند")
    if snapshot["daily_new_risk"] > max_daily:
        errors.append(f"ریسک سیگنال‌های امروز از سقف {max_daily:g}% عبور می‌کند")
    if bool(controls.get("correlation_guard", True)):
        for group in correlation_groups(symbol):
            group_risk = float(snapshot["by_group"].get(group, 0.0))
            if group_risk > max_correlated:
                errors.append(
                    f"ریسک گروه هم‌بسته {group.upper()} برابر {group_risk:.2f}% و بیشتر از سقف {max_correlated:g}% است"
                )
            elif group_risk >= max_correlated * 0.8:
                warnings.append(f"ریسک گروه {group.upper()} به {group_risk:.2f}% رسیده است")
    return ExposureDecision(not errors, tuple(errors), tuple(warnings), snapshot)

