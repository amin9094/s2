from __future__ import annotations

import asyncio
import logging
from datetime import datetime

from telegram.error import BadRequest, Forbidden, TelegramError
from telegram.ext import ContextTypes

from config import SETTINGS
from core.async_runtime import run_blocking
from core.db import load_db, with_db
from core.domain import (
    expire_vips,
    mark_vip_removal_failed,
    mark_vip_removal_phase,
    mark_vip_removed,
)
from core.utils import parse_dt

logger = logging.getLogger(__name__)


def _phase_for(user_id: int) -> str:
    record = load_db().get("vip_users", {}).get(str(user_id), {})
    return str(record.get("channel_removal_phase") or "ban")


async def check_expired_vips(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Remove expired VIPs with durable retry and phase tracking.

    Ban and unban are tracked separately. If ban succeeds and unban fails, the
    next run resumes from unban instead of leaving the user permanently banned.
    """
    # Reconcile normalized Mini App entitlements before evaluating Telegram
    # channel access.  Failure is non-destructive: the next scheduled run will
    # retry and the normalized entitlement remains the source of truth.
    try:
        from services.vip_entitlement_projection import project_normalized_entitlements_to_legacy
        await run_blocking(project_normalized_entitlements_to_legacy)
    except Exception:
        logger.exception("Could not reconcile normalized VIP entitlements")
    due_ids = await run_blocking(with_db, expire_vips, timeout=20)
    for user_id in due_ids:
        phase = await run_blocking(_phase_for, user_id, timeout=10)
        try:
            if phase != "unban":
                await context.bot.ban_chat_member(chat_id=SETTINGS.private_channel_id, user_id=user_id)
                await run_blocking(with_db, lambda db, uid=user_id: mark_vip_removal_phase(db, uid, "unban"), timeout=10)
            await context.bot.unban_chat_member(
                chat_id=SETTINGS.private_channel_id,
                user_id=user_id,
                only_if_banned=True,
            )
        except BadRequest as exc:
            message = str(exc).lower()
            if any(token in message for token in ("user_not_participant", "not a member", "participant_id_invalid")):
                # The target is already outside the channel, so the access-control goal is complete.
                await run_blocking(with_db, lambda db, uid=user_id: mark_vip_removed(db, uid), timeout=10)
                continue
            logger.warning("Could not complete expired VIP removal for %s: %s", user_id, exc)
            await run_blocking(with_db, lambda db, uid=user_id, err=str(exc): mark_vip_removal_failed(db, uid, err), timeout=10)
        except (Forbidden, TelegramError) as exc:
            logger.warning("Could not complete expired VIP removal for %s: %s", user_id, exc)
            await run_blocking(with_db, lambda db, uid=user_id, err=str(exc): mark_vip_removal_failed(db, uid, err), timeout=10)
        except Exception as exc:  # defensive: keep removal retryable on unexpected client failures
            logger.exception("Unexpected error while removing expired VIP %s", user_id)
            await run_blocking(with_db, lambda db, uid=user_id, err=str(exc): mark_vip_removal_failed(db, uid, err), timeout=10)
        else:
            await run_blocking(with_db, lambda db, uid=user_id: mark_vip_removed(db, uid), timeout=10)


async def restore_vip_channel_access(bot, user_id: int, expires_at: str | None) -> str:
    """Ensure an extended VIP can re-enter and return a fresh one-use invite link."""
    try:
        await bot.unban_chat_member(
            chat_id=SETTINGS.private_channel_id,
            user_id=user_id,
            only_if_banned=True,
        )
    except BadRequest as exc:
        # Telegram may report that the user was never banned; invite creation can
        # still continue. Other BadRequest values are logged and re-raised.
        message = str(exc).lower()
        if "not banned" not in message and "user_not_participant" not in message:
            raise

    expiry: datetime | None = parse_dt(expires_at)
    kwargs: dict = {
        "chat_id": SETTINGS.private_channel_id,
        "member_limit": 1,
        "name": f"VIP-{user_id}",
    }
    if expiry:
        kwargs["expire_date"] = expiry
    link = await bot.create_chat_invite_link(**kwargs)
    return link.invite_link
