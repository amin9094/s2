from __future__ import annotations

import csv
import io
import json
import zipfile
from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now

MAX_DETAILED_ACTIVITY_ROWS = 100_000
MAX_POINT_LEDGER_ROWS = 100_000

SEGMENT_LABELS = {
    "new_user": "کاربر جدید",
    "active_user": "کاربر فعال",
    "warm_user": "کاربر نیمه‌فعال",
    "inactive_user": "کاربر غیرفعال",
    "vip_active": "VIP فعال",
    "vip_expired": "VIP منقضی",
    "never_vip": "بدون سابقه VIP",
    "first_buyer": "خریدار بار اول",
    "repeat_buyer": "خریدار تکراری",
    "loyal_buyer": "مشتری وفادار",
    "high_value": "مشتری باارزش",
    "education_buyer": "خریدار آموزش",
    "points_earner": "کاربر امتیازی",
    "points_spender": "خرج‌کننده امتیاز",
    "high_points": "امتیاز بالا",
    "referrer": "معرف فعال",
    "support_user": "کاربر پشتیبانی",
    "vip_viewer": "بازدیدکننده صفحه VIP",
    "plan_interested": "علاقه‌مند به پلن",
    "checkout_started": "شروع‌کننده خرید",
    "abandoned_checkout": "خرید رهاشده",
    "pending_buyer": "پرداخت در انتظار",
    "renewal_due": "نزدیک تمدید",
    "churned_customer": "مشتری ریزش‌کرده",
    "coupon_user": "استفاده‌کننده تخفیف",
    "public_coupon_user": "استفاده‌کننده کمپین عمومی",
    "behavior_explorer": "کاوشگر تازه‌وارد",
    "behavior_engaged": "کاربر درگیر و فعال",
    "behavior_vip_prospect": "مستعد خرید VIP",
    "behavior_paying": "مشتری پرداخت‌کننده",
    "behavior_advocate": "حامی و معرف برند",
    "behavior_at_risk": "در معرض ریزش",
    "behavior_dormant": "خوابیده",
    "behavior_support_sensitive": "نیازمند توجه پشتیبانی",
}


PROFILE_PRESERVED_FIELDS = {
    "phone",
    "phone_number",
    "email",
    "source",
    "lead_source",
    "company",
    "preferred_market",
    "preferred_contact",
    "assigned_admin",
    "notes",
    "tags",
    "timezone",
    "language",
    "metadata",
    "custom_fields",
}


def _preserve_manual_profile_fields(existing: dict[str, Any], generated: dict[str, Any]) -> dict[str, Any]:
    for key in PROFILE_PRESERVED_FIELDS:
        if key in existing:
            generated[key] = existing[key]
    if existing:
        previous = {key: value for key, value in existing.items() if key != "updated_at"}
        candidate = {key: value for key, value in generated.items() if key != "updated_at"}
        if previous == candidate and existing.get("updated_at"):
            generated["updated_at"] = existing["updated_at"]
    return generated


def _safe_int(value: Any) -> int:
    try:
        return int(str(value or 0).replace(",", ""))
    except (TypeError, ValueError):
        return 0


def _rows(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [row for row in value if isinstance(row, dict)]


def _mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _date(value: Any) -> datetime | None:
    return parse_dt(value)


def _approved(row: dict[str, Any]) -> bool:
    return str(row.get("status") or "").lower() == "approved"


def point_ledger_summary(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    rows = [row for row in _rows(db.get("point_history")) if str(row.get("user_id")) == uid]
    received = sum(max(0, _safe_int(row.get("amount"))) for row in rows)
    spent = sum(abs(min(0, _safe_int(row.get("amount")))) for row in rows)
    return {
        "current": max(0, _safe_int(_mapping(db.get("user_points")).get(uid))),
        "received": received,
        "spent": spent,
        "transaction_count": len(rows),
        "earned_transaction_count": sum(1 for row in rows if _safe_int(row.get("amount")) > 0),
        "spent_transaction_count": sum(1 for row in rows if _safe_int(row.get("amount")) < 0),
        "last_transaction_at": rows[-1].get("created_at") if rows else None,
    }


def _activity_aggregate(db: dict[str, Any], uid: str) -> dict[str, Any]:
    existing = _mapping(_mapping(db.get("user_profiles")).get(uid)).get("activity_summary")
    if isinstance(existing, dict):
        counts = existing.get("counts", {})
        return {
            "total": max(0, _safe_int(existing.get("total"))),
            "counts": dict(counts) if isinstance(counts, dict) else {},
            "first_at": existing.get("first_at"),
            "last_at": existing.get("last_at"),
            "last_action": existing.get("last_action"),
        }
    rows = [row for row in _rows(db.get("user_activity")) if str(row.get("user_id")) == uid]
    counts = Counter(str(row.get("action") or "unknown") for row in rows)
    return {
        "total": len(rows),
        "counts": dict(counts),
        "first_at": rows[0].get("created_at") if rows else None,
        "last_at": rows[-1].get("created_at") if rows else None,
        "last_action": rows[-1].get("action") if rows else None,
    }


def _segments_for_profile(profile: dict[str, Any], *, now: datetime) -> list[str]:
    segments: list[str] = []
    created = _date(profile.get("created_at"))
    last_seen = _date(profile.get("last_seen_at")) or created
    if created and created >= now - timedelta(days=7):
        segments.append("new_user")
    if last_seen and last_seen >= now - timedelta(days=7):
        segments.append("active_user")
    elif last_seen and last_seen >= now - timedelta(days=30):
        segments.append("warm_user")
    else:
        segments.append("inactive_user")

    if profile.get("vip_active"):
        segments.append("vip_active")
    elif profile.get("vip_purchase_count", 0) > 0:
        segments.append("vip_expired")
    else:
        segments.append("never_vip")

    purchases = _safe_int(profile.get("vip_purchase_count"))
    if purchases >= 4:
        segments.append("loyal_buyer")
    elif purchases >= 2:
        segments.append("repeat_buyer")
    elif purchases == 1:
        segments.append("first_buyer")

    if _safe_int(profile.get("total_spend")) >= max(3_000_000, _safe_int(profile.get("vip_current_price")) * 4):
        segments.append("high_value")
    if _safe_int(profile.get("education_purchase_count")) > 0:
        segments.append("education_buyer")
    if _safe_int(profile.get("points_received")) > 0:
        segments.append("points_earner")
    if _safe_int(profile.get("points_spent")) > 0:
        segments.append("points_spender")
    if _safe_int(profile.get("points_current")) >= 500:
        segments.append("high_points")
    if _safe_int(profile.get("referral_count")) > 0:
        segments.append("referrer")
    if _safe_int(profile.get("ticket_count")) > 0:
        segments.append("support_user")

    activity_counts = _mapping(profile.get("activity_summary")).get("counts", {})
    activity_counts = activity_counts if isinstance(activity_counts, dict) else {}
    if _safe_int(activity_counts.get("vip_page_viewed")) > 0:
        segments.append("vip_viewer")
    if _safe_int(activity_counts.get("vip_plan_selected")) > 0:
        segments.append("plan_interested")
    checkout_count = sum(_safe_int(activity_counts.get(key)) for key in ("vip_checkout_started", "vip_coupon_step", "vip_receipt_requested"))
    if checkout_count > 0:
        segments.append("checkout_started")
    if _safe_int(profile.get("vip_pending_count")) > 0:
        segments.append("pending_buyer")
    if checkout_count > _safe_int(profile.get("vip_order_count")) and _safe_int(profile.get("vip_pending_count")) == 0:
        segments.append("abandoned_checkout")
    expiry = _date(profile.get("vip_expires_at"))
    if profile.get("vip_active") and expiry and now <= expiry <= now + timedelta(days=7):
        segments.append("renewal_due")
    if "vip_expired" in segments and last_seen and last_seen < now - timedelta(days=30):
        segments.append("churned_customer")
    if _safe_int(profile.get("coupon_order_count")) > 0:
        segments.append("coupon_user")
    if _safe_int(profile.get("public_coupon_order_count")) > 0:
        segments.append("public_coupon_user")
    persona = str(profile.get("behavior_persona") or "")
    if persona:
        segments.append(f"behavior_{persona}")
    return segments


def _behavior_scores(profile: dict[str, Any], *, now: datetime) -> dict[str, Any]:
    activity = _mapping(profile.get("activity_summary"))
    counts = _mapping(activity.get("counts"))
    total = _safe_int(activity.get("total"))
    recent = _date(profile.get("last_seen_at")) or _date(profile.get("created_at"))
    recency_days = max(0, (now - recent).days) if recent else 999
    vip_views = _safe_int(counts.get("vip_page_viewed"))
    plan_selects = _safe_int(counts.get("vip_plan_selected"))
    checkouts = sum(
        _safe_int(counts.get(key))
        for key in ("vip_checkout_started", "vip_coupon_step", "vip_receipt_requested")
    )
    market_actions = sum(
        _safe_int(counts.get(key))
        for key in (
            "signal_viewed",
            "price_viewed",
            "price_search",
            "watchlist_added",
            "journal_created",
            "calculator_used",
        )
    )
    support_actions = _safe_int(profile.get("ticket_count"))
    purchase_count = _safe_int(profile.get("total_purchase_count"))
    intent = min(100, vip_views * 8 + plan_selects * 15 + checkouts * 22 + (15 if "pending_buyer" in profile.get("segments", []) else 0))
    engagement = min(
        100,
        total * 2
        + market_actions * 4
        + _safe_int(profile.get("referral_count")) * 8
        + (20 if recency_days <= 2 else 10 if recency_days <= 7 else 0),
    )
    churn = min(
        100,
        (55 if recency_days > 30 else 30 if recency_days > 14 else 10 if recency_days > 7 else 0)
        + (25 if profile.get("vip_active") and recency_days > 14 else 0)
        + (20 if "vip_expired" in profile.get("segments", []) else 0),
    )
    if churn >= 60 and purchase_count:
        persona = "at_risk"
    elif recency_days > 45 and not purchase_count:
        persona = "dormant"
    elif support_actions >= 3 and engagement < 45:
        persona = "support_sensitive"
    elif _safe_int(profile.get("referral_count")) >= 2 or _safe_int(profile.get("vip_purchase_count")) >= 4:
        persona = "advocate"
    elif purchase_count:
        persona = "paying"
    elif intent >= 35:
        persona = "vip_prospect"
    elif engagement >= 35:
        persona = "engaged"
    else:
        persona = "explorer"
    return {
        "behavior_persona": persona,
        "engagement_score": engagement,
        "purchase_intent_score": intent,
        "churn_risk_score": churn,
        "recency_days": recency_days,
        "market_action_count": market_actions,
    }


def _primary_category(profile: dict[str, Any], segments: list[str]) -> tuple[str, str]:
    priority = (
        "loyal_buyer",
        "high_value",
        "renewal_due",
        "pending_buyer",
        "vip_active",
        "repeat_buyer",
        "first_buyer",
        "abandoned_checkout",
        "churned_customer",
        "vip_expired",
        "high_points",
        "education_buyer",
        "active_user",
        "new_user",
        "warm_user",
        "inactive_user",
    )
    code = next((item for item in priority if item in segments), "inactive_user")
    return code, SEGMENT_LABELS[code]


def build_user_profile(
    db: dict[str, Any],
    user_id: int | str,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = (now or utc_now()).astimezone(UTC)
    uid = str(user_id)
    user = _mapping(_mapping(db.get("users")).get(uid))
    vip = _mapping(_mapping(db.get("vip_users")).get(uid))
    expiry = _date(vip.get("expires_at"))
    vip_active = bool(expiry and expiry > current and str(vip.get("status") or "active") != "expired")

    vip_orders = [row for row in _rows(db.get("vip_orders")) if str(row.get("user_id")) == uid]
    approved_vip = [row for row in vip_orders if _approved(row)]
    education_orders = [row for row in _rows(db.get("education_orders")) if str(row.get("user_id")) == uid]
    approved_education = [row for row in education_orders if _approved(row)]
    tickets = [row for row in _rows(db.get("tickets")) if str(row.get("user_id")) == uid]
    rewards = [row for row in _rows(db.get("user_rewards")) if str(row.get("user_id")) == uid]
    reward_requests = [row for row in _rows(db.get("reward_requests")) if str(row.get("user_id")) == uid]
    referral = _mapping(_mapping(db.get("user_referrals")).get(uid))
    points = point_ledger_summary(db, uid)
    activity = _activity_aggregate(db, uid)
    vip_spend = sum(_safe_int(row.get("price")) for row in approved_vip)
    education_spend = sum(_safe_int(row.get("price")) for row in approved_education)

    profile: dict[str, Any] = {
        "user_id": uid,
        "username": str(user.get("username") or ""),
        "first_name": str(user.get("first_name") or ""),
        "last_name": str(user.get("last_name") or ""),
        "created_at": user.get("created_at"),
        "last_seen_at": user.get("last_seen_at"),
        "vip_active": vip_active,
        "vip_expires_at": vip.get("expires_at"),
        "vip_order_count": len(vip_orders),
        "vip_purchase_count": len(approved_vip),
        "vip_renewal_count": max(0, len(approved_vip) - 1),
        "vip_pending_count": sum(1 for row in vip_orders if str(row.get("status")) in {"pending", "approving"}),
        "vip_spend": vip_spend,
        "coupon_order_count": sum(1 for row in vip_orders if str(row.get("coupon") or "")),
        "public_coupon_order_count": sum(
            1 for row in vip_orders
            if str(row.get("coupon") or "")
            and str(_mapping(db.get("discount_codes")).get(str(row.get("coupon") or "").upper(), {}).get("scope") or "") == "public"
        ),
        "vip_current_price": _safe_int(_mapping(db.get("vip_settings")).get("price")),
        "education_purchase_count": len(approved_education),
        "education_spend": education_spend,
        "total_purchase_count": len(approved_vip) + len(approved_education),
        "total_spend": vip_spend + education_spend,
        "points_current": points["current"],
        "points_received": points["received"],
        "points_spent": points["spent"],
        "point_transaction_count": points["transaction_count"],
        "reward_count": len(rewards),
        "reward_request_count": len(reward_requests),
        "ticket_count": len(tickets),
        "open_ticket_count": sum(1 for row in tickets if str(row.get("status")) == "open"),
        "referral_count": len(referral.get("invited", [])) if isinstance(referral.get("invited"), list) else 0,
        "activity_summary": activity,
        "updated_at": utc_iso(current),
    }
    # First pass supplies lifecycle and commerce context to the behavior model.
    profile["segments"] = _segments_for_profile(profile, now=current)
    profile.update(_behavior_scores(profile, now=current))
    segments = _segments_for_profile(profile, now=current)
    code, label = _primary_category(profile, segments)
    profile["segments"] = segments
    profile["segment_labels"] = [SEGMENT_LABELS[item] for item in segments]
    profile["primary_category"] = code
    profile["primary_category_label"] = label
    return profile


def refresh_user_profile(db: dict[str, Any], user_id: int | str, *, now: datetime | None = None) -> dict[str, Any]:
    uid = str(user_id)
    profiles = db.setdefault("user_profiles", {})
    existing = _mapping(profiles.get(uid))
    profile = _preserve_manual_profile_fields(existing, build_user_profile(db, uid, now=now))
    profiles[uid] = profile
    return profile


def rebuild_all_user_profiles(db: dict[str, Any], *, now: datetime | None = None) -> dict[str, dict[str, Any]]:
    user_ids: set[str] = {str(uid) for uid in _mapping(db.get("users"))}
    for section in ("user_points", "vip_users", "user_referrals", "education_access"):
        user_ids.update(str(uid) for uid in _mapping(db.get(section)))
    for section in ("vip_orders", "education_orders", "tickets", "user_rewards", "reward_requests", "point_history", "user_activity"):
        user_ids.update(str(row.get("user_id")) for row in _rows(db.get(section)) if row.get("user_id") is not None)
    profiles = db.setdefault("user_profiles", {})
    for uid in sorted(user_ids, key=lambda value: (0, int(value)) if value.isdigit() else (1, value)):
        existing = _mapping(profiles.get(uid))
        profiles[uid] = _preserve_manual_profile_fields(existing, build_user_profile(db, uid, now=now))
    return profiles


def record_user_activity(
    db: dict[str, Any],
    user_id: int | str,
    action: str,
    *,
    source: str = "bot",
    detail: str = "",
    metadata: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    uid = str(user_id)
    stamp = created_at or utc_iso()
    ids = db.setdefault("next_ids", {})
    event_id = max(1, _safe_int(ids.get("user_activity", 1)))
    ids["user_activity"] = event_id + 1
    event = {
        "id": event_id,
        "user_id": uid,
        "action": str(action or "unknown")[:120],
        "source": str(source or "bot")[:40],
        "detail": str(detail or "")[:500],
        "metadata": metadata if isinstance(metadata, dict) else {},
        "created_at": stamp,
    }
    rows = db.setdefault("user_activity", [])
    rows.append(event)
    if len(rows) > MAX_DETAILED_ACTIVITY_ROWS:
        del rows[: len(rows) - MAX_DETAILED_ACTIVITY_ROWS]

    profiles = db.setdefault("user_profiles", {})
    profile = profiles.setdefault(uid, {"user_id": uid})
    summary = profile.setdefault("activity_summary", {"total": 0, "counts": {}, "first_at": None, "last_at": None, "last_action": None})
    counts = summary.setdefault("counts", {})
    summary["total"] = max(0, _safe_int(summary.get("total"))) + 1
    counts[event["action"]] = max(0, _safe_int(counts.get(event["action"]))) + 1
    summary["first_at"] = summary.get("first_at") or stamp
    summary["last_at"] = stamp
    summary["last_action"] = event["action"]
    profile["updated_at"] = stamp
    return event


def _csv_bytes(headers: list[str], rows: list[list[Any]]) -> bytes:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(headers)
    writer.writerows(rows)
    return output.getvalue().encode("utf-8-sig")


def user_master_csv(db: dict[str, Any]) -> bytes:
    profiles = rebuild_all_user_profiles(db)
    rows: list[list[Any]] = []
    for uid, profile in sorted(profiles.items(), key=lambda item: int(item[0]) if item[0].isdigit() else 0):
        activity = _mapping(profile.get("activity_summary"))
        rows.append([
            uid,
            profile.get("username", ""),
            profile.get("first_name", ""),
            profile.get("last_name", ""),
            profile.get("primary_category_label", ""),
            " | ".join(profile.get("segment_labels", [])),
            "yes" if profile.get("vip_active") else "no",
            profile.get("vip_expires_at", ""),
            profile.get("vip_purchase_count", 0),
            profile.get("vip_renewal_count", 0),
            profile.get("vip_spend", 0),
            profile.get("education_purchase_count", 0),
            profile.get("education_spend", 0),
            profile.get("total_spend", 0),
            profile.get("points_current", 0),
            profile.get("points_received", 0),
            profile.get("points_spent", 0),
            profile.get("reward_count", 0),
            profile.get("referral_count", 0),
            profile.get("ticket_count", 0),
            activity.get("total", 0),
            activity.get("last_action", ""),
            activity.get("last_at", ""),
            profile.get("created_at", ""),
            profile.get("last_seen_at", ""),
        ])
    return _csv_bytes(
        [
            "user_id", "username", "first_name", "last_name", "primary_category", "segments", "vip_active",
            "vip_expires_at", "vip_purchase_count", "vip_renewal_count", "vip_spend", "education_purchase_count",
            "education_spend", "total_spend", "points_current", "points_received", "points_spent", "reward_count",
            "referral_count", "ticket_count", "activity_total", "last_action", "last_activity_at", "created_at", "last_seen_at",
        ],
        rows,
    )


def user_activity_csv(db: dict[str, Any]) -> bytes:
    rows = [
        [
            row.get("id", ""),
            row.get("user_id", ""),
            row.get("action", ""),
            row.get("source", ""),
            row.get("detail", ""),
            json.dumps(row.get("metadata", {}), ensure_ascii=False, separators=(",", ":")),
            row.get("created_at", ""),
        ]
        for row in _rows(db.get("user_activity"))
    ]
    return _csv_bytes(["id", "user_id", "action", "source", "detail", "metadata", "created_at"], rows)


def points_ledger_csv(db: dict[str, Any]) -> bytes:
    rows = [
        [
            row.get("id", ""),
            row.get("user_id", ""),
            row.get("amount", 0),
            row.get("direction", "earned" if _safe_int(row.get("amount")) >= 0 else "spent"),
            row.get("balance_after", ""),
            row.get("reason", ""),
            row.get("created_at", ""),
        ]
        for row in _rows(db.get("point_history"))
    ]
    return _csv_bytes(["id", "user_id", "amount", "direction", "balance_after", "reason", "created_at"], rows)


def _filtered_user_database(db: dict[str, Any]) -> dict[str, Any]:
    allowed = (
        "schema_version", "users", "user_profiles", "vip_users", "vip_orders", "education_orders", "education_access",
        "user_points", "point_history", "user_referrals", "user_rewards", "reward_requests", "user_missions", "tickets",
        "price_alerts", "user_bans", "crm_profiles", "user_activity",
    )
    return {key: db.get(key) for key in allowed}


def full_user_export_zip(db: dict[str, Any]) -> bytes:
    rebuild_all_user_profiles(db)
    payload = _filtered_user_database(db)
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("users_master.csv", user_master_csv(db))
        archive.writestr("points_ledger.csv", points_ledger_csv(db))
        archive.writestr("user_activity.csv", user_activity_csv(db))
        archive.writestr(
            "vip_orders.csv",
            _csv_bytes(
                ["order_id", "user_id", "status", "price", "days", "created_at", "approved_at", "expires_at"],
                [
                    [
                        row.get("order_id", ""), row.get("user_id", ""), row.get("status", ""), row.get("price", 0),
                        row.get("days", ""), row.get("created_at", ""), row.get("approved_at", ""), row.get("expires_at", ""),
                    ]
                    for row in _rows(db.get("vip_orders"))
                ],
            ),
        )
        archive.writestr("user_database.json", json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8"))
        archive.writestr(
            "README_FA.txt",
            (
                "خروجی کامل اطلاعات کاربران SENTINEL\n"
                "users_master.csv: خلاصه، دسته‌بندی، خرید، تمدید، امتیاز و فعالیت هر کاربر\n"
                "points_ledger.csv: دفتر کل امتیازهای دریافتی و خرج‌شده\n"
                "user_activity.csv: رویدادهای جزئی ثبت‌شده در ربات\n"
                "vip_orders.csv: همه سفارش‌های اشتراک\n"
                "user_database.json: داده کامل کاربرمحور برای بازیابی یا تحلیل\n"
            ).encode(),
        )
    return output.getvalue()
