from __future__ import annotations

from typing import Any

BOT_GUIDE_TOPICS: dict[str, dict[str, Any]] = {
    "start": {
        "title": "شروع سریع",
        "summary": "آشنایی با مسیرهای اصلی ربات و انتخاب سریع ابزار مناسب.",
        "body": "از منوی اصلی پنج ابزار پرکاربرد مستقیماً در دسترس‌اند: خرید اشتراک، آموزش، قیمت بازار، ماشین‌حساب و مسابقه‌ها. بخش‌های سیگنال، واچ‌لیست و ژورنال داخل مرکز معامله‌گری قرار دارند.",
        "destination": "home",
    },
    "vip": {
        "title": "خرید و تمدید اشتراک",
        "summary": "انتخاب پلن، روش پرداخت، کد تخفیف و ارسال رسید.",
        "body": "ابتدا پلن مناسب را انتخاب کنید. سپس یکی از روش‌های فعال کارت بانکی یا تتر را انتخاب کنید، کد تخفیف را وارد کنید یا بدون کد ادامه دهید و تصویر رسید را بفرستید. بعد از تأیید ادمین، اشتراک فعال می‌شود، لینک یک‌بارمصرف کانال خصوصی ارسال می‌شود و در پایان مدت پلن دسترسی کانال خودکار قطع خواهد شد.",
        "destination": "u_vip",
    },
    "education": {
        "title": "استفاده از آموزش‌ها",
        "summary": "آموزش رایگان، آموزش پولی و ثبت پیشرفت مطالعه.",
        "body": "آموزش‌های رایگان مستقیم باز می‌شوند. برای آموزش پولی پس از پرداخت و تأیید ادمین دسترسی دائمی فعال می‌شود. در هر درس می‌توانید مطالعه را کامل و امتیاز ثبت کنید.",
        "destination": "u_edu",
    },
    "prices": {
        "title": "قیمت بازار و جست‌وجوی نماد",
        "summary": "دسترسی به فارکس، طلا، رمزارز، سهام و انرژی.",
        "body": "از قیمت بازار وارد بخش موردنظر شوید. برای رمزارز و سهام امکان جست‌وجوی نام یا نماد وجود دارد. واچ‌لیست شخصی داخل مرکز معامله‌گری مدیریت می‌شود.",
        "destination": "u_price",
    },
    "calculator": {
        "title": "ماشین‌حساب مدیریت ریسک",
        "summary": "محاسبه حجم معامله براساس موجودی، ریسک، ورود و حد ضرر.",
        "body": "نماد، موجودی حساب، درصد ریسک، قیمت ورود و حد ضرر را وارد کنید. ربات حجم پیشنهادی را محاسبه می‌کند. قبل از معامله، نتیجه را با شرایط بروکر خود بررسی کنید.",
        "destination": "u_calc",
    },
    "contests": {
        "title": "مسابقه‌ها و امتیازها",
        "summary": "شرکت در چالش‌ها، ثبت پاسخ و دریافت امتیاز.",
        "body": "در بخش مسابقه‌ها چالش‌های فعال نمایش داده می‌شوند. پاسخ را طبق راهنمای همان مسابقه ثبت کنید و نتیجه را در حساب یا باشگاه پیگیری کنید.",
        "destination": "u_contests",
    },
    "trading": {
        "title": "مرکز معامله‌گری",
        "summary": "سیگنال‌ها، واچ‌لیست و ژورنال در یک مسیر منظم.",
        "body": "در سیگنال‌های من، وضعیت و نتیجه هر سیگنال را می‌بینید. نمادهای مهم را به واچ‌لیست اضافه کنید و معاملات گرفته‌شده را در ژورنال ثبت و نتیجه‌گذاری کنید.",
        "destination": "nav_user:trade",
    },
    "account": {
        "title": "حساب، باشگاه و پشتیبانی",
        "summary": "مشاهده اشتراک، فعالیت، جوایز، معرفی دوستان و تیکت‌ها.",
        "body": "از حساب و باشگاه، وضعیت VIP، خریدها، امتیاز، مأموریت‌ها و جوایز را پیگیری کنید. برای مشکل یا سوال، از خدمات و پشتیبانی تیکت ثبت کنید.",
        "destination": "u_account",
    },
    "search": {
        "title": "جست‌وجوی داخلی",
        "summary": "پیداکردن آموزش، سوال متداول، نماد و بخش‌های ربات.",
        "body": "عبارت موردنظر را بنویسید؛ ربات در راهنمای خود، آموزش‌ها، سوالات متداول و سیگنال‌های قابل مشاهده جست‌وجو می‌کند و مسیر مناسب را نشان می‌دهد.",
        "destination": "u_search",
    },
}

BOT_GUIDE_TOPICS_EN: dict[str, dict[str, Any]] = {
    "start": {
        "title": "Quick start",
        "summary": "Learn the main routes and reach the right tool quickly.",
        "body": "The home screen gives you direct access to VIP, education, market prices, the risk calculator and contests. Signals, watchlist and journal are grouped inside Trading Center.",
        "destination": "home",
    },
    "vip": {
        "title": "Buy or renew VIP",
        "summary": "Choose a plan, payment method and discount code, then submit the receipt.",
        "body": "Choose a plan and an enabled payment method, apply an optional discount, then submit the required payment evidence. After admin verification, VIP is activated and a one-time private-channel invite is delivered.",
        "destination": "u_vip",
    },
    "education": {
        "title": "Education",
        "summary": "Access free and paid lessons and track your progress.",
        "body": "Free lessons open immediately. Paid courses become permanently available after payment verification. You can mark lessons as completed and track progress from your account.",
        "destination": "u_edu",
    },
    "prices": {
        "title": "Market prices and symbol search",
        "summary": "Search forex, metals, crypto, equities and energy markets.",
        "body": "Open Market Prices, choose a market and search by symbol or asset name. Quotes include freshness, source confidence and provider information when available.",
        "destination": "u_price",
    },
    "calculator": {
        "title": "Risk calculator",
        "summary": "Estimate position size from balance, risk, entry and stop loss.",
        "body": "Enter the symbol, account balance, risk percentage, entry and stop loss. SENTINEL estimates the position size; always verify contract specifications with your broker or exchange.",
        "destination": "u_calc",
    },
    "contests": {
        "title": "Contests and points",
        "summary": "Join active challenges and earn points.",
        "body": "Active challenges are listed in Contests. Follow each challenge's instructions, submit your answer and track the result from Account & Club.",
        "destination": "u_contests",
    },
    "trading": {
        "title": "Trading center",
        "summary": "Signals, watchlist and journal in one structured workspace.",
        "body": "Review visible signals and their outcomes, maintain a personal watchlist and record taken trades in the journal.",
        "destination": "nav_user:trade",
    },
    "account": {
        "title": "Account, club and support",
        "summary": "Manage VIP, activity, rewards, referrals and support tickets.",
        "body": "Account & Club shows VIP status, purchases, points, missions and rewards. Use Services & Support to open and follow support tickets.",
        "destination": "u_account",
    },
    "search": {
        "title": "Internal search",
        "summary": "Find guides, FAQs, symbols and bot sections.",
        "body": "Send a keyword to search the built-in guide, active lessons, FAQs and visible signals, then open the matching destination.",
        "destination": "u_search",
    },
}


def _normalize(value: Any) -> str:
    text = str(value or "").strip().casefold()
    replacements = {"ي": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه", "‌": " "}
    for source, target in replacements.items():
        text = text.replace(source, target)
    return " ".join(text.split())


def search_internal(
    db: dict[str, Any],
    user_id: int | str,
    query: str,
    *,
    limit: int = 12,
    language: str = "fa",
) -> list[dict[str, Any]]:
    english = str(language or "").lower().startswith("en")
    term = _normalize(query)
    if len(term) < 2:
        return []
    results: list[dict[str, Any]] = []

    def add(kind: str, title: str, subtitle: str, callback: str, haystack: str, score: int) -> None:
        normalized = _normalize(haystack)
        if term not in normalized:
            tokens = [token for token in term.split() if token]
            if not tokens or not all(token in normalized for token in tokens):
                return
        results.append({"kind": kind, "title": title[:80], "subtitle": subtitle[:160], "callback": callback, "score": score})

    guide_topics = BOT_GUIDE_TOPICS_EN if english else BOT_GUIDE_TOPICS
    for key, topic in guide_topics.items():
        add("guide", topic["title"], topic["summary"], f"bot_guide:{key}", f"{topic['title']} {topic['summary']} {topic['body']}", 100)

    navigation = ([
        ("VIP subscription", "Choose a plan and submit payment", "u_vip"),
        ("Education", "Free and paid lessons", "u_edu"),
        ("Market prices", "Forex, metals, crypto, equities and energy", "u_price"),
        ("Risk calculator", "Estimate position size and risk", "u_calc"),
        ("Contests", "Challenges and points", "u_contests"),
        ("Trading center", "Signals, watchlist and journal", "nav_user:trade"),
        ("Account and club", "Subscription, rewards and referrals", "u_account"),
        ("Support", "Tickets and frequently asked questions", "nav_user:growth"),
    ] if english else [
        ("خرید اشتراک VIP", "انتخاب پلن و ثبت پرداخت", "u_vip"),
        ("آموزش", "آموزش رایگان و پولی", "u_edu"),
        ("قیمت بازار", "طلا، ارز، رمزارز، سهام و انرژی", "u_price"),
        ("ماشین حساب ریسک", "محاسبه حجم و ریسک معامله", "u_calc"),
        ("مسابقه‌ها", "چالش و امتیاز", "u_contests"),
        ("مرکز معامله‌گری", "سیگنال، واچ‌لیست و ژورنال", "nav_user:trade"),
        ("حساب و باشگاه", "اشتراک، جوایز و معرفی دوستان", "u_account"),
        ("پشتیبانی", "تیکت و سوالات متداول", "nav_user:growth"),
    ])
    for title, subtitle, callback in navigation:
        add("menu", title, subtitle, callback, f"{title} {subtitle}", 90)

    for faq in db.get("faqs", []):
        if not isinstance(faq, dict) or not faq.get("active", True):
            continue
        question = str(faq.get("q_en") or faq.get("q") or faq.get("question") or ("FAQ" if english else "سوال متداول")) if english else str(faq.get("q") or faq.get("question") or "سوال متداول")
        answer = str(faq.get("a_en") or faq.get("a") or faq.get("answer") or "") if english else str(faq.get("a") or faq.get("answer") or "")
        add("faq", question, answer[:140], f"faq:{faq.get('id')}", f"{question} {answer}", 75)

    for lesson in db.get("lessons", []):
        if not isinstance(lesson, dict) or not lesson.get("active", True) or lesson.get("status", "published") != "published":
            continue
        title = str(lesson.get("title_en") or lesson.get("title") or ("Lesson" if english else "آموزش")) if english else str(lesson.get("title") or "آموزش")
        category = str(lesson.get("category_en") or lesson.get("category") or lesson.get("course") or ("Education" if english else "آموزش")) if english else str(lesson.get("category") or lesson.get("course") or "آموزش")
        content = str(lesson.get("text_en") or lesson.get("text") or "") if english else str(lesson.get("text") or "")
        add("lesson", title, category, f"lesson:{lesson.get('id')}", f"{title} {category} {content}", 70)

    vip_users = db.get("vip_users", {})
    is_vip_user = False
    try:
        from core.domain import is_vip
        is_vip_user = is_vip(db, user_id)
    except Exception:
        is_vip_user = str(user_id) in vip_users
    from modules.signal_portal import user_visible_signals
    for signal in user_visible_signals(db, vip=is_vip_user)[:100]:
        symbol = str(signal.get("symbol") or "")
        add("signal", f"Signal {symbol}" if english else f"سیگنال {symbol}", f"{str(signal.get('side') or '').upper()} | {'Entry' if english else 'ورود'} {signal.get('entry')}", f"user_signal_view:{signal.get('id')}", f"{symbol} {signal.get('side')} {signal.get('entry')} {signal.get('targets')} {signal.get('status')}", 65)

    results.sort(key=lambda row: (-int(row["score"]), row["title"]))
    unique: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for row in results:
        key = (row["kind"], row["callback"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(row)
        if len(unique) >= max(1, min(limit, 20)):
            break
    return unique
