from __future__ import annotations

from typing import Any

from core.utils import utc_iso

_SETTING_KEY = "miniapp_runtime"


def miniapp_runtime_state(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("settings", {})
    row = settings.get(_SETTING_KEY)
    if not isinstance(row, dict):
        row = {"enabled": True, "updated_at": utc_iso(), "updated_by": "system", "reason": ""}
        settings[_SETTING_KEY] = row
    row.setdefault("enabled", True)
    row.setdefault("updated_at", utc_iso())
    row.setdefault("updated_by", "system")
    row.setdefault("reason", "")
    return dict(row)


def miniapp_enabled(db: dict[str, Any]) -> bool:
    return bool(miniapp_runtime_state(db).get("enabled", True))


def set_miniapp_enabled(
    db: dict[str, Any],
    enabled: bool,
    *,
    actor_id: int | str,
    reason: str = "",
) -> dict[str, Any]:
    row = {
        "enabled": bool(enabled),
        "updated_at": utc_iso(),
        "updated_by": str(actor_id),
        "reason": str(reason or "")[:500],
    }
    db.setdefault("settings", {})[_SETTING_KEY] = row
    return dict(row)
