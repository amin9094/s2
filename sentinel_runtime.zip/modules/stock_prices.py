from __future__ import annotations

import math
import re
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from core.async_primitives import LoopLocalLock
from core.http_client import get_json
from modules.api_credentials import alpha_vantage_key

_ALPHA_URL = "https://www.alphavantage.co/query"
_SEARCH_CACHE_SECONDS = 600
_QUOTE_CACHE_SECONDS = 60
_LOCK = LoopLocalLock()
_SEARCH_CACHE: dict[str, tuple[float, list[StockSearchResult]]] = {}
_QUOTE_CACHE: dict[str, tuple[float, StockQuote]] = {}
_SYMBOL_RE = re.compile(r"^[A-Z0-9.\-]{1,20}$")


@dataclass(frozen=True, slots=True)
class StockSearchResult:
    symbol: str
    name: str
    region: str
    currency: str
    match_score: float


@dataclass(frozen=True, slots=True)
class StockQuote:
    symbol: str
    price: float | None
    open: float | None
    high: float | None
    low: float | None
    previous_close: float | None
    change: float | None
    change_percent: float | None
    volume: int | None
    latest_trading_day: str
    source: str
    updated_at: datetime


def popular_stocks() -> tuple[tuple[str, str], ...]:
    return (
        ("AAPL", "Apple"),
        ("MSFT", "Microsoft"),
        ("NVDA", "NVIDIA"),
        ("TSLA", "Tesla"),
        ("AMZN", "Amazon"),
        ("META", "Meta"),
        ("GOOGL", "Alphabet"),
        ("XOM", "Exxon Mobil"),
    )


def _key() -> str:
    key = alpha_vantage_key()
    if not key:
        raise ValueError("کلید ALPHA_VANTAGE_API_KEY توسط ادمین تنظیم نشده است.")
    return key


def _float(value: Any) -> float | None:
    try:
        number = float(str(value).replace("%", "").replace(",", ""))
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


async def _json(params: dict[str, str]) -> dict[str, Any]:
    payload = await get_json(
        _ALPHA_URL,
        params=params,
        headers={"User-Agent": "SENTINELBot/5.2"},
        retries=2,
    )
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ سرویس سهام معتبر نیست")
    error = payload.get("Information") or payload.get("Note") or payload.get("Error Message")
    if error:
        text = str(error)[:300]
        lowered = text.casefold()
        if "frequency" in lowered or "rate limit" in lowered or "premium" in lowered:
            raise RuntimeError("سهمیه یا سطح دسترسی پلن Alpha Vantage کافی نیست؛ چند دقیقه بعد تلاش کنید.")
        if "api key" in lowered or "apikey" in lowered:
            raise RuntimeError("کلید Alpha Vantage نامعتبر است یا هنوز فعال نشده است.")
        raise RuntimeError(text)
    return payload


async def search_stocks(query: str, *, limit: int = 8) -> list[StockSearchResult]:
    term = re.sub(r"\s+", " ", str(query or "").strip())[:80]
    if len(term) < 1:
        raise ValueError("نام شرکت یا نماد سهام را وارد کنید.")
    cache_key = term.casefold()
    cached = _SEARCH_CACHE.get(cache_key)
    if cached and time.monotonic() - cached[0] < _SEARCH_CACHE_SECONDS:
        return cached[1][:limit]
    async with _LOCK():
        cached = _SEARCH_CACHE.get(cache_key)
        if cached and time.monotonic() - cached[0] < _SEARCH_CACHE_SECONDS:
            return cached[1][:limit]
        payload = await _json({"function": "SYMBOL_SEARCH", "keywords": term, "apikey": _key()})
        rows: list[StockSearchResult] = []
        for item in payload.get("bestMatches", []):
            if not isinstance(item, dict):
                continue
            symbol = str(item.get("1. symbol") or "").strip().upper()
            if not _SYMBOL_RE.fullmatch(symbol):
                continue
            rows.append(
                StockSearchResult(
                    symbol=symbol,
                    name=str(item.get("2. name") or symbol).strip()[:120],
                    region=str(item.get("4. region") or "").strip()[:60],
                    currency=str(item.get("8. currency") or "").strip()[:20],
                    match_score=_float(item.get("9. matchScore")) or 0.0,
                )
            )
        rows.sort(key=lambda item: item.match_score, reverse=True)
        _SEARCH_CACHE[cache_key] = (time.monotonic(), rows[:20])
        return rows[:limit]


async def fetch_stock_quote(symbol: str, *, force: bool = False) -> StockQuote:
    clean = str(symbol or "").strip().upper()
    if not _SYMBOL_RE.fullmatch(clean):
        raise ValueError("نماد سهام معتبر نیست.")
    cached = _QUOTE_CACHE.get(clean)
    if not force and cached and time.monotonic() - cached[0] < _QUOTE_CACHE_SECONDS:
        return cached[1]
    async with _LOCK():
        cached = _QUOTE_CACHE.get(clean)
        if not force and cached and time.monotonic() - cached[0] < _QUOTE_CACHE_SECONDS:
            return cached[1]
        payload = await _json({"function": "GLOBAL_QUOTE", "symbol": clean, "apikey": _key()})
        data = payload.get("Global Quote") if isinstance(payload.get("Global Quote"), dict) else {}
        price = _float(data.get("05. price"))
        if price is None:
            raise ValueError("قیمت این نماد دریافت نشد یا نماد پشتیبانی نمی‌شود.")
        volume_value = _float(data.get("06. volume"))
        quote = StockQuote(
            symbol=clean,
            price=price,
            open=_float(data.get("02. open")),
            high=_float(data.get("03. high")),
            low=_float(data.get("04. low")),
            previous_close=_float(data.get("08. previous close")),
            change=_float(data.get("09. change")),
            change_percent=_float(data.get("10. change percent")),
            volume=int(volume_value) if volume_value is not None else None,
            latest_trading_day=str(data.get("07. latest trading day") or ""),
            source="Alpha Vantage GLOBAL_QUOTE",
            updated_at=datetime.now(UTC),
        )
        _QUOTE_CACHE[clean] = (time.monotonic(), quote)
        return quote
