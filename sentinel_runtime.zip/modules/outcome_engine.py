from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable

from core.db import next_id
from core.utils import utc_iso
from modules.market_scope import signal_market_category

OUTCOME_OPEN = "open"
OUTCOME_FULL_WIN = "full_win"
OUTCOME_PARTIAL_WIN = "partial_win"
OUTCOME_BREAKEVEN = "breakeven"
OUTCOME_LOSS = "loss"
OUTCOME_NO_ENTRY = "no_entry"
OUTCOME_CANCELLED = "cancelled"
OUTCOME_EXPIRED = "expired"

SETTLED_OUTCOMES = {
    OUTCOME_FULL_WIN,
    OUTCOME_PARTIAL_WIN,
    OUTCOME_BREAKEVEN,
    OUTCOME_LOSS,
}
NEUTRAL_OUTCOMES = {OUTCOME_NO_ENTRY, OUTCOME_CANCELLED, OUTCOME_EXPIRED}
FINAL_SIGNAL_STATUSES = {
    "target_complete",
    "manual_close",
    "no_entry",
    "stop",
    "cancelled",
    "expired",
}


def _decimal(value: Any, default: Decimal = Decimal("0")) -> Decimal:
    try:
        result = Decimal(str(value if value is not None else default))
    except (InvalidOperation, TypeError, ValueError):
        return default
    return result if result.is_finite() else default


def _positive(value: Any) -> Decimal:
    result = _decimal(value)
    return result if result > 0 else Decimal("0")


def _levels(values: Iterable[Any] | None) -> list[Decimal]:
    return [number for number in (_positive(value) for value in values or []) if number > 0]


def _entry_value(row: dict[str, Any]) -> Decimal:
    execution = row.get("execution") if isinstance(row.get("execution"), dict) else {}
    average_fill = _positive(execution.get("average_fill_price"))
    if average_fill:
        return average_fill
    entries = _levels(row.get("entries") or [row.get("entry")])
    if not entries:
        return Decimal("0")
    side = str(row.get("side") or "").lower()
    return max(entries) if side == "buy" else min(entries)


def _target_r_values(row: dict[str, Any]) -> list[Decimal]:
    entry = _entry_value(row)
    stop = _positive(row.get("stop"))
    targets = _levels(row.get("targets"))
    side = str(row.get("side") or "").lower()
    if not entry or not stop or side not in {"buy", "sell"}:
        return []
    risk_distance = entry - stop if side == "buy" else stop - entry
    if risk_distance <= 0:
        return []
    output: list[Decimal] = []
    for target in targets:
        reward = target - entry if side == "buy" else entry - target
        output.append(max(Decimal("0"), reward / risk_distance))
    return output


def _close_plan(row: dict[str, Any], target_count: int) -> list[Decimal]:
    configured = [_positive(value) for value in row.get("partial_close_plan", [])]
    if len(configured) != target_count or sum(configured) <= 0:
        if target_count <= 0:
            return []
        equal = Decimal("100") / Decimal(target_count)
        configured = [equal for _ in range(target_count)]
    total = sum(configured)
    if total > Decimal("100"):
        configured = [(value / total) * Decimal("100") for value in configured]
    elif configured and total < Decimal("100"):
        configured[-1] += Decimal("100") - total
    return configured


def _remaining_percent(row: dict[str, Any], plan: list[Decimal], highest_target: int) -> Decimal:
    execution = row.get("execution") if isinstance(row.get("execution"), dict) else {}
    explicit_remaining = execution.get("remaining_percent")
    if explicit_remaining is not None:
        return min(Decimal("100"), max(Decimal("0"), _decimal(explicit_remaining)))
    explicit_closed = execution.get("closed_percent")
    if explicit_closed is not None:
        return min(Decimal("100"), max(Decimal("0"), Decimal("100") - _decimal(explicit_closed)))
    realized_percent = sum(plan[: max(0, highest_target)])
    for close in row.get("partial_closes", []):
        if isinstance(close, dict):
            realized_percent += _positive(close.get("percent"))
    return min(Decimal("100"), max(Decimal("0"), Decimal("100") - realized_percent))


@dataclass(frozen=True, slots=True)
class SignalOutcome:
    bucket: str
    final: bool
    settled: bool
    gross_r: float
    fee_r: float
    slippage_r: float
    net_r: float
    highest_target_hit: int
    remaining_percent: float
    method: str
    market_category: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "bucket": self.bucket,
            "final": self.final,
            "settled": self.settled,
            "gross_r": self.gross_r,
            "fee_r": self.fee_r,
            "slippage_r": self.slippage_r,
            "net_r": self.net_r,
            "highest_target_hit": self.highest_target_hit,
            "remaining_percent": self.remaining_percent,
            "method": self.method,
            "market_category": self.market_category,
        }


def calculate_signal_outcome(row: dict[str, Any]) -> SignalOutcome:
    status = str(row.get("status") or "open").lower()
    highest = max(0, int(row.get("highest_target_hit", 0) or 0))
    target_r = _target_r_values(row)
    if status == "target_complete":
        highest = max(highest, len(target_r))
    highest = min(highest, len(target_r))
    plan = _close_plan(row, len(target_r))
    remaining = _remaining_percent(row, plan, highest)
    gross_r = sum(
        (target_r[index] * plan[index] / Decimal("100") for index in range(highest)),
        Decimal("0"),
    )
    method = "calculated_from_levels"

    explicit_net = row.get("net_r")
    if explicit_net is not None and str(row.get("outcome_method") or "") == "manual":
        gross_r = _decimal(explicit_net)
        method = "manual"
    elif status == "stop":
        gross_r -= remaining / Decimal("100")
    elif status == "manual_close":
        manual_r = row.get("rr")
        if manual_r is not None:
            gross_r = _decimal(manual_r)
            method = "manual_rr"
        elif row.get("profit_percent") is not None and _decimal(row.get("risk")) > 0:
            gross_r = _decimal(row.get("profit_percent")) / _decimal(row.get("risk"))
            method = "profit_percent_over_declared_risk"
    elif status == "target_complete" and highest < len(plan):
        remaining = Decimal("0")
    elif status == "breakeven":
        remaining = Decimal("0")

    fee_r = max(Decimal("0"), _decimal(row.get("fee_r")))
    slippage_r = max(Decimal("0"), _decimal(row.get("slippage_r")))
    net_r = gross_r - fee_r - slippage_r
    final = status in FINAL_SIGNAL_STATUSES

    if status == "no_entry":
        bucket = OUTCOME_NO_ENTRY
    elif status == "cancelled":
        bucket = OUTCOME_CANCELLED
    elif status == "expired":
        bucket = OUTCOME_EXPIRED
    elif not final:
        bucket = OUTCOME_OPEN
    elif status == "target_complete" and net_r > 0:
        bucket = OUTCOME_FULL_WIN
    elif net_r > Decimal("0.0001"):
        bucket = OUTCOME_PARTIAL_WIN
    elif net_r < Decimal("-0.0001"):
        bucket = OUTCOME_LOSS
    else:
        bucket = OUTCOME_BREAKEVEN

    return SignalOutcome(
        bucket=bucket,
        final=final,
        settled=bucket in SETTLED_OUTCOMES,
        gross_r=round(float(gross_r), 6),
        fee_r=round(float(fee_r), 6),
        slippage_r=round(float(slippage_r), 6),
        net_r=round(float(net_r), 6),
        highest_target_hit=highest,
        remaining_percent=round(float(remaining), 4),
        method=method,
        market_category=signal_market_category(row),
    )


def apply_signal_outcome(row: dict[str, Any]) -> dict[str, Any]:
    outcome = calculate_signal_outcome(row)
    row["outcome"] = outcome.as_dict()
    row["outcome_bucket"] = outcome.bucket
    row["net_r"] = outcome.net_r
    row["gross_r"] = outcome.gross_r
    row["remaining_risk_percent"] = round(
        max(0.0, float(row.get("risk", 0) or 0)) * outcome.remaining_percent / 100,
        6,
    )
    return row


def record_outcome_event(
    db: dict[str, Any],
    row: dict[str, Any],
    *,
    actor_id: int | str,
    event: str,
) -> dict[str, Any]:
    apply_signal_outcome(row)
    events = db.setdefault("signal_outcome_events", [])
    previous_hash = str(events[-1].get("hash") or "") if events else ""
    payload = {
        "id": next_id(db, "signal_outcome_event"),
        "signal_id": int(row.get("id", 0) or 0),
        "actor_id": str(actor_id),
        "event": str(event or "recalculated")[:120],
        "status": str(row.get("status") or "open"),
        "outcome": dict(row.get("outcome") or {}),
        "previous_hash": previous_hash,
        "created_at": utc_iso(),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    payload["hash"] = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    events.append(payload)
    db["signal_outcome_events"] = events[-100_000:]
    row["outcome_event_id"] = payload["id"]
    row["outcome_hash"] = payload["hash"]
    return payload
