from __future__ import annotations

import hashlib
import secrets
from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso

OPEN_STATES = {"open", "acknowledged", "investigating"}
DEFAULT_INCIDENT_SETTINGS = {
    # Incidents are intentionally pull-only: operators inspect the dedicated
    # center without receiving raw technical failures in other bot screens.
    "notify_critical": False,
    "show_outside_center": False,
    "dedupe_minutes": 15,
    "auto_resolve_minutes": 30,
    "retention_days": 180,
    "escalate_after_minutes": 15,
}
RUNBOOKS = {
    "telegram_update": "شناسه پیگیری را در لاگ پیدا کنید، ورودی کاربر و Callback را بررسی و سپس Retry امن انجام دهید.",
    "signal_delivery": "دسترسی ادمین ربات در کانال، شناسه کانال و محدودیت Telegram را بررسی کنید.",
    "database": "Readiness دیتابیس، اتصال PostgreSQL/Volume و آخرین بکاپ تأییدشده را بررسی کنید.",
    "business_intelligence_job": "سلامت دیتابیس و داده‌های سیگنال را بررسی و Job را دوباره اجرا کنید.",
    "retention_delivery": "وضعیت حساب کاربر، ساعات سکوت و Rate Limit ارسال را بررسی کنید.",
}


def incident_settings(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("incident_settings", {})
    if not isinstance(settings, dict):
        settings = {}
        db["incident_settings"] = settings
    for key, value in DEFAULT_INCIDENT_SETTINGS.items():
        settings.setdefault(key, value)
    # Product policy: technical errors stay inside Incident Center.
    settings["notify_critical"] = False
    settings["show_outside_center"] = False
    return settings


def _fingerprint(source: str, kind: str, detail: str) -> str:
    raw = f"{source}|{kind}|{detail[:500]}".encode("utf-8", "ignore")
    return hashlib.sha256(raw).hexdigest()[:20]


def _correlation_id() -> str:
    return f"INC-{secrets.token_hex(5).upper()}"


def record_incident(
    db: dict[str, Any],
    *,
    source: str,
    kind: str,
    detail: str,
    severity: str = "warning",
    metadata: dict[str, Any] | None = None,
    dedupe_minutes: int | None = None,
) -> dict[str, Any]:
    rows = db.setdefault("incidents", [])
    settings = incident_settings(db)
    fingerprint = _fingerprint(source, kind, detail)
    now = datetime.now(UTC)
    dedupe = int(
        settings.get("dedupe_minutes", 15)
        if dedupe_minutes is None
        else dedupe_minutes
    )
    cutoff = now - timedelta(minutes=max(0, dedupe))
    for row in reversed(rows):
        if (
            not isinstance(row, dict)
            or row.get("fingerprint") != fingerprint
            or row.get("status") not in OPEN_STATES
        ):
            continue
        seen_at = parse_dt(row.get("last_seen_at") or row.get("created_at"))
        if seen_at and seen_at >= cutoff:
            row["count"] = int(row.get("count", 1) or 1) + 1
            row["last_seen_at"] = utc_iso(now)
            row["metadata"] = {
                **dict(row.get("metadata") or {}),
                **dict(metadata or {}),
            }
            row["healthy_since"] = None
            if severity == "critical":
                row["severity"] = "critical"
                row["notification_status"] = (
                    "pending" if settings.get("notify_critical", False) else "not_required"
                )
            return row
    normalized_severity = severity if severity in {"info", "warning", "critical"} else "warning"
    correlation_id = str((metadata or {}).get("error_ref") or _correlation_id())
    row = {
        "id": next_id(db, "incident"),
        "correlation_id": correlation_id,
        "fingerprint": fingerprint,
        "source": str(source)[:100],
        "kind": str(kind)[:100],
        "detail": str(detail)[:2000],
        "severity": normalized_severity,
        "status": "open",
        "count": 1,
        "metadata": dict(metadata or {}),
        "runbook": RUNBOOKS.get(str(source), RUNBOOKS.get(str(kind), "لاگ و وابستگی مرتبط را بررسی و پس از رفع علت، رخداد را Resolve کنید.")),
        "created_at": utc_iso(now),
        "last_seen_at": utc_iso(now),
        "acknowledged_at": None,
        "resolved_at": None,
        "healthy_since": None,
        "notification_status": (
            "pending"
            if normalized_severity == "critical" and settings.get("notify_critical", False)
            else "not_required"
        ),
        "escalation_level": 0,
        "action_history": [],
    }
    rows.append(row)
    db["incidents"] = rows[-5000:]
    return row


def add_incident_action(
    db: dict[str, Any],
    incident_id: int | str,
    *,
    actor_id: int | str,
    action: str,
    detail: str = "",
    success: bool | None = None,
) -> dict[str, Any]:
    target = str(incident_id)
    for row in db.setdefault("incidents", []):
        if isinstance(row, dict) and str(row.get("id")) == target:
            action_row = {
                "actor_id": str(actor_id),
                "action": str(action)[:100],
                "detail": str(detail)[:1000],
                "success": success,
                "created_at": utc_iso(),
            }
            row.setdefault("action_history", []).append(action_row)
            row["action_history"] = row["action_history"][-100:]
            row["updated_at"] = action_row["created_at"]
            return row
    raise ValueError("رخداد پیدا نشد")


def update_incident_status(
    db: dict[str, Any],
    incident_id: int | str,
    status: str,
    actor_id: int | str,
) -> dict[str, Any]:
    normalized = (
        status
        if status in {"acknowledged", "investigating", "resolved", "open"}
        else "open"
    )
    target = str(incident_id)
    for row in db.setdefault("incidents", []):
        if isinstance(row, dict) and str(row.get("id")) == target:
            row["status"] = normalized
            row["updated_by"] = str(actor_id)
            row["updated_at"] = utc_iso()
            if normalized == "acknowledged":
                row["acknowledged_at"] = utc_iso()
            if normalized == "resolved":
                row["resolved_at"] = utc_iso()
            add_incident_action(
                db,
                incident_id,
                actor_id=actor_id,
                action=f"status:{normalized}",
            )
            return row
    raise ValueError("رخداد پیدا نشد")


def claim_critical_notifications(
    db: dict[str, Any],
    *,
    limit: int = 20,
) -> list[dict[str, Any]]:
    if not incident_settings(db).get("notify_critical", True):
        return []
    claimed: list[dict[str, Any]] = []
    for row in db.get("incidents", []):
        if len(claimed) >= max(1, int(limit)):
            break
        if (
            not isinstance(row, dict)
            or row.get("severity") != "critical"
            or row.get("status") not in OPEN_STATES
            or row.get("notification_status") not in {"pending", "retry"}
        ):
            continue
        row["notification_status"] = "sending"
        row["notification_attempts"] = int(row.get("notification_attempts", 0) or 0) + 1
        row["notification_claimed_at"] = utc_iso()
        claimed.append(dict(row))
    return claimed


def mark_incident_notification(
    db: dict[str, Any],
    incident_id: int | str,
    *,
    success: bool,
    detail: str = "",
) -> dict[str, Any]:
    target = str(incident_id)
    for row in db.get("incidents", []):
        if isinstance(row, dict) and str(row.get("id")) == target:
            row["notification_status"] = "sent" if success else "retry"
            row["notification_error"] = None if success else str(detail)[:500]
            row["notification_sent_at"] = utc_iso() if success else row.get("notification_sent_at")
            return row
    raise ValueError("رخداد پیدا نشد")


def maintain_incidents(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
) -> dict[str, int]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    settings = incident_settings(db)
    auto_minutes = max(1, int(settings.get("auto_resolve_minutes", 30) or 30))
    escalate_minutes = max(1, int(settings.get("escalate_after_minutes", 15) or 15))
    auto_resolved = 0
    escalated = 0
    for row in db.get("incidents", []):
        if not isinstance(row, dict) or row.get("status") not in OPEN_STATES:
            continue
        last_seen = parse_dt(row.get("last_seen_at") or row.get("created_at"))
        if not last_seen:
            continue
        age_minutes = (current - last_seen).total_seconds() / 60
        if row.get("severity") != "critical" and age_minutes >= auto_minutes:
            row["status"] = "resolved"
            row["resolved_at"] = utc_iso(current)
            row["resolved_by"] = "auto_health_window"
            auto_resolved += 1
            continue
        created_at = parse_dt(row.get("created_at")) or last_seen
        open_minutes = (current - created_at).total_seconds() / 60
        desired_level = min(3, int(open_minutes // escalate_minutes))
        if desired_level > int(row.get("escalation_level", 0) or 0):
            row["escalation_level"] = desired_level
            row["escalated_at"] = utc_iso(current)
            if row.get("severity") == "critical" and settings.get("notify_critical", False):
                row["notification_status"] = "pending"
            escalated += 1

    retention_days = max(7, int(settings.get("retention_days", 180) or 180))
    cutoff = current - timedelta(days=retention_days)
    before = len(db.get("incidents", []))
    db["incidents"] = [
        row
        for row in db.get("incidents", [])
        if not isinstance(row, dict)
        or row.get("status") in OPEN_STATES
        or (parse_dt(row.get("resolved_at") or row.get("created_at")) or current) >= cutoff
    ][-5000:]
    return {
        "auto_resolved": auto_resolved,
        "escalated": escalated,
        "pruned": max(0, before - len(db["incidents"])),
    }


def incident_summary(db: dict[str, Any]) -> dict[str, Any]:
    rows = [row for row in db.get("incidents", []) if isinstance(row, dict)]
    open_rows = [row for row in rows if row.get("status") in OPEN_STATES]
    severity = Counter(str(row.get("severity") or "warning") for row in open_rows)
    source = Counter(str(row.get("source") or "unknown") for row in open_rows)
    return {
        "total": len(rows),
        "open": len(open_rows),
        "critical": severity.get("critical", 0),
        "warning": severity.get("warning", 0),
        "acknowledged": sum(
            1 for row in open_rows if row.get("status") == "acknowledged"
        ),
        "investigating": sum(
            1 for row in open_rows if row.get("status") == "investigating"
        ),
        "pending_notifications": sum(
            1
            for row in open_rows
            if row.get("notification_status") in {"pending", "retry"}
        ),
        "by_source": dict(source.most_common(10)),
        "latest": list(reversed(rows[-30:])),
    }
