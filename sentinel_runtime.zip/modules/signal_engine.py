from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from core.utils import utc_iso
from modules.market_scope import classify_market_symbol, normalize_market_category


def normalize_entries(value: str | list[str]) -> list[str]:
    raw = value if isinstance(value, list) else [part.strip() for part in str(value or "").replace("؛", ",").split(",")]
    entries: list[str] = []
    for item in raw:
        if not str(item).strip():
            continue
        try:
            number = Decimal(str(item).replace(",", "").strip())
        except InvalidOperation as exc:
            raise ValueError("قیمت ورود نامعتبر است") from exc
        if not number.is_finite() or number <= 0:
            raise ValueError("قیمت ورود باید بیشتر از صفر باشد")
        clean = format(number.normalize(), "f")
        if clean not in entries:
            entries.append(clean)
    if not 1 <= len(entries) <= 5:
        raise ValueError("بین ۱ تا ۵ نقطه ورود وارد کنید")
    return entries


def average_entry(entries: list[str]) -> str:
    if not entries:
        raise ValueError("حداقل یک نقطه ورود لازم است")
    numbers = [Decimal(item) for item in entries]
    return format((sum(numbers) / Decimal(len(numbers))).normalize(), "f")


def _partial_close_plan(target_count: int) -> list[float]:
    count = max(0, min(int(target_count), 10))
    if count == 0:
        return []
    base = Decimal(100) / Decimal(count)
    plan = [base.quantize(Decimal("0.01")) for _ in range(count)]
    difference = Decimal(100) - sum(plan)
    plan[-1] += difference
    return [float(value) for value in plan]


def _rr_targets(entry: Decimal, stop: Decimal, targets: list[Any]) -> list[float]:
    risk = abs(entry - stop)
    if risk <= 0:
        return []
    output: list[float] = []
    for target in targets:
        try:
            reward = abs(Decimal(str(target)) - entry)
        except InvalidOperation:
            continue
        output.append(round(float(reward / risk), 4))
    return output


def enrich_signal_payload(payload: dict[str, Any]) -> dict[str, Any]:
    row = dict(payload)
    if row.get("symbol"):
        row["market_category"] = normalize_market_category(
            row.get("market_category"), default=classify_market_symbol(row.get("symbol"))
        )
        from modules.prices import normalize_tracking_symbol

        row.setdefault("display_symbol", str(row.get("symbol") or "").strip())
        try:
            row["market_symbol"] = normalize_tracking_symbol(str(row.get("market_symbol") or row["display_symbol"]))
        except ValueError:
            # Keep manual-only signals usable.  The tracker explicitly marks
            # these records unsupported instead of breaking the entire cycle.
            row["market_symbol"] = ""
            row["tracking_supported"] = False
        else:
            row["tracking_supported"] = True
    source = row.get("entries") or row.get("entry")
    if source:
        entries = normalize_entries(source)
        row["entries"] = entries
        row["entry"] = average_entry(entries)
        row.setdefault("entry_mode", "single" if len(entries) == 1 else "ladder")
    else:
        entries = []
        row.setdefault("entries", [])
        row.setdefault("entry_mode", "single")

    targets = list(row.get("targets", []))
    if "partial_close_plan" not in row or len(list(row.get("partial_close_plan") or [])) != len(targets):
        row["partial_close_plan"] = _partial_close_plan(len(targets))

    if entries and row.get("stop") is not None:
        try:
            row["rr_targets"] = _rr_targets(Decimal(str(row["entry"])), Decimal(str(row["stop"])), targets)
            if row["rr_targets"]:
                row.setdefault("rr", row["rr_targets"][-1])
        except InvalidOperation:
            row.setdefault("rr_targets", [])
    else:
        row.setdefault("rr_targets", [])

    trailing = dict(row.get("trailing_stop") or {})
    trailing.setdefault("enabled", False)
    trailing.setdefault("activate_after_tp", 1)
    trailing.setdefault("distance_percent", 0.0)
    trailing.setdefault("last_price", None)
    row["trailing_stop"] = trailing
    row.setdefault("breakeven_after_tp", 1)
    row.setdefault("max_risk_percent", float(row.get("risk", 0) or 0))

    execution = dict(row.get("execution") or {})
    execution.setdefault("filled_percent", 0.0)
    execution.setdefault("filled_entries", [])
    execution.setdefault("average_fill_price", None)
    execution.setdefault("slippage_percent", 0.0)
    execution.setdefault("closed_percent", 0.0)
    row["execution"] = execution
    row.setdefault("signal_version", 2)
    row.setdefault("updated_at", utc_iso())
    return row


def update_execution(
    row: dict[str, Any],
    *,
    filled_percent: float | None = None,
    filled_entries: list[str] | None = None,
    average_fill_price: float | None = None,
    closed_percent: float | None = None,
    slippage_percent: float | None = None,
    trailing_enabled: bool | None = None,
    trailing_distance_percent: float | None = None,
    last_price: float | None = None,
) -> dict[str, Any]:
    execution = row.setdefault("execution", {})
    if filled_percent is not None:
        execution["filled_percent"] = max(0.0, min(float(filled_percent), 100.0))
    if filled_entries is not None:
        execution["filled_entries"] = list(dict.fromkeys(str(item) for item in filled_entries))
    if average_fill_price is not None:
        execution["average_fill_price"] = float(average_fill_price)
    if closed_percent is not None:
        execution["closed_percent"] = max(0.0, min(float(closed_percent), 100.0))
    if slippage_percent is not None:
        execution["slippage_percent"] = max(-100.0, min(float(slippage_percent), 100.0))
    trailing = row.setdefault("trailing_stop", {})
    if trailing_enabled is not None:
        trailing["enabled"] = bool(trailing_enabled)
    if trailing_distance_percent is not None:
        trailing["distance_percent"] = max(0.0, min(float(trailing_distance_percent), 100.0))
    if last_price is not None:
        trailing["last_price"] = float(last_price)
    row["updated_at"] = utc_iso()
    return row
