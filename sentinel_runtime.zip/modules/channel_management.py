from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from core.db import next_id
from core.utils import esc, parse_dt, utc_iso, utc_now
from modules.signal_portal import signal_display_number
from modules.outcome_engine import calculate_signal_outcome
from modules.signal_status import signal_is_final

FINAL_SIGNAL_STATUSES = {"target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}

DEFAULT_CHANNEL_MANAGEMENT: dict[str, Any] = {
    "force_join": {
        "enabled": False,
        "channel_id": 0,
        "invite_link": "",
        "title": "کانال رسمی SENTINEL",
        "channels": [],
        "require_all": True,
        "cache_seconds": 120,
        "failure_policy": "grace",
        "cache_max_entries": 20000,
        "check_concurrency": 8,
    },
    "smart_pin": {
        "enabled": True,
        "public_message_id": None,
        "private_message_id": None,
        "updated_at": None,
        "max_signals": 15,
        "show_entry": True,
        "show_stop": True,
        "show_targets": True,
        "show_profit": True,
        "show_age": True,
        "sort": "newest",
    },
    "live_status": {"enabled": True},
}


def ensure_channel_management(
    db: dict[str, Any],
    *,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> dict[str, Any]:
    settings = db.setdefault("channel_management", {})
    if not isinstance(settings, dict):
        settings = {}
        db["channel_management"] = settings
    for key, default in DEFAULT_CHANNEL_MANAGEMENT.items():
        current = settings.setdefault(key, {})
        if not isinstance(current, dict):
            current = {}
            settings[key] = current
        for field, value in default.items():
            current.setdefault(field, value)
    force_join = settings["force_join"]
    if not int(force_join.get("channel_id", 0) or 0) and public_channel_id:
        force_join["channel_id"] = int(public_channel_id)
    channels = force_join.get("channels")
    if not isinstance(channels, list):
        channels = []
        force_join["channels"] = channels
    if not channels and int(force_join.get("channel_id", 0) or 0):
        channels.append({
            "channel_id": int(force_join.get("channel_id", 0) or 0),
            "invite_link": str(force_join.get("invite_link") or ""),
            "title": str(force_join.get("title") or "کانال رسمی SENTINEL"),
            "enabled": True,
        })
    settings.setdefault("public_channel_id", int(public_channel_id or 0))
    settings.setdefault("private_channel_id", int(private_channel_id or 0))
    db.setdefault("scheduled_signals", [])
    return settings


def normalize_invite_link(value: str) -> str:
    link = str(value or "").strip()
    if not link:
        raise ValueError("لینک عضویت خالی است")
    if link.startswith("@"):
        username = link[1:]
        if not re.fullmatch(r"[A-Za-z0-9_]{5,32}", username):
            raise ValueError("نام کاربری کانال معتبر نیست")
        return f"https://t.me/{username}"
    if not re.fullmatch(r"https://t\.me/(?:\+|joinchat/)?[A-Za-z0-9_-]{5,128}", link):
        raise ValueError("لینک باید یک آدرس معتبر t.me باشد")
    return link


def required_join_channels(
    db: dict[str, Any],
    *,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> list[dict[str, Any]]:
    row = ensure_channel_management(
        db, public_channel_id=public_channel_id, private_channel_id=private_channel_id
    )["force_join"]
    output: list[dict[str, Any]] = []
    for item in row.get("channels", []):
        if not isinstance(item, dict) or not item.get("enabled", True):
            continue
        channel_id = int(item.get("channel_id", 0) or 0)
        if channel_id >= 0:
            continue
        output.append({
            "channel_id": channel_id,
            "invite_link": str(item.get("invite_link") or ""),
            "title": str(item.get("title") or f"کانال {channel_id}")[:80],
            "enabled": True,
        })
    return output


def set_force_join_channels(
    db: dict[str, Any],
    channels: list[dict[str, Any]],
    *,
    require_all: bool = True,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> dict[str, Any]:
    if len(channels) > 20:
        raise ValueError("حداکثر ۲۰ کانال عضویت اجباری مجاز است")
    normalized: list[dict[str, Any]] = []
    seen: set[int] = set()
    for item in channels:
        if not isinstance(item, dict):
            raise ValueError("ساختار کانال نامعتبر است")
        channel_id = int(item.get("channel_id", 0) or 0)
        if channel_id >= 0:
            raise ValueError("شناسه هر کانال باید یک عدد منفی تلگرام باشد")
        if channel_id in seen:
            continue
        seen.add(channel_id)
        link = normalize_invite_link(str(item.get("invite_link") or ""))
        title = str(item.get("title") or f"کانال {channel_id}").strip()[:80]
        if not title:
            raise ValueError("عنوان کانال خالی است")
        normalized.append({"channel_id": channel_id, "invite_link": link, "title": title, "enabled": bool(item.get("enabled", True))})
    settings = ensure_channel_management(
        db, public_channel_id=public_channel_id, private_channel_id=private_channel_id
    )
    row = settings["force_join"]
    row["channels"] = normalized
    row["require_all"] = bool(require_all)
    if normalized:
        row.update({
            "channel_id": normalized[0]["channel_id"],
            "invite_link": normalized[0]["invite_link"],
            "title": normalized[0]["title"],
        })
    row["updated_at"] = utc_iso()
    return row


def parse_force_join_channels(value: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in str(value or "").splitlines():
        clean = line.strip()
        if not clean:
            continue
        parts = [part.strip() for part in clean.split("|", 2)]
        if len(parts) != 3:
            raise ValueError("هر خط باید به شکل شناسه | عنوان | لینک باشد")
        try:
            channel_id = int(parts[0])
        except ValueError as exc:
            raise ValueError("شناسه کانال باید عددی باشد") from exc
        rows.append({"channel_id": channel_id, "title": parts[1], "invite_link": parts[2], "enabled": True})
    if not rows:
        raise ValueError("حداقل یک کانال وارد کنید")
    return rows


def set_force_join(
    db: dict[str, Any],
    *,
    enabled: bool | None = None,
    invite_link: str | None = None,
    channel_id: int | None = None,
    title: str | None = None,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> dict[str, Any]:
    settings = ensure_channel_management(
        db,
        public_channel_id=public_channel_id,
        private_channel_id=private_channel_id,
    )
    row = settings["force_join"]
    if enabled is not None:
        row["enabled"] = bool(enabled)
    if invite_link is not None:
        row["invite_link"] = normalize_invite_link(invite_link)
    if channel_id is not None:
        value = int(channel_id)
        if value >= 0:
            raise ValueError("شناسه کانال باید یک عدد منفی تلگرام باشد")
        row["channel_id"] = value
    if title is not None:
        clean = str(title).strip()[:80]
        if not clean:
            raise ValueError("عنوان کانال خالی است")
        row["title"] = clean
    channels = row.get("channels") if isinstance(row.get("channels"), list) else []
    if channels:
        first = channels[0]
        if channel_id is not None:
            first["channel_id"] = row["channel_id"]
        if invite_link is not None:
            first["invite_link"] = row["invite_link"]
        if title is not None:
            first["title"] = row["title"]
    elif int(row.get("channel_id", 0) or 0) < 0 and str(row.get("invite_link") or ""):
        row["channels"] = [{
            "channel_id": int(row["channel_id"]), "invite_link": str(row["invite_link"]),
            "title": str(row.get("title") or "کانال رسمی"), "enabled": True,
        }]
    row["updated_at"] = utc_iso()
    return row


def set_channel_option(
    db: dict[str, Any],
    section: str,
    field: str,
    value: Any,
    *,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> dict[str, Any]:
    settings = ensure_channel_management(
        db,
        public_channel_id=public_channel_id,
        private_channel_id=private_channel_id,
    )
    if section not in {"smart_pin", "live_status"}:
        raise ValueError("بخش تنظیمات کانال معتبر نیست")
    row = settings[section]
    row[field] = value
    row["updated_at"] = utc_iso()
    return row


def get_channel_management(
    db: dict[str, Any],
    *,
    public_channel_id: int = 0,
    private_channel_id: int = 0,
) -> dict[str, Any]:
    return ensure_channel_management(
        db,
        public_channel_id=public_channel_id,
        private_channel_id=private_channel_id,
    )


def parse_schedule_time(value: str, *, timezone: str, now: datetime | None = None) -> datetime:
    raw = str(value or "").strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789"))
    if not raw:
        raise ValueError("زمان انتشار خالی است")
    zone = ZoneInfo(timezone)
    current = (now or datetime.now(UTC)).astimezone(zone)
    parsed: datetime | None = None
    for fmt in ("%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M", "%Y-%m-%dT%H:%M"):
        try:
            parsed = datetime.strptime(raw, fmt).replace(tzinfo=zone)
            break
        except ValueError:
            continue
    if parsed is None and re.fullmatch(r"\d{1,2}:\d{2}", raw):
        hour, minute = (int(part) for part in raw.split(":"))
        if hour > 23 or minute > 59:
            raise ValueError("ساعت واردشده معتبر نیست")
        parsed = current.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if parsed <= current:
            parsed += timedelta(days=1)
    if parsed is None:
        raise ValueError("قالب زمان صحیح نیست؛ نمونه: 2026-06-27 18:30 یا 18:30")
    if parsed <= current + timedelta(seconds=20):
        raise ValueError("زمان انتشار باید در آینده باشد")
    if parsed > current + timedelta(days=365):
        raise ValueError("زمان انتشار نمی‌تواند بیشتر از یک سال آینده باشد")
    return parsed.astimezone(UTC)


def schedule_signal(
    db: dict[str, Any],
    *,
    payload: dict[str, Any],
    target: str,
    run_at: datetime | str,
    admin_id: int | str,
) -> dict[str, Any]:
    if target not in {"public", "private", "both"}:
        raise ValueError("مقصد سیگنال معتبر نیست")
    stamp = parse_dt(run_at) if not isinstance(run_at, datetime) else run_at
    if stamp is None:
        raise ValueError("زمان انتشار معتبر نیست")
    if stamp <= utc_now():
        raise ValueError("زمان انتشار باید در آینده باشد")
    row = {
        "id": next_id(db, "scheduled_signal"),
        "payload": dict(payload),
        "target": target,
        "run_at": utc_iso(stamp),
        "status": "pending",
        "admin_id": str(admin_id),
        "created_at": utc_iso(),
        "attempts": 0,
        "max_attempts": 3,
        "last_error": "",
        "signal_id": None,
    }
    db.setdefault("scheduled_signals", []).append(row)
    db["scheduled_signals"] = db["scheduled_signals"][-1000:]
    return row


def scheduled_signal_rows(db: dict[str, Any], *, include_done: bool = False) -> list[dict[str, Any]]:
    rows = [row for row in db.get("scheduled_signals", []) if isinstance(row, dict)]
    if not include_done:
        rows = [row for row in rows if row.get("status") in {"pending", "processing", "retrying", "failed"}]
    return sorted(rows, key=lambda row: str(row.get("run_at") or ""))


def due_scheduled_signals(db: dict[str, Any], *, now: datetime | None = None, limit: int = 10) -> list[dict[str, Any]]:
    current = now or utc_now()
    due: list[dict[str, Any]] = []
    for row in scheduled_signal_rows(db):
        status = str(row.get("status") or "pending")
        if status == "processing":
            lease_until = parse_dt(row.get("lease_until"))
            if lease_until and lease_until > current:
                continue
            row["status"] = "retrying"
            row["last_error"] = "مهلت پردازش تمام شد؛ بازیابی خودکار انجام شد"
            row.pop("lease_token", None)
            row.pop("lease_until", None)
            status = "retrying"
        if status == "failed":  # migration from v8.11 and older
            status = "retrying"
            row["status"] = "retrying"
        if status not in {"pending", "retrying"}:
            continue
        if int(row.get("attempts", 0) or 0) >= int(row.get("max_attempts", 3) or 3):
            row["status"] = "dead"
            row["dead_at"] = row.get("dead_at") or utc_iso(current)
            continue
        run_at = parse_dt(row.get("run_at"))
        if run_at and run_at <= current:
            due.append(row)
        if len(due) >= max(1, int(limit)):
            break
    return due


def update_scheduled_signal(
    db: dict[str, Any],
    schedule_id: int | str,
    *,
    status: str,
    signal_id: int | None = None,
    error: str = "",
) -> dict[str, Any]:
    if status not in {"pending", "processing", "retrying", "sent", "dead", "cancelled"}:
        raise ValueError("وضعیت زمان‌بندی معتبر نیست")
    target = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target:
            row["status"] = status
            row["updated_at"] = utc_iso()
            if status == "processing":
                row["attempts"] = int(row.get("attempts", 0) or 0) + 1
                row.setdefault("processing_started_at", utc_iso())
            if signal_id is not None:
                row["signal_id"] = int(signal_id)
            if error:
                row["last_error"] = str(error)[:1000]
            if status == "sent":
                row["sent_at"] = utc_iso()
                row["last_error"] = ""
                row.pop("lease_token", None)
                row.pop("lease_until", None)
                row.pop("processing_started_at", None)
            if status == "retrying":
                row["retry_at"] = row.get("run_at") or utc_iso()
                row.pop("lease_token", None)
                row.pop("lease_until", None)
                row.pop("processing_started_at", None)
            if status == "dead":
                row["dead_at"] = utc_iso()
                row.pop("lease_token", None)
                row.pop("lease_until", None)
                row.pop("processing_started_at", None)
            if status == "cancelled":
                row["cancelled_at"] = utc_iso()
                row.pop("lease_token", None)
                row.pop("lease_until", None)
            return row
    raise ValueError("زمان‌بندی پیدا نشد")


def claim_scheduled_signal(
    db: dict[str, Any],
    schedule_id: int | str,
    *,
    lease_seconds: int = 300,
) -> dict[str, Any] | None:
    import secrets

    now = utc_now()
    target = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        status = str(row.get("status") or "pending")
        lease_until = parse_dt(row.get("lease_until"))
        if status == "processing" and lease_until and lease_until > now:
            return None
        if status == "failed":
            status = "retrying"
            row["status"] = "retrying"
        if status == "retrying" and int(row.get("attempts", 0) or 0) >= int(row.get("max_attempts", 3) or 3):
            row["status"] = "dead"
            row["dead_at"] = utc_iso(now)
            return None
        if status not in {"pending", "retrying", "processing"}:
            return None
        run_at = parse_dt(row.get("run_at"))
        if run_at and run_at > now:
            return None
        token = secrets.token_urlsafe(24)
        row["status"] = "processing"
        row["attempts"] = int(row.get("attempts", 0) or 0) + 1
        row["lease_token"] = token
        row["lease_until"] = utc_iso(now + timedelta(seconds=max(60, int(lease_seconds))))
        row["processing_started_at"] = utc_iso(now)
        row["updated_at"] = utc_iso(now)
        return dict(row)
    return None


def retry_scheduled_signal(db: dict[str, Any], schedule_id: int | str, *, actor_id: int | str) -> dict[str, Any]:
    target = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        if str(row.get("status") or "") not in {"retrying", "dead", "failed", "cancelled"}:
            raise ValueError("SIGNAL_JOB_NOT_RETRYABLE")
        row.update({
            "status": "pending", "attempts": 0, "last_error": "",
            "run_at": utc_iso(utc_now() + timedelta(seconds=1)), "updated_at": utc_iso(),
            "manual_retry_by": str(actor_id), "manual_retry_at": utc_iso(),
        })
        for key in ("lease_token", "lease_until", "processing_started_at", "dead_at", "cancelled_at"):
            row.pop(key, None)
        return row
    raise ValueError("SIGNAL_JOB_NOT_FOUND")


def cancel_scheduled_signal(db: dict[str, Any], schedule_id: int | str, *, actor_id: int | str, reason: str = "") -> dict[str, Any]:
    target = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        if str(row.get("status") or "") in {"sent", "cancelled"}:
            raise ValueError("SIGNAL_JOB_NOT_CANCELLABLE")
        row = update_scheduled_signal(db, target, status="cancelled")
        row["cancelled_by"] = str(actor_id)
        row["cancel_reason"] = str(reason or "")[:500]
        return row
    raise ValueError("SIGNAL_JOB_NOT_FOUND")


def edit_scheduled_signal(
    db: dict[str, Any], schedule_id: int | str, *, actor_id: int | str,
    target: str | None = None, run_at: Any = None, payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    wanted = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != wanted:
            continue
        if str(row.get("status") or "") not in {"pending", "retrying", "failed", "dead"}:
            raise ValueError("SIGNAL_JOB_NOT_EDITABLE")
        if target is not None:
            clean_target = str(target).lower()
            if clean_target not in {"public", "private", "both"}:
                raise ValueError("INVALID_SIGNAL_TARGET")
            row["target"] = clean_target
        if run_at:
            parsed = parse_dt(run_at)
            if parsed is None or parsed <= utc_now():
                raise ValueError("INVALID_SIGNAL_RUN_AT")
            row["run_at"] = utc_iso(parsed)
        if isinstance(payload, dict) and payload:
            current = dict(row.get("payload") or {})
            current.update(payload)
            row["payload"] = current
        row["updated_at"] = utc_iso()
        row["edited_by"] = str(actor_id)
        row["edited_at"] = utc_iso()
        return row
    raise ValueError("SIGNAL_JOB_NOT_FOUND")

def renew_scheduled_signal_lease(
    db: dict[str, Any], schedule_id: int | str, lease_token: str, *, lease_seconds: int = 300
) -> bool:
    target = int(schedule_id)
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        if row.get("status") != "processing" or str(row.get("lease_token") or "") != str(lease_token):
            return False
        row["lease_until"] = utc_iso(utc_now() + timedelta(seconds=max(60, int(lease_seconds))))
        row["updated_at"] = utc_iso()
        return True
    return False


def active_signals_for_channel(db: dict[str, Any], channel: str | None = None) -> list[dict[str, Any]]:
    """Return channel signals for the board, including closed records.

    The historical name is retained for compatibility. Closed signals stay on
    the board so users can verify the final state and R result instead of seeing
    records disappear as soon as they settle.
    """
    rows: list[dict[str, Any]] = []
    for row in reversed(db.get("signals", [])):
        if not isinstance(row, dict):
            continue
        if channel in {"public", "private"}:
            delivered = row.get("delivered_channels")
            if isinstance(delivered, list):
                if channel not in delivered:
                    continue
            elif row.get("target") not in {channel, "both"}:
                continue
        rows.append(row)
    return rows


def signal_board_page(
    db: dict[str, Any],
    *,
    channel: str = "all",
    page: int = 0,
    page_size: int = 8,
) -> tuple[list[dict[str, Any]], int, int]:
    selected_channel = None if channel == "all" else channel
    if selected_channel not in {None, "public", "private"}:
        raise ValueError("فیلتر کانال معتبر نیست")
    rows = active_signals_for_channel(db, selected_channel)
    size = max(1, min(20, int(page_size)))
    total_pages = max(1, (len(rows) + size - 1) // size)
    current = max(0, min(int(page), total_pages - 1))
    start = current * size
    return rows[start : start + size], current, total_pages


def signal_age_minutes(row: dict[str, Any], *, now: datetime | None = None) -> int:
    created = parse_dt(row.get("created_at"))
    if created is None:
        return 0
    return max(0, int(((now or utc_now()) - created).total_seconds() // 60))


def smart_pin_text(db: dict[str, Any], channel: str) -> str:
    if channel not in {"public", "private"}:
        raise ValueError("کانال معتبر نیست")
    settings = ensure_channel_management(db).get("smart_pin", {})
    rows = active_signals_for_channel(db, channel)
    sort_mode = str(settings.get("sort") or "newest")
    if sort_mode == "priority":
        rows.sort(key=lambda row: (int(row.get("priority", 0) or 0), str(row.get("created_at") or "")), reverse=True)
    elif sort_mode == "oldest":
        rows.reverse()
    limit = max(1, min(int(settings.get("max_signals", 15) or 15), 30))
    title = "عمومی" if channel == "public" else "VIP"
    waiting = sum(1 for row in rows if not row.get("entry_hit_at") and str(row.get("status") or "open") == "open")
    closed = sum(1 for row in rows if signal_is_final(row))
    active = sum(
        1 for row in rows
        if not signal_is_final(row)
        and (row.get("entry_hit_at") or str(row.get("status") or "open") != "open")
    )
    lines = [
        f"📌 <b>تابلوی هوشمند سیگنال‌های {title}</b>",
        f"کل: <b>{len(rows)}</b> | در انتظار ورود: <b>{waiting}</b> | معامله فعال: <b>{active}</b> | بسته‌شده: <b>{closed}</b>",
        "",
    ]
    max_chars = max(1000, min(int(settings.get("max_chars", 3800) or 3800), 4000))
    hidden = 0
    if not rows:
        lines.append("در حال حاضر سیگنالی وجود ندارد.")
    else:
        for index, row in enumerate(rows[:limit]):
            highest = int(row.get("highest_target_hit", 0) or 0)
            status = str(row.get("status") or "open")
            is_closed = signal_is_final(row)
            if is_closed:
                outcome_row = dict(row)
                if status in {"stopped", "sl", "loss"}:
                    outcome_row["status"] = "stop"
                elif status == "win":
                    outcome_row["status"] = "target_complete"
                net_r = float(calculate_signal_outcome(outcome_row).net_r)
                if status in {"stop", "stopped", "sl", "loss"}:
                    final_label = "استاپ خورد"
                elif status in {"target_complete", "win"} or (status.startswith("tp") and highest >= len(row.get("targets", [])) > 0):
                    final_label = "فول TP شد"
                elif status == "manual_close" and highest:
                    final_label = f"روی TP{highest} بسته شد"
                elif status == "manual_close":
                    final_label = "دستی بسته شد"
                elif status == "no_entry":
                    final_label = "بدون ورود بسته شد"
                elif status == "cancelled":
                    final_label = "لغو شد"
                elif status == "expired":
                    final_label = "منقضی شد"
                else:
                    final_label = "بسته شد"
                state = f"🔒 بسته‌شده · {final_label} · {net_r:+.2f}R"
            elif highest:
                state = f"✅ TP{highest} · {float(calculate_signal_outcome(row).net_r):+.2f}R"
            elif status == "entry_hit":
                state = "📍 ورود"
            elif status == "breakeven":
                state = "🟦 ریسک‌فری"
            elif status == "partial_close":
                state = "✂️ خروج جزئی"
            else:
                state = "⏳ انتظار"
            head = (
                f"<code>#{signal_display_number(row)}</code> | <b>{esc(row.get('symbol', '-'))}</b> "
                f"{esc(str(row.get('side', '')).upper())} | {state}"
            )
            details: list[str] = []
            entries = row.get("entries") if isinstance(row.get("entries"), list) else [row.get("entry", "-")]
            if settings.get("show_entry", True):
                details.append(f"ورود: <code>{esc(' / '.join(str(item) for item in entries))}</code>")
            if settings.get("show_targets", True):
                pending_targets = list(row.get("targets", []))[highest:highest + 3]
                if pending_targets:
                    details.append(f"اهداف بعدی: <code>{esc(' / '.join(str(item) for item in pending_targets))}</code>")
            if settings.get("show_stop", True):
                details.append(f"SL: <code>{esc(row.get('stop', '-'))}</code>")
            if settings.get("show_profit", True) and row.get("profit_percent") is not None:
                details.append(f"P/L: <b>{float(row.get('profit_percent', 0) or 0):+.2f}%</b>")
            if settings.get("show_age", True):
                details.append(f"سن: {signal_age_minutes(row)}دقیقه")
            block = head + ("\n  " + " | ".join(details) if details else "")
            footer_reserve = 160
            if len("\n".join([*lines, block])) + footer_reserve > max_chars:
                hidden = len(rows) - index
                break
            lines.append(block)
        hidden = max(hidden, len(rows) - min(limit, len(rows)))
        if hidden:
            summary = f"\nو <b>{hidden}</b> سیگنال دیگر…"
            if len("\n".join([*lines, summary])) < max_chars - 100:
                lines.append(summary)
    footer = f"🔄 آخرین بروزرسانی: <b>{utc_now().strftime('%Y-%m-%d %H:%M UTC')}</b>"
    lines.extend(["", footer])
    text = "\n".join(lines)
    while len(text) > max_chars and len(lines) > 5:
        # Remove one complete signal block.  Never slice raw HTML because a
        # broken closing tag makes Telegram reject the whole pin update.
        del lines[-3]
        text = "\n".join(lines)
    if len(text) > max_chars:
        text = "\n".join(
            [
                f"📌 <b>تابلوی هوشمند سیگنال‌های {title}</b>",
                f"کل: <b>{len(rows)}</b> | در انتظار ورود: <b>{waiting}</b> | معامله فعال: <b>{active}</b> | بسته‌شده: <b>{closed}</b>",
                "",
                "جزئیات کامل به‌دلیل تعداد زیاد سیگنال‌ها در پنل ربات قابل مشاهده است.",
                "",
                footer,
            ]
        )
    return text


def live_status_text(row: dict[str, Any]) -> str:
    status = str(row.get("status") or "open")
    highest = int(row.get("highest_target_hit", 0) or 0)
    targets = list(row.get("targets", []))
    lines = [
        f"📊 <b>وضعیت زنده سیگنال #{signal_display_number(row)}</b>",
        f"نماد: <b>{esc(row.get('symbol', '-'))}</b> | {esc(str(row.get('side', '')).upper())}",
        "",
        f"{'✅' if row.get('entry_hit_at') else '⏳'} ورود: <code>{esc(row.get('entry', '-'))}</code>",
    ]
    for index, value in enumerate(targets, start=1):
        icon = "✅" if index <= highest else "⏳"
        lines.append(f"{icon} TP{index}: <code>{esc(value)}</code>")
    stop_icon = "🛑" if status == "stop" else "▫️"
    lines.append(f"{stop_icon} SL: <code>{esc(row.get('stop', '-'))}</code>")
    if row.get("breakeven_at"):
        lines.append("🟦 استاپ به نقطه ورود منتقل شده است")
    if row.get("partial_close_at"):
        lines.append("✂️ بخشی از معامله بسته شده است")
    labels = {
        "open": "در انتظار ورود",
        "entry_hit": "ورود انجام شد",
        "breakeven": "ریسک‌فری",
        "partial_close": "بستن بخشی",
        "manual_close": "بسته‌شدن دستی",
        "no_entry": "بدون ورود",
        "stop": "استاپ",
        "cancelled": "لغوشده",
        "target_complete": "تمام تارگت‌ها لمس شد",
    }
    current = labels.get(status, f"تارگت {highest}" if status.startswith("tp") else status)
    lines.extend(["", f"📌 وضعیت فعلی: <b>{esc(current)}</b>"])
    if row.get("update_note"):
        lines.append(f"📝 آخرین بروزرسانی: {esc(str(row.get('update_note'))[:300])}")
    lines.append(f"🕒 بروزرسانی: <b>{utc_now().strftime('%H:%M UTC')}</b>")
    return "\n".join(lines)
