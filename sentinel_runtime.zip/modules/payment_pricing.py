from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any

TOMAN_QUANTUM = Decimal("1")
USDT_QUANTUM = Decimal("0.000001")


def exact_decimal(value: Any, *, field: str) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f"{field.upper()}_INVALID") from exc
    if not number.is_finite():
        raise ValueError(f"{field.upper()}_INVALID")
    return number


def normalize_toman(value: Any) -> int:
    amount = exact_decimal(value, field="toman_amount")
    if amount < 0:
        raise ValueError("TOMAN_AMOUNT_NEGATIVE")
    return int(amount.quantize(TOMAN_QUANTUM, rounding=ROUND_HALF_UP))


def calculate_usdt_amount(toman_amount: Any, rate_toman: Any) -> Decimal:
    toman = Decimal(normalize_toman(toman_amount))
    rate = exact_decimal(rate_toman, field="usdt_rate")
    if rate <= 0:
        raise ValueError("USDT_RATE_UNAVAILABLE")
    return (toman / rate).quantize(USDT_QUANTUM, rounding=ROUND_HALF_UP)


def format_usdt_amount(toman_amount: Any, rate_toman: Any) -> str:
    return format(calculate_usdt_amount(toman_amount, rate_toman), ".6f")
