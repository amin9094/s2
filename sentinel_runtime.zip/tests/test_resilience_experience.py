from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from core.telegram_update_store import UpdateReplayConflict, persist
from modules.app_migrations import apply_migration, migration_status, simulate_migration
from modules.feature_flags import feature_enabled, set_feature_flag, set_feature_rollout
from modules.operations_intelligence import memory_trend_snapshot, record_memory_trend_sample, run_safe_self_healing
from modules.provider_intelligence import provider_cost_summary, rank_providers
from modules.security_sentinel import record_security_event, security_sentinel_snapshot


def test_feature_rollout_is_stable_and_bounded() -> None:
    db: dict = {}
    set_feature_flag(db, "messaging.signal_album", True, actor_id=1)
    set_feature_rollout(db, "messaging.signal_album", 25, actor_id=1)
    first = [feature_enabled(db, "messaging.signal_album", subject_id=user_id) for user_id in range(200)]
    second = [feature_enabled(db, "messaging.signal_album", subject_id=user_id) for user_id in range(200)]
    assert first == second
    assert 20 <= sum(first) <= 80


def test_memory_trend_detects_sustained_growth() -> None:
    db: dict = {}
    start = datetime(2026, 9, 27, tzinfo=UTC)
    for index, rss in enumerate((100, 200, 300, 400)):
        record_memory_trend_sample(
            db,
            {"rss_bytes": rss * 1024 * 1024, "rss_mb": rss, "percent": 10 + index},
            now=start + timedelta(hours=index),
        )
    trend = memory_trend_snapshot(db)
    assert trend["samples"] == 4
    assert trend["growth_mb_per_hour"] == pytest.approx(100.0)
    assert trend["suspected_leak"] is True


def test_recovery_budget_enters_degraded_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    import modules.operations_intelligence as oi

    monkeypatch.setenv("SELF_HEALING_MAX_RECOVERIES_PER_WINDOW", "1")
    monkeypatch.setenv("SELF_HEALING_COOLDOWN_SECONDS", "60")
    monkeypatch.setattr(oi, "memory_guardian_snapshot", lambda: {
        "state": "critical", "rss_bytes": 1000, "rss_mb": 1, "limit_bytes": 1100,
        "limit_mb": 1.1, "percent": 91, "warning_percent": 75, "critical_percent": 90,
        "generated_at": "now",
    })
    monkeypatch.setattr("core.shared_cache.trim_local_cache", lambda **_kwargs: {"removed": 1})
    db: dict = {}
    first = run_safe_self_healing(db, now=datetime(2026, 9, 27, tzinfo=UTC))
    second = run_safe_self_healing(db, now=datetime(2026, 9, 27, 0, 2, tzinfo=UTC))
    assert first["status"] == "acted"
    assert second["status"] == "degraded_budget_exhausted"


def test_security_sentinel_records_high_severity_event() -> None:
    db: dict = {}
    record_security_event("replay_conflict", severity="high", subject="42", db=db)
    snap = security_sentinel_snapshot(db)
    assert snap["state"] == "warning"
    assert snap["counts"]["high"] >= 1


def test_migration_sandbox_does_not_mutate_source() -> None:
    db: dict = {"operations": {}}
    before = repr(db)
    result = simulate_migration(db, "resilience-experience-foundation")
    assert result["sandbox"] is True
    assert repr(db) == before


def test_versioned_migration_marker_is_neutralized_without_literal_dependency() -> None:
    db = {"operations": {"app_migrations": {"applied": ["1.2.3-operations-intelligence"]}}}
    status = migration_status(db)
    assert "operations-intelligence-foundation" in status["applied"]


def test_provider_cost_is_exposed_in_rank_and_summary() -> None:
    db = {"provider_health": {"a": {"provider": "a", "status": "healthy", "requests": 2000, "cost_per_1000_requests": 0.5}}}
    ranked = rank_providers(db["provider_health"], ["a"])
    assert ranked[0]["estimated_cost"] == 1.0
    assert provider_cost_summary(db)["estimated_total_cost"] == 1.0
