from __future__ import annotations

import ast
import copy
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

from modules.ai_action_firewall import (
    HUMAN_ONLY_ACTIONS,
    bind_to_admin_intent,
    json_schema_for,
    stable_execution_key,
    validate_payload,
)
from modules.gemini_admin_control import AI_OPERATIONAL_TOOLS, sanitize_tool_calls
from modules.security_audit import append_security_audit, verify_security_audit_chain
from modules.signal_safety import create_signal_approval, resolve_signal_approval
from modules.signal_team_rules import evaluate_team_signal_gate, update_team_rules

ROOT = Path(__file__).resolve().parents[1]


def test_primary_ai_transport_accepts_canonical_financial_permissions() -> None:
    from services.actions_v2 import admin

    ctx = SimpleNamespace(transport={"source": "gemini_primary_autonomous", "ai_origin": True})
    assert admin._validate_admin_permissions_for_source(
        ctx, ["tickets", "payment_receipt_approve"]
    ) == ["tickets", "payment_receipt_approve"]
    with pytest.raises(PermissionError, match="AI_PERMISSION_GRANT_BLOCKED"):
        admin._validate_admin_permissions_for_source(ctx, ["tickets", "not_a_real_permission"])


def test_registered_commerce_tools_are_exposed_but_human_attestations_are_not() -> None:
    assert {"payment_approve", "payment_reject", "admin_vip_plan_create", "admin_vip_plan_update"} <= set(AI_OPERATIONAL_TOOLS)
    assert "partner_create" not in AI_OPERATIONAL_TOOLS
    assert not (set(AI_OPERATIONAL_TOOLS) & set(HUMAN_ONLY_ACTIONS))
    assert {
        "delegated_admin_approve", "delegated_admin_reject",
        "admin_ai_command_approve", "admin_ai_command_reject",
        "ai_signal_lab_candidate_to_review", "admin_ai_undo_restore",
    } <= set(HUMAN_ONLY_ACTIONS)


def test_prompt_injection_cannot_turn_ticket_review_into_user_ban() -> None:
    call = [{"action": "admin_user_ban", "payload": {"user_id": "123", "days": 7, "reason": "x"}}]
    with pytest.raises(PermissionError, match="AI_TOOL_NOT_EXPLICITLY_REQUESTED"):
        sanitize_tool_calls(call, admin_command="تیکت‌های امروز را خلاصه کن")
    with pytest.raises(PermissionError, match="AI_TOOL_TARGET_NOT_BOUND"):
        sanitize_tool_calls(call, admin_command="کاربر را مسدود کن")
    result = sanitize_tool_calls(call, admin_command="کاربر 123 را مسدود کن")
    assert result[0]["action"] == "admin_user_ban"


def test_action_payloads_are_closed_schema_and_typed() -> None:
    keys = AI_OPERATIONAL_TOOLS["campaign_schedule"]["keys"]
    schema = json_schema_for("campaign_schedule", keys)
    assert schema["additionalProperties"] is False
    with pytest.raises(ValueError, match="ADDITIONAL_PROPERTIES"):
        validate_payload("campaign_schedule", {"campaign_id": 1, "scheduled_for": "x", "unexpected": True}, keys)
    with pytest.raises(ValueError, match="REQUIRED_FIELDS"):
        validate_payload("campaign_schedule", {"campaign_id": 1}, keys)


def test_execution_key_is_stable_and_payload_sensitive() -> None:
    first = stable_execution_key(conversation_id=1, response_id="r", index=0, action="control_change", payload={"module": "news"})
    second = stable_execution_key(conversation_id=1, response_id="r", index=0, action="control_change", payload={"module": "news"})
    third = stable_execution_key(conversation_id=1, response_id="r", index=0, action="control_change", payload={"module": "signals"})
    assert first == second and first != third


def test_security_audit_chain_detects_tampering() -> None:
    db: dict = {}
    append_security_audit(db, action="one", actor_id=1, details={"x": 1})
    append_security_audit(db, action="two", actor_id=1, details={"x": 2})
    assert verify_security_audit_chain(db["security_audit_log"])["valid"] is True
    tampered = copy.deepcopy(db["security_audit_log"])
    tampered[0]["details"]["x"] = 99
    assert verify_security_audit_chain(tampered)["valid"] is False


def test_ai_signal_requires_human_confirmation_of_entry_stop_and_targets() -> None:
    db: dict = {}
    row = create_signal_approval(
        db,
        payload={"symbol": "XAUUSD", "side": "BUY", "entry": "2400", "stop": "2390", "targets": ["2420"]},
        target="public", requested_by=1, source="gemini_ai_signal_draft",
        review_requirements=["entry", "stop", "targets"],
    )
    approved = resolve_signal_approval(db, row["id"], 354678485, approve=True)
    assert approved["human_confirmation"] is True
    assert approved["confirmed_fields"] == ["entry", "stop", "targets"]


def test_team_signal_gate_never_blocks_admin_publication_from_legacy_limits() -> None:
    now = datetime(2026, 7, 28, 12, 0, tzinfo=UTC)
    db: dict = {"signals": [], "signal_archive": []}
    rules = update_team_rules(db, 1, {
        "timezone": "UTC", "max_daily_signals": 2, "max_weekly_signals": 20,
        "max_daily_forex": 2, "max_daily_crypto": 2,
        "max_consecutive_stops": 2, "cooldown_minutes": 180,
        "max_daily_loss_r": 2, "minimum_rr": 2,
    })
    for index in range(2):
        stamp = (now - timedelta(minutes=20 - index)).isoformat()
        db["signals"].append({
            "id": index + 1, "symbol": "XAUUSD", "market_category": "forex",
            "created_at": stamp, "result_at": stamp, "status": "stop", "result_r": -1,
        })
    gate = evaluate_team_signal_gate(db, {"symbol": "EURUSD", "market_category": "forex"}, now=now)
    assert gate.ok is True
    assert gate.errors == () and gate.warnings == ()
    assert gate.metrics["enforcement"] == "disabled_for_admin_signal_publication"
    assert rules["max_daily_signals"] == 0
    assert rules["max_weekly_signals"] == 0
    assert rules["max_consecutive_stops"] == 0
    assert rules["max_daily_loss_r"] == 0.0


def test_catalog_actions_are_registered_and_handler_payload_keys_match() -> None:
    from services.actions_v2 import action_specs

    assert set(AI_OPERATIONAL_TOOLS) <= set(action_specs())
    handlers: dict[str, tuple[Path, ast.AST]] = {}
    for path in (ROOT / "services" / "actions_v2").glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in tree.body:
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Name) and decorator.func.id == "action" and decorator.args and isinstance(decorator.args[0], ast.Constant):
                    handlers[str(decorator.args[0].value)] = (path, node)
    for action_name, tool in AI_OPERATIONAL_TOOLS.items():
        path, node = handlers[action_name]
        used: set[str] = set()
        for child in ast.walk(node):
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and child.func.attr == "get" and isinstance(child.func.value, ast.Attribute) and child.func.value.attr == "payload" and child.args and isinstance(child.args[0], ast.Constant):
                used.add(str(child.args[0].value))
            if isinstance(child, ast.Subscript) and isinstance(child.value, ast.Attribute) and child.value.attr == "payload" and isinstance(child.slice, ast.Constant):
                used.add(str(child.slice.value))
        assert used <= set(tool["keys"]), f"{action_name} mismatch in {path}"
        assert json_schema_for(action_name, list(tool["keys"]))["additionalProperties"] is False


def test_primary_admin_has_no_numeric_fallback_in_application_source() -> None:
    source = (ROOT / "config.py").read_text(encoding="utf-8")
    assert 'PRIMARY_ADMIN_ID", admin_ids[0] if admin_ids else 0' in source
    assert "354678485" not in source
