from __future__ import annotations

from repositories.v2.journal import JournalRepository
from services import unified_journal_service as unified
from services import miniapp_read_service_v2 as read


def _legacy_signal(*, external_id: str = "jnl-canonical") -> dict:
    return {
        "id": 11,
        "user_id": "77",
        "signal_id": 501,
        "symbol": "XAUUSD",
        "side": "BUY",
        "status": "closed",
        "entry_price": 2400,
        "exit_price": 2420,
        "volume": 1,
        "pnl_amount": 100,
        "pnl_percent": 1,
        "result_r": 2,
        "source": "channel_signal",
        "entry_reason_type": "channel_signal",
        "entry_reason": "SENTINEL signal #501",
        "external_id": external_id,
        "created_at": "2026-01-01T00:00:00+00:00",
        "closed_at": "2026-01-01T01:00:00+00:00",
    }


def test_sync_archives_synthetic_duplicate_for_mirrored_signal(sqlite_engine, monkeypatch) -> None:
    repo = JournalRepository(sqlite_engine)
    canonical = repo.add(77, {
        "id": "jnl-canonical",
        "position_id": "pos-signal-501",
        "signal_id": "501",
        "symbol": "XAUUSD",
        "side": "BUY",
        "status": "open",
        "volume": 1,
        "source": "channel_signal",
        "entry_reason_type": "channel_signal",
    })
    duplicate = repo.add(77, {
        "id": "legacy-77-11",
        "signal_id": "501",
        "symbol": "XAUUSD",
        "side": "BUY",
        "status": "open",
        "volume": 1,
        "source": "channel_signal",
        "entry_reason_type": "channel_signal",
    })
    legacy = _legacy_signal()

    monkeypatch.setattr(unified, "JournalRepository", lambda: repo)
    monkeypatch.setattr(unified, "with_db_read", lambda fn: [dict(legacy)])

    assert unified.sync_legacy_journal_to_normalized(77) == 1

    refreshed = repo.get(77, canonical["id"])
    archived = repo.get(77, duplicate["id"])
    assert refreshed["status"] == "closed"
    assert refreshed["pnl_amount"] == 100
    assert refreshed["legacy_journal_id"] == 11
    assert archived["status"] == "archived"
    assert [row["id"] for row in repo.list_for_user(77, limit=20)["items"]] == [canonical["id"]]
    stats = read._journal_stats(sqlite_engine, 77)
    assert stats["total"] == 1
    assert stats["closed"] == 1
    assert stats["wins"] == 1
    assert stats["net_pnl"] == 100


def test_sync_is_idempotent_and_never_recreates_duplicate(sqlite_engine, monkeypatch) -> None:
    repo = JournalRepository(sqlite_engine)
    repo.add(77, {
        "id": "jnl-canonical", "position_id": "pos-signal-501", "signal_id": "501",
        "symbol": "XAUUSD", "side": "BUY", "status": "open", "volume": 1,
        "source": "channel_signal", "entry_reason_type": "channel_signal",
    })
    legacy = _legacy_signal()
    monkeypatch.setattr(unified, "JournalRepository", lambda: repo)
    monkeypatch.setattr(unified, "with_db_read", lambda fn: [dict(legacy)])

    unified.sync_legacy_journal_to_normalized(77)
    unified.sync_legacy_journal_to_normalized(77)

    active = repo.list_for_user(77, limit=20)["items"]
    assert len(active) == 1
    assert active[0]["id"] == "jnl-canonical"


def test_mirror_reuses_existing_legacy_signal_record(monkeypatch) -> None:
    legacy = _legacy_signal(external_id="")
    legacy["status"] = "open"
    db = {"trade_journal": {"77": [legacy]}, "operations": {}, "counters": {}}
    monkeypatch.setattr(unified, "with_db", lambda fn: fn(db))

    result = unified.mirror_normalized_journal_create(77, {
        "id": "jnl-normalized",
        "signal_id": 501,
        "symbol": "XAUUSD",
        "side": "BUY",
        "status": "open",
        "volume": 1,
        "source": "channel_signal",
    })

    assert len(db["trade_journal"]["77"]) == 1
    assert result["id"] == "jnl-normalized"
    assert result.get("legacy_journal_id") is None


def test_legacy_journal_screen_and_stats_hide_duplicate_signal() -> None:
    from modules.portfolio import journal_entries, journal_stats, reconcile_signal_journal_duplicates

    first = _legacy_signal(external_id="")
    second = {**_legacy_signal(external_id="jnl-normalized"), "id": 12, "status": "closed", "pnl_amount": 100, "pnl_percent": 1}
    db = {"trade_journal": {"77": [first, second]}, "operations": {}, "counters": {}}

    visible = journal_entries(db, 77, limit=50)
    assert len(visible) == 1
    stats = journal_stats(db, 77)
    assert stats["total"] == 1
    assert stats["wins"] == 1

    assert reconcile_signal_journal_duplicates(db, 77) == 1
    active = [row for row in db["trade_journal"]["77"] if row.get("status") != "archived"]
    assert len(active) == 1
    assert active[0]["external_id"] == "jnl-normalized"
    assert active[0]["pnl_amount"] == 100
