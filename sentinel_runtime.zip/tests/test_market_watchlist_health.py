from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

import pytest

from modules.market_scope import classify_market_symbol, normalize_market_category, signal_market_category
from modules.portfolio import (
    calculate_r_multiple,
    clear_watchlist,
    normalize_journal_reason,
    remove_watchlist_symbol,
    set_watchlist_alerts,
    toggle_watchlist_symbol,
    watchlist_for_user,
)
from modules.prices import MarketQuote, _quote_from_dict, normalize_market_symbol, normalize_tracking_symbol
from services import live_market_service


@pytest.mark.parametrize(
    ("symbol", "expected"),
    [
        ("BTC/USDT", "crypto"),
        ("XRPUSD", "crypto"),
        ("DOGE-USDT", "crypto"),
        ("EURUSD", "forex"),
        ("XAUUSD.pro", "forex"),
        ("US100", "forex"),
        ("", "forex"),
    ],
)
def test_market_classification(symbol: str, expected: str) -> None:
    assert classify_market_symbol(symbol) == expected


def test_market_category_alias_and_signal_fallback() -> None:
    assert normalize_market_category("fx") == "forex"
    assert normalize_market_category("cryptocurrency") == "crypto"
    assert signal_market_category({"symbol": "SOLUSDT"}) == "crypto"
    assert signal_market_category({"market_category": "forex", "symbol": "BTCUSD"}) == "forex"


def test_market_quote_serialization_and_age() -> None:
    quote = MarketQuote(
        symbol="XAUUSD",
        title="Gold",
        price=2400.5,
        source="test",
        updated_at=datetime.now(UTC) - timedelta(seconds=12),
        confidence=1.5,
        provider_count=0,
        dispersion_bps=-1,
    )
    payload = quote.as_dict()
    assert payload["price"] == 2400.5
    assert payload["age_seconds"] >= 11
    assert payload["confidence"] == 1.0
    assert payload["provider_count"] == 1
    assert payload["dispersion_bps"] == 0.0
    assert _quote_from_dict(payload) is not None
    assert _quote_from_dict({"updated_at": "broken"}) is None


def test_symbol_normalization_for_tracker_aliases() -> None:
    assert normalize_market_symbol("BTC/USDT") == "BTCUSD"
    assert normalize_tracking_symbol("BINANCE:BTC/USDT") == "BTCUSD"
    assert normalize_tracking_symbol("XAUUSD.pro") == "XAUUSD"
    assert normalize_tracking_symbol("EURUSDm") == "EURUSD"


def test_watchlist_full_lifecycle() -> None:
    db: dict = {}
    added, row = toggle_watchlist_symbol(db, 10, "btc/usdt")
    assert added and row and row["symbol"] == "BTCUSD"
    assert watchlist_for_user(db, 10)[0]["alerts_enabled"] is True
    updated = set_watchlist_alerts(db, 10, "BTCUSD", False)
    assert updated["alerts_enabled"] is False
    assert remove_watchlist_symbol(db, 10, "BTCUSD") is True
    assert remove_watchlist_symbol(db, 10, "BTCUSD") is False
    toggle_watchlist_symbol(db, 10, "XAUUSD")
    toggle_watchlist_symbol(db, 10, "EURUSD")
    assert clear_watchlist(db, 10) == 2
    assert watchlist_for_user(db, 10) == []


def test_watchlist_guards() -> None:
    with pytest.raises(ValueError, match="INVALID_SYMBOL"):
        toggle_watchlist_symbol({}, 1, "?")
    with pytest.raises(ValueError, match="WATCHLIST_ITEM_NOT_FOUND"):
        set_watchlist_alerts({}, 1, "XAUUSD", True)
    db = {}
    from modules.admin_control_center import module_state
    module_state(db, "watchlists")["max_assets"] = 1
    toggle_watchlist_symbol(db, 1, "XAUUSD")
    with pytest.raises(ValueError, match="WATCHLIST_LIMIT_REACHED"):
        toggle_watchlist_symbol(db, 1, "EURUSD")


def test_journal_math_and_reason_normalization() -> None:
    assert calculate_r_multiple("BUY", 100, 90, 120) == 2.0
    assert calculate_r_multiple("SELL", 100, 110, 80) == 2.0
    assert calculate_r_multiple("BUY", 100, 100, 120) is None
    assert calculate_r_multiple("BUY", None, 90, 120) is None
    assert normalize_journal_reason("", "", signal_id=7) == ("channel_signal", "سیگنال کانال #7")
    assert normalize_journal_reason("invalid", "custom") == ("other", "custom")


class _Quote:
    def __init__(self, symbol: str, price: float = 1.0, *, stale: bool = False) -> None:
        self.symbol = symbol
        self.price = price
        self.stale = stale

    def as_dict(self):
        return {
            "symbol": self.symbol,
            "title": self.symbol,
            "price": self.price,
            "source": "provider-a",
            "updated_at": datetime.now(UTC).isoformat(),
            "fetched_at": datetime.now(UTC).isoformat(),
            "age_seconds": 1.5,
            "stale": self.stale,
            "delayed": False,
            "confidence": 0.91,
            "provider_count": 2,
        }


@pytest.mark.asyncio
async def test_live_market_fetch_is_resilient_and_enriches_watchlist(monkeypatch) -> None:
    monkeypatch.setattr(live_market_service, "_watchlist", lambda _uid: [{"symbol": "XRPUSD", "alerts_enabled": True}])

    async def quote(symbol: str, *, force: bool = False):
        if symbol == "GBPUSD":
            raise RuntimeError("provider down")
        return _Quote(symbol, 2.5 if symbol == "XRPUSD" else 1.1)

    class IranItem:
        symbol = "dollar"
        title = "Dollar"
        price = 60000
        unit = "toman"
        change_percent = 1.2
        source = "iran-provider"
        estimated = False
        updated_at = datetime.now(UTC).isoformat()

    async def iran(*, force: bool = False):
        return SimpleNamespace(all_quotes=[IranItem()], stale=False)

    monkeypatch.setattr(live_market_service, "fetch_market_quote", quote)
    monkeypatch.setattr(live_market_service, "fetch_iran_market_snapshot", iran)
    monkeypatch.setattr(live_market_service, "read_db_sections", lambda _sections: {})
    monkeypatch.setattr(live_market_service, "market_regime_dashboard", lambda _db: {"current": {"regime": "balanced"}})

    result = await live_market_service._fetch(12, force=True)
    assert any(row["symbol"] == "XRPUSD" and row["category"] == "crypto" for row in result["quotes"])
    assert any(row["symbol"] == "GBPUSD" for row in result["failed_quotes"])
    assert result["watchlist"][0]["quote_available"] is True
    assert result["watchlist"][0]["quote"]["price"] == 2.5
    assert result["iran_quotes"][0]["symbol"] == "dollar"
    assert result["live"] is True


@pytest.mark.asyncio
async def test_live_market_rejects_invalid_prices(monkeypatch) -> None:
    monkeypatch.setattr(live_market_service, "_watchlist", lambda _uid: [])

    async def quote(symbol: str, *, force: bool = False):
        return _Quote(symbol, 0)

    async def iran(*, force: bool = False):
        raise RuntimeError("iran unavailable")

    monkeypatch.setattr(live_market_service, "fetch_market_quote", quote)
    monkeypatch.setattr(live_market_service, "fetch_iran_market_snapshot", iran)
    monkeypatch.setattr(live_market_service, "read_db_sections", lambda _sections: {})
    monkeypatch.setattr(live_market_service, "market_regime_dashboard", lambda _db: {})
    result = await live_market_service._fetch(1)
    assert not result["quotes"]
    assert len(result["failed_quotes"]) == len(live_market_service._DEFAULT_SYMBOLS)
    assert result["iran_error"] == "iran unavailable"


@pytest.mark.asyncio
async def test_fetch_symbols_deduplicates_and_bounds(monkeypatch) -> None:
    calls: list[str] = []

    async def quote(symbol: str, *, force: bool = False):
        calls.append(symbol)
        return _Quote(symbol, 10)

    monkeypatch.setattr(live_market_service, "fetch_market_quote", quote)
    values = ["BTC/USDT", "BTCUSD", *[f"AAA{i}USD" for i in range(60)]]
    result = await live_market_service._fetch_symbols(values)
    assert calls.count("BTCUSD") == 1
    assert len(result) <= 40
