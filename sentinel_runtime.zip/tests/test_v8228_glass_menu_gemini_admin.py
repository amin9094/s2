from __future__ import annotations

import inspect
from pathlib import Path

import pytest

from bot_runtime import navigation
from bot_runtime import account_support
from modules.ai_action_firewall import action_family, bind_to_admin_intent, json_schema_for
from modules.gemini_admin_control import AI_OPERATIONAL_TOOLS
from services.actions_v2.registry import action_specs


def _flatten(rows):
    return [button for row in rows for button in row]


def test_mission_is_neutral_and_user_deck_has_language_not_gemini(monkeypatch):
    monkeypatch.setattr(navigation, "load_db", lambda: {"users": {}})
    monkeypatch.setattr(navigation, "is_vip", lambda db, uid: False)
    monkeypatch.setattr(navigation, "_language_for_user", lambda uid: "fa")
    monkeypatch.setattr(navigation, "_is_any_admin", lambda uid: True)
    monkeypatch.setattr(navigation, "_is_owner_admin", lambda uid: True)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *args: False)
    monkeypatch.setattr(navigation, "with_webapp", lambda rows: rows)
    buttons = _flatten(navigation.main_menu(7))
    mission = next(button for button in buttons if button.callback_data == "u_missions")
    assert 'mission_label = "🧭 مأموریت"' in inspect.getsource(navigation.main_menu)
    assert getattr(mission, "style", None) is None
    assert any(button.callback_data == "language_menu" for button in buttons)
    assert not any(button.callback_data in {"a_ai_chat_start", "u_ai_chat_start"} for button in buttons)


def test_normal_user_has_no_gemini_entry(monkeypatch):
    monkeypatch.setattr(navigation, "load_db", lambda: {"users": {}})
    monkeypatch.setattr(navigation, "is_vip", lambda db, uid: False)
    monkeypatch.setattr(navigation, "_language_for_user", lambda uid: "fa")
    monkeypatch.setattr(navigation, "_is_any_admin", lambda uid: False)
    monkeypatch.setattr(navigation, "_is_owner_admin", lambda uid: False)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *args: False)
    monkeypatch.setattr(navigation, "with_webapp", lambda rows: rows)
    buttons = _flatten(navigation.main_menu(8))
    assert any(button.callback_data == "language_menu" for button in buttons)
    assert not any(button.callback_data in {"a_ai_chat_start", "u_ai_chat_start"} for button in buttons)


def test_owner_admin_menu_has_direct_gemini_button(monkeypatch):
    monkeypatch.setattr(navigation, "_admin_granted_permissions", lambda uid: set())
    monkeypatch.setattr(navigation, "_admin_counts", lambda: {})
    monkeypatch.setattr(navigation, "load_db", lambda: {})
    monkeypatch.setattr(navigation, "admin_ui_mode", lambda db, uid: "basic")
    monkeypatch.setattr(navigation, "_is_owner_admin", lambda uid: True)
    rows = navigation.admin_menu(7)
    assert any(button.callback_data == "a_ai_chat_start" for button in _flatten(rows))


def test_removed_combined_challenge_hub_and_direct_home_routes():
    challenge_source = inspect.getsource(account_support.u_challenges)
    missions_source = inspect.getsource(account_support.u_missions)
    contests_source = inspect.getsource(account_support.u_contests)
    assert "مسابقه‌ها و مأموریت‌ها" not in challenge_source
    assert "u_challenges" not in missions_source
    assert 'callback_data="home"' in missions_source
    assert "u_challenges" not in contests_source
    assert 'callback_data="home"' in contests_source


def test_idea_tool_is_registered_and_bound_to_idea_intent():
    assert "ai_idea_create" in AI_OPERATIONAL_TOOLS
    assert "ai_idea_create" in action_specs()
    schema = json_schema_for("ai_idea_create", AI_OPERATIONAL_TOOLS["ai_idea_create"]["keys"])
    assert set(schema["required"]) == {"title", "description"}
    assert action_family("ai_idea_create") == "idea"
    bind_to_admin_intent("ai_idea_create", {"title": "رشد ربات", "description": "ایده آزمایشی"}, "یک ایده جدید برای رشد ربات ثبت کن")
    with pytest.raises(PermissionError):
        bind_to_admin_intent("ai_idea_create", {"title": "نامرتبط", "description": "نامرتبط"}, "تیکت شماره ۱۲ را ببند")


def test_vivid_glass_assets_and_version():
    css = Path("webapp/src/styles.css").read_text(encoding="utf-8")
    assert "SENTINEL v8.30.0 — resilience experience visual pass" in css
    assert "backdrop-filter:blur(19px)" in css
    assert "#ffd95a" in css and "#e9ae22" in css
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "8.30.0"
