from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_modified_python_sources_parse() -> None:
    for path in (
        "ui/button_factory.py",
        "bot_runtime/navigation.py",
        "bot_runtime/runtime_jobs.py",
        "services/actions_v2/admin.py",
        "services/miniapp_action_service_v2.py",
        "services/miniapp_read_service_v2.py",
        "core/miniapp_server.py",
    ):
        ast.parse(text(path), filename=path)


def test_back_is_canonical_and_routes_to_parent_without_replay() -> None:
    navigation = text("bot_runtime/navigation.py")
    factory = text("ui/button_factory.py")
    routes = text("handlers/callback_routes.py")
    runtime = text("bot_runtime/runtime_jobs.py")

    assert '_NAVIGATION_TARGET_PREFIX = "nb:"' in navigation
    assert "callback_data=callback" in navigation
    assert "_dispatch_back_target" in navigation
    assert "candidate is navigation_back" in navigation
    assert "database writes that already succeeded are never reversed" in navigation
    assert "_is_state_mutation_callback" in navigation
    assert '"toggle", "perm", "set", "save", "update"' in navigation
    assert '_BACK_TARGET_PREFIX = "nb:"' in factory
    assert "_encoded_back_callback(callback_data)" in factory
    assert '"⬅️ برگشت"' in factory
    assert "(?:nav_back|nb:.+)" in routes
    assert "CallbackQueryHandler(capture_navigation_screen), group=-8" in runtime
    assert 'CallbackQueryHandler(navigation_back, pattern=r"^(?:nav_back|nb:.+)$")' in runtime


def test_miniapp_admin_parity_backend_contract() -> None:
    actions = text("services/actions_v2/admin.py")
    reads = text("services/miniapp_read_service_v2.py")
    server = text("core/miniapp_server.py")
    events = text("services/miniapp_action_service_v2.py")

    for action_name in (
        "admin_user_ban",
        "admin_user_unban",
        "delegated_admin_upsert",
        "delegated_admin_permissions_set",
        "delegated_admin_remove",
        "signal_edit",
        "signal_result_set",
        "signal_result_reset",
        "signal_delete",
    ):
        assert f'@action("{action_name}"' in actions

    for function_name in (
        "admin_users",
        "admin_user",
        "admin_delegated_admins",
        "admin_signals",
        "admin_signal",
    ):
        assert f"def {function_name}(" in reads

    for route in (
        "/api/v1/admin/users",
        "/api/v1/admin/admins",
        "/api/v1/admin/signals",
    ):
        assert route in server

    assert 'action in {"signal_edit", "signal_result_set", "signal_result_reset"}' in server
    assert 'action == "signal_delete"' in server
    assert '"signal_edit": "signal.revised"' in events
    assert '"admin_user_ban": "admin.user_updated"' in events
    assert '"delegated_admin_upsert": "admin.access_updated"' in events


def test_miniapp_admin_parity_frontend_contract() -> None:
    core = text("webapp/src/core.js")
    admin = text("webapp/src/admin-parity.js")
    shell = text("webapp/src/shell-events.js")
    experience = text("webapp/src/experience-v2.js")

    for resource in ("adminUsers", "adminAdmins", "adminSignals"):
        assert f"{resource}:" in core
    for function_name in (
        "adminUsersCenter",
        "adminAdminsCenter",
        "adminSignalsCenter",
        "adminSignalEditModal",
        "adminSignalResultModal",
    ):
        assert f"function {function_name}(" in admin or f"async function {function_name}(" in admin
    assert "admin.user_updated" in shell
    assert "admin.access_updated" in shell
    assert "signal.deleted" in shell
    assert "admin-signals" in experience
    assert "admin-users" in experience
    assert "admin-admins" in experience


def test_release_version_bumped() -> None:
    assert text("VERSION").strip() == "8.30.0"
