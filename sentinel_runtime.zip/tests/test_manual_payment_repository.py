from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from core.storage.engine import DatabaseEngine
from repositories.v2.commerce import CommerceRepository


def repo_for(tmp_path: Path) -> CommerceRepository:
    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "db.sqlite3")
    engine.ensure_schema()
    return CommerceRepository(engine)


def receipt(repo: CommerceRepository, user_id: str, suffix: str = "1") -> dict:
    return repo.create_receipt(user_id, {
        "id": f"R-{suffix}",
        "receipt_id": f"R-{suffix}",
        "checksum": (suffix[-1] if suffix[-1] in "0123456789abcdef" else "a") * 64,
        "object_key": f"receipt-{suffix}.webp",
        "storage_backend": "local",
        "mime_type": "image/webp",
        "size_bytes": 123,
    })


def quote(repo: CommerceRepository, user_id: str, *, method="card", payable=1000, quote_id="Q-1", **extra) -> dict:
    return repo.create_quote(user_id, {
        "quote_id": quote_id,
        "plan_id": "1",
        "plan_name": "VIP",
        "duration_days": 30,
        "base_price": extra.pop("base_price", payable),
        "discount_amount": extra.pop("discount_amount", 0),
        "coupon": extra.pop("coupon", ""),
        "payable_toman": payable,
        "payment_method": method,
        "expires_at": "2999-01-01T00:00:00+00:00",
        **extra,
    })


@pytest.mark.parametrize("method", ["card", "usdt"])
def test_paid_orders_require_receipt_even_when_txid_exists(tmp_path, method):
    repo = repo_for(tmp_path)
    q = quote(repo, "10", method=method)
    with pytest.raises(ValueError, match="RECEIPT_REQUIRED"):
        repo.submit_order_from_quote("10", quote_id=q["quote_id"], transaction_hash="abc")


@pytest.mark.parametrize("method", ["card", "usdt"])
def test_receipt_creates_pending_manual_order(tmp_path, method):
    repo = repo_for(tmp_path)
    r = receipt(repo, "10")
    q = quote(repo, "10", method=method)
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    assert order["status"] == "pending"
    assert order["manual_review_required"] is True
    assert order["verification_status"] == "manual_review"
    assert order["receipt_attached"] is True
    assert order["transaction_hash"] is None


def test_txid_is_optional_but_deduplicated_when_supplied(tmp_path):
    repo = repo_for(tmp_path)
    r1, r2 = receipt(repo, "10", "a"), receipt(repo, "11", "b")
    q1, q2 = quote(repo, "10", method="usdt", quote_id="Q-1"), quote(repo, "11", method="usdt", quote_id="Q-2")
    repo.submit_order_from_quote("10", quote_id=q1["quote_id"], receipt_id=r1["id"], transaction_hash="optional-tx")
    with pytest.raises(ValueError, match="TRANSACTION_HASH_ALREADY_USED"):
        repo.submit_order_from_quote("11", quote_id=q2["quote_id"], receipt_id=r2["id"], transaction_hash="optional-tx")


@pytest.mark.parametrize(
    "base,discount,coupon,valid",
    [(0, 0, "", True), (1000, 1000, "FULL", True), (1000, 999, "FULL", False), (1000, 1000, "", False)],
)
def test_zero_value_order_stays_pending_and_is_validated(tmp_path, base, discount, coupon, valid):
    repo = repo_for(tmp_path)
    q = quote(repo, "10", payable=0, base_price=base, discount_amount=discount, coupon=coupon)
    if valid:
        order = repo.submit_order_from_quote("10", quote_id=q["quote_id"])
        assert order["status"] == "pending"
        assert repo.entitlement_for_user("10") is None
    else:
        with pytest.raises(ValueError, match="ZERO_VALUE_ORDER_INVALID"):
            repo.submit_order_from_quote("10", quote_id=q["quote_id"])


def test_quote_and_receipt_are_single_use(tmp_path):
    repo = repo_for(tmp_path)
    r = receipt(repo, "10")
    q = quote(repo, "10")
    repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    with pytest.raises(ValueError, match="CHECKOUT_QUOTE_EXPIRED"):
        repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])


def test_approval_requires_claim_and_valid_invite(tmp_path):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    with pytest.raises(ValueError, match="APPROVAL_ORCHESTRATION_REQUIRED"):
        repo.approve_order(order["id"], actor_id="1")
    claimed = repo.claim_order_for_approval(order["id"], actor_id="1")
    assert claimed["status"] == "approving"
    with pytest.raises(ValueError, match="INVITE_LINK_INVALID"):
        repo.finalize_order_approval(order["id"], actor_id="1", invite_link="not-a-link")
    approved = repo.finalize_order_approval(order["id"], actor_id="1", invite_link="https://t.me/+safe")
    assert approved["status"] == "approved"
    assert approved["invite_link"] == "https://t.me/+safe"
    assert repo.entitlement_for_user("10")["active"] is True


def test_approved_order_cannot_be_rejected_or_cancelled(tmp_path):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    repo.claim_order_for_approval(order["id"], actor_id="1")
    repo.finalize_order_approval(order["id"], actor_id="1", invite_link="https://t.me/+safe")
    with pytest.raises(ValueError, match="ORDER_NOT_PENDING"):
        repo.reject_order(order["id"], actor_id="1", reason="invalid receipt")
    with pytest.raises(ValueError, match="ORDER_CANNOT_BE_CANCELLED"):
        repo.update_status(order["id"], status="cancelled", actor_id="10")


def test_rejected_order_can_only_return_via_resubmit_with_new_receipt(tmp_path):
    repo = repo_for(tmp_path)
    r1, q = receipt(repo, "10", "a"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r1["id"])
    rejected = repo.reject_order(order["id"], actor_id="1", reason="receipt unreadable")
    assert rejected["status"] == "rejected"
    with pytest.raises(ValueError, match="RECEIPT_REQUIRED"):
        repo.resubmit_order("10", order["id"], receipt_id="")
    r2 = receipt(repo, "10", "b")
    pending = repo.resubmit_order("10", order["id"], receipt_id=r2["id"])
    assert pending["status"] == "pending"
    assert pending["receipt_id"] == r2["id"]


def test_claim_is_idempotent_for_same_admin_and_exclusive_for_others(tmp_path):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    first = repo.claim_order_for_approval(order["id"], actor_id="1")
    second = repo.claim_order_for_approval(order["id"], actor_id="1")
    assert first["processing_by"] == second["processing_by"] == "1"
    with pytest.raises(ValueError, match="ORDER_NOT_PENDING"):
        repo.claim_order_for_approval(order["id"], actor_id="2")


def test_failed_approval_can_release_back_to_pending(tmp_path):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    repo.claim_order_for_approval(order["id"], actor_id="1")
    released = repo.release_order_approval(order["id"], actor_id="1", error="telegram unavailable")
    assert released["status"] == "pending"
    assert "telegram unavailable" in released["approval_last_error"]


def test_concurrent_claim_has_one_winner(tmp_path):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])

    def claim(admin: int):
        try:
            return repo.claim_order_for_approval(order["id"], actor_id=str(admin))["processing_by"]
        except ValueError:
            return None

    with ThreadPoolExecutor(max_workers=12) as pool:
        outcomes = list(pool.map(claim, range(1, 13)))
    assert len([value for value in outcomes if value is not None]) == 1


@pytest.mark.parametrize("reason", ["", " ", "x", "ab"])
def test_rejection_reason_is_required(tmp_path, reason):
    repo = repo_for(tmp_path)
    r, q = receipt(repo, "10"), quote(repo, "10")
    order = repo.submit_order_from_quote("10", quote_id=q["quote_id"], receipt_id=r["id"])
    with pytest.raises(ValueError, match="REJECTION_REASON_REQUIRED"):
        repo.reject_order(order["id"], actor_id="1", reason=reason)
