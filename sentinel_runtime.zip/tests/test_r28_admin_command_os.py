from __future__ import annotations

from pathlib import Path
from io import BytesIO

from PIL import Image
from types import SimpleNamespace

import pytest

from modules.admin_command_os import ADMIN_PANEL_TAXONOMY, admin_command_center_snapshot, admin_global_search
from modules.automation_v2 import create_automation_rule, process_automation_event

ROOT = Path(__file__).resolve().parents[1]
OWNER_ID = 354678485
DELEGATED_ID = 987654321


def _delegated_db(*permissions: str) -> dict:
    return {
        "delegated_admins": {
            str(DELEGATED_ID): {
                "user_id": DELEGATED_ID,
                "permissions": list(permissions),
                "active": True,
                "approval_status": "approved",
            }
        }
    }


def test_global_search_finds_users_tickets_signals_and_payments() -> None:
    db = {
        "users": {"100": {"id": "100", "user_id": "100", "username": "amir_test", "first_name": "Amir"}},
        "tickets": [{"id": "T-7", "user_id": "100", "subject": "واریز تتر", "message": "رسید پرداخت"}],
        "signals": [{"id": "S-184", "display_number": "184", "symbol": "XAUUSD", "status": "open"}],
        "vip_orders": [{"id": "ORD-9", "order_id": "ORD-9", "user_id": "100", "txid": "TRX-8492", "status": "pending"}],
    }
    assert admin_global_search(db, OWNER_ID, "amir")["items"][0]["type"] == "users"
    assert any(row["type"] == "tickets" for row in admin_global_search(db, OWNER_ID, "واریز تتر")["items"])
    assert any(row["type"] == "signals" for row in admin_global_search(db, OWNER_ID, "XAUUSD")["items"])
    assert any(row["type"] == "payments" for row in admin_global_search(db, OWNER_ID, "TRX-8492")["items"])


def test_global_search_is_permission_aware() -> None:
    db = _delegated_db("users_view")
    db["users"] = {"100": {"id": "100", "username": "visible-user"}}
    db["vip_orders"] = [{"id": "ORD-SECRET", "txid": "SECRET-TXID", "status": "pending"}]
    assert admin_global_search(db, DELEGATED_ID, "visible-user")["total"] == 1
    hidden = admin_global_search(db, DELEGATED_ID, "SECRET-TXID")
    assert hidden["total"] == 0
    assert all(row["type"] != "payments" for row in hidden["items"])


def test_command_center_prioritizes_actions_and_keeps_all_taxonomy_domains() -> None:
    db = {
        "users": {"1": {"id": "1"}, "2": {"id": "2"}},
        "vip_users": {"1": {"user_id": "1"}},
        "vip_orders": [{"id": "P1", "status": "pending"}],
        "tickets": [{"id": "T1", "status": "open", "waiting_for": "admin"}],
        "ai_admin_command_queue": [{"id": 1, "status": "pending_primary_approval"}],
        "automation_outbox": [{"id": 1, "status": "failed"}],
        "marketing_campaigns": {"CMP-1": {"id": "CMP-1", "ai_ad_status": "READY_FOR_REVIEW"}},
    }
    result = admin_command_center_snapshot(db, OWNER_ID)
    assert result["action_items"][0]["title"] == "پرداخت‌های معلق"
    assert result["metrics"]["pending_ai_approvals"] == 1
    assert set(result["taxonomy"]) == {
        "command", "trading", "market", "users", "sales", "content",
        "education", "engagement", "automation", "analytics", "system",
    }
    assert result["taxonomy"] == ADMIN_PANEL_TAXONOMY


def test_automation_v2_supports_nested_conditions_dry_run_and_idempotency() -> None:
    db: dict = {}
    rule = create_automation_rule(
        db,
        name="تمدید VIP نزدیک",
        trigger="vip_expiring",
        conditions={"all": [
            {"field": "days_left", "operator": "lte", "value": 3},
            {"any": [
                {"field": "plan", "operator": "eq", "value": "vip"},
                {"field": "lifetime_value", "operator": "gte", "value": 1000000},
            ]},
        ]},
        actions=[{"type": "send_message", "payload": {"user_id": "{{user_id}}", "text": "تمدید برای {{user_id}}"}}],
        guards={"max_runs_per_day": 20},
        actor_id=OWNER_ID,
        enabled=True,
    )
    event = {"event_id": "expiry-100", "user_id": "100", "days_left": 2, "plan": "vip", "dry_run": True}
    first = process_automation_event(db, "vip_expiring", event, actor_id=OWNER_ID)
    second = process_automation_event(db, "vip_expiring", event, actor_id=OWNER_ID)
    assert first["matched"][0]["status"] == "completed"
    assert first["matched"][0]["dry_run"] is True
    assert db.get("automation_outbox", []) == []
    assert second["matched"][0]["status"] == "duplicate"
    assert rule["id"].startswith("AR2-")


def test_primary_sensitive_ai_action_requires_human_preview(monkeypatch: pytest.MonkeyPatch) -> None:
    from services import ai_control_service as service

    calls = [{"action": "payment_approve", "payload": {"order_id": "ORD-1"}}]
    plan = [SimpleNamespace(index=0, action="payment_approve", risk="financial_mutation", reversible=False, execution_key="key")]
    monkeypatch.setattr(service, "sanitize_tool_calls", lambda raw, **_kwargs: list(raw))
    monkeypatch.setattr(service, "build_execution_plan", lambda *_args, **_kwargs: plan)
    monkeypatch.setattr(service, "_record_plan", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(service, "is_primary_admin", lambda _actor: True)
    monkeypatch.setattr(service, "backend_risk", lambda _action: "financial_mutation")
    monkeypatch.setattr(service, "ai_execution_settings", lambda: {
        "execution_enabled": True,
        "autonomous_primary_admin": True,
        "primary_admin_full_bot_access": True,
        "confirm_sensitive_actions": True,
    })
    queued: list[dict] = []
    monkeypatch.setattr(service, "queue_ai_admin_commands", lambda _actor, rows, **_kwargs: queued.extend(rows) or [{"id": 77, **row} for row in rows])
    monkeypatch.setattr(service, "execute_registered_admin_action", lambda *_args, **_kwargs: pytest.fail("sensitive action executed without human approval"))

    result = service.execute_or_queue_ai_tool_calls(OWNER_ID, calls, conversation_id="c1", response_id="r1")
    assert result["mode"] == "primary_preview_required"
    assert result["queued"][0]["id"] == 77
    assert queued[0]["action"] == "payment_approve"


def test_gemini_ad_pipeline_creates_secure_image_and_qa(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from modules import gemini_ads

    monkeypatch.setattr(gemini_ads, "SETTINGS", SimpleNamespace(gemini_generated_ads_dir=str(tmp_path / "ads")))
    monkeypatch.setattr(gemini_ads, "gemini_generate_ad_copy", lambda *_args, **_kwargs: {
        "variants": ["تبلیغ دقیق Sentinel برای مدیریت ریسک."] * 3,
        "selected": "تبلیغ دقیق Sentinel برای مدیریت ریسک.",
        "rationale": "شفاف و بدون ادعای تضمینی",
        "model": "test-copy",
    })
    buffer = BytesIO()
    Image.new("RGB", (512, 512), "black").save(buffer, format="PNG")
    monkeypatch.setattr(gemini_ads, "gemini_generate_admin_image", lambda *_args, **_kwargs: {
        "image_bytes": buffer.getvalue(),
        "mime_type": "image/png",
        "model": "test-image",
    })
    db: dict = {}
    campaign = gemini_ads.create_ai_ad_campaign(
        db, actor_id=OWNER_ID, name="تبلیغ ریسک", product="دوره ریسک",
        objective="فروش دوره", audience="all", delivery="draft",
    )
    generated = gemini_ads.generate_ai_ad_image(db, campaign["id"], actor_id=OWNER_ID)
    asset_path = Path(generated["asset"]["path"])
    assert asset_path.is_file()
    assert asset_path.parent == (tmp_path / "ads").resolve()
    assert generated["qa"]["passed"] is True
    assert generated["campaign"]["creative"]["type"] == "photo"
    assert generated["campaign"]["ai_ad_status"] == "READY_FOR_REVIEW"


def test_r28_voice_search_and_action_registry_are_wired() -> None:
    platform = (ROOT / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    jobs = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    plan = (ROOT / "handlers" / "registration_plan.py").read_text(encoding="utf-8")
    actions = (ROOT / "services" / "actions_v2" / "ai.py").read_text(encoding="utf-8")
    assert "async def ai_chat_voice_router" in platform
    assert "gemini_transcribe_admin_audio" in platform
    assert "async def a_admin_search_start" in platform
    assert "filters.VOICE, ai_chat_voice_router" in jobs
    assert 'CallbackQueryHandler(a_admin_search_start, pattern=r"^a_admin_search$")' in jobs
    assert '("asearch", "admin_search_command")' in plan
    for name in (
        "admin_command_center_snapshot", "admin_global_search", "automation_v2_rule_create",
        "automation_v2_rule_update", "automation_v2_rule_test", "ai_ad_campaign_create",
        "ai_ad_image_generate", "ai_ad_summary", "ai_ad_approve", "ai_ad_schedule",
    ):
        assert f'@action("{name}"' in actions


def test_every_legacy_admin_menu_callback_is_categorized() -> None:
    from bot_runtime.navigation import _admin_menu_items, _admin_navigation_categories

    menu_callbacks = {callback for _label, callback, _permission in _admin_menu_items()}
    categorized = {
        callback
        for section in _admin_navigation_categories().values()
        for callback in section.get("callbacks", [])
    }
    assert len(_admin_navigation_categories()) == 11
    assert menu_callbacks <= categorized
    assert "a_admin_search" in menu_callbacks


def test_market_scope_fallback_and_bare_crypto_symbol(monkeypatch: pytest.MonkeyPatch) -> None:
    import modules.market_scope as market_scope

    def explode(_value: str):
        raise ValueError("bad")

    monkeypatch.setattr(market_scope, "normalize_asset_symbol", explode)
    assert market_scope.classify_market_symbol("BTC") == market_scope.MARKET_CRYPTO
    assert market_scope.market_label("crypto") == "کریپتو"
