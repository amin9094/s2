from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from repositories.v2.accounts import AccountRepository
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load
from repositories.v2.journal import JournalRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.preferences import PreferenceRepository
from repositories.v2.signals import SignalRepository


def test_common_json_and_cursor_contracts() -> None:
    assert json_load(json_dump({"b": 2, "a": 1})) == {"a": 1, "b": 2}
    assert json_load("broken", {"safe": True}) == {"safe": True}
    cursor = encode_cursor("2026-01-01T00:00:00+00:00", "row-1")
    assert decode_cursor(cursor) == ("2026-01-01T00:00:00+00:00", "row-1")
    assert decode_cursor(None) is None
    with pytest.raises(ValueError, match="INVALID_CURSOR"):
        decode_cursor("not-base64")
    with pytest.raises(ValueError):
        json_dump({"bad": float("nan")})


def test_preferences_get_set_patch(sqlite_engine) -> None:
    repo = PreferenceRepository(sqlite_engine)
    assert repo.get(1, "missing", {"x": 1}) == {"x": 1}
    assert repo.set(1, "prefs", {"lang": "fa"}) == {"lang": "fa"}
    assert repo.get(1, "prefs") == {"lang": "fa"}
    assert repo.patch(1, "prefs", {"theme": "dark"}) == {"lang": "fa", "theme": "dark"}
    repo.set(1, "not-a-dict", [1, 2])
    assert repo.patch(1, "not-a-dict", {"ok": True}) == {"ok": True}


def test_account_equity_and_archive_lifecycle(sqlite_engine) -> None:
    repo = AccountRepository(sqlite_engine)
    first = repo.upsert(7, {"name": "Main", "balance": 10_000, "equity": 9_500, "timezone": "Asia/Tehran"})
    assert first["is_default"] is True
    assert first["high_water_mark"] == 10_000
    second = repo.upsert(7, {"name": "Prop", "balance": 20_000, "equity": 20_500, "is_default": True})
    assert repo.get(7)["id"] == second["id"]
    assert len(repo.list_for_user(7)) == 2
    observed = datetime.now(UTC).isoformat()
    event = repo.record_equity(7, second["id"], balance=20_200, equity=19_800, floating_pnl=-400, confidence=2, observed_at=observed)
    assert event["confidence"] == 1.0
    assert repo.daily_snapshot(second["id"], event["account_local_date"])["lowest_equity"] == 19_800
    repo.record_equity(7, second["id"], balance=20_500, equity=21_000, observed_at=(datetime.now(UTC) + timedelta(seconds=1)).isoformat())
    snapshot = repo.daily_snapshot(second["id"], event["account_local_date"])
    assert snapshot["highest_equity"] == 21_000
    archived = repo.archive(7, first["id"])
    assert archived["archived"] is True
    assert len(repo.list_for_user(7)) == 1
    assert len(repo.list_for_user(7, include_archived=True)) == 2
    with pytest.raises(ValueError, match="TRADING_ACCOUNT_NOT_FOUND"):
        repo.archive(7, "missing")
    with pytest.raises(ValueError):
        repo.upsert(7, {"timezone": "Mars/Olympus"})


def _open_position(repos, *, signal_id="sig-1", position_id="pos-1"):
    accounts, positions = repos
    account = accounts.upsert(11, {"name": "Main", "balance": 10_000, "equity": 10_000})
    return account, positions.open({
        "id": position_id,
        "user_id": 11,
        "account_id": account["id"],
        "signal_id": signal_id,
        "symbol": "XAU/USD",
        "side": "BUY",
        "actual_entry": 2400,
        "actual_stop": 2390,
        "actual_volume": 1.0,
        "risk_percent": 1.0,
        "risk_money": 100,
    })


def test_position_open_partial_close_and_final_close(sqlite_engine) -> None:
    accounts = AccountRepository(sqlite_engine)
    positions = PositionRepository(sqlite_engine)
    account, position = _open_position((accounts, positions))
    assert position["symbol"] == "XAUUSD"
    assert positions.active_exposure(11, account["id"]) == {"open_count": 1, "risk_percent": 1.0, "risk_money": 100.0}
    with pytest.raises(ValueError, match="POSITION_ALREADY_OPEN"):
        positions.open({**position, "id": "pos-2"})
    partial = positions.close(11, position["id"], close_volume=0.4, realized_pnl=40, exit_price=2410, commission=2, fees=1)
    assert partial["status"] == "partial"
    assert partial["remaining_volume"] == pytest.approx(0.6)
    assert partial["pnl_event"]["net_realized_pnl"] == 37
    closed = positions.close(11, position["id"], close_volume=0.6, realized_pnl=90, exit_price=2420)
    assert closed["status"] == "closed"
    assert positions.active_for_signal(11, "sig-1") == []
    events = positions.events_for_position(position["id"])
    assert [event["event_type"] for event in events] == ["partial_close", "close"]
    pnl = positions.pnl_for_date(account["id"], events[0]["account_local_date"])
    assert pnl["event_count"] == 2
    assert pnl["net_pnl"] == pytest.approx(127)
    with pytest.raises(ValueError, match="POSITION_NOT_ACTIVE"):
        positions.close(11, position["id"], close_volume=0.1, realized_pnl=1, exit_price=2421)


def test_position_validation_and_cancel(sqlite_engine) -> None:
    accounts = AccountRepository(sqlite_engine)
    positions = PositionRepository(sqlite_engine)
    account = accounts.upsert(12, {"balance": 1_000, "equity": 1_000})
    base = {"user_id": 12, "account_id": account["id"], "symbol": "EURUSD", "side": "SELL", "actual_entry": 1.1, "actual_stop": 1.11, "actual_volume": 1, "risk_percent": 1, "risk_money": 10}
    with pytest.raises(ValueError, match="INVALID_POSITION_STATUS"):
        positions.open({**base, "status": "unknown"})
    with pytest.raises(ValueError, match="INVALID_POSITION_VOLUME"):
        positions.open({**base, "actual_volume": 0})
    with pytest.raises(ValueError, match="INVALID_POSITION_LEVELS"):
        positions.open({**base, "actual_stop": 1.1})
    row = positions.open(base)
    cancelled = positions.cancel(12, row["id"], reason="manual")
    assert cancelled["status"] == "cancelled"
    assert positions.cancel(12, row["id"])["status"] == "cancelled"
    with pytest.raises(ValueError, match="POSITION_NOT_FOUND"):
        positions.cancel(12, "missing")
    with pytest.raises(ValueError, match="INVALID_CLOSE_VOLUME"):
        positions.close(12, row["id"], close_volume=0, realized_pnl=0, exit_price=1)


def test_journal_crud_pagination_and_idempotency(sqlite_engine) -> None:
    repo = JournalRepository(sqlite_engine)
    one = repo.add(20, {"id": "jnl-1", "position_id": "pos-1", "signal_id": "sig-1", "symbol": "BTC/USD", "side": "BUY", "volume": 1, "entry_price": 60_000})
    retry = repo.add(20, {"id": "different", "position_id": "pos-1", "signal_id": "sig-1", "symbol": "BTCUSD", "side": "BUY", "volume": 1})
    assert retry["id"] == one["id"]
    second = repo.add(20, {"id": "jnl-2", "signal_id": "sig-1", "source": "manual", "symbol": "ETHUSD", "side": "SELL", "volume": 2})
    assert repo.get_by_position(20, "pos-1")["id"] == one["id"]
    assert repo.get_by_signal(20, "sig-1", source="manual")["id"] == second["id"]
    updated = repo.update(20, one["id"], {"status": "partial", "remaining_volume": 0.5, "pnl_amount": 100})
    assert updated["status"] == "partial"
    page = repo.list_for_user(20, limit=1)
    assert len(page["items"]) == 1 and page["next_cursor"]
    page2 = repo.list_for_user(20, limit=1, cursor=page["next_cursor"])
    assert page2["items"]
    repo.archive(20, second["id"])
    assert all(row["id"] != second["id"] for row in repo.list_for_user(20)["items"])
    with pytest.raises(ValueError, match="INVALID_JOURNAL_ENTRY"):
        repo.add(20, {"symbol": "", "side": "BUY"})
    with pytest.raises(ValueError, match="JOURNAL_ENTRY_NOT_FOUND"):
        repo.update(20, "missing", {})


def test_signal_revision_replay_track_record_and_pagination(sqlite_engine) -> None:
    repo = SignalRepository(sqlite_engine)
    created_at = "2026-01-01T00:00:00+00:00"
    first = repo.upsert({"id": "100", "display_number": 100, "symbol": "XAU/USD", "side": "BUY", "status": "open", "market_category": "forex", "created_at": created_at})
    assert first["revision"] == 1
    retry = repo.upsert({"id": "100", "display_number": 100, "symbol": "XAU/USD", "side": "BUY", "status": "open", "market_category": "forex", "created_at": created_at})
    assert retry["revision"] == 1
    final = repo.upsert({"id": "100", "status": "win", "result_r": 2.5, "updated_at": "2026-01-02T00:00:00+00:00"})
    assert final["revision"] == 2
    replay = repo.replay("100")
    assert replay["revision_count"] == 2
    assert replay["outcome"]["result_r"] == 2.5
    track = repo.track_record()
    assert track["summary"]["sample_size"] == 1
    assert track["summary"]["win_rate"] == 100.0
    for index in range(101, 104):
        repo.upsert({"id": str(index), "display_number": index, "symbol": "BTCUSD", "side": "SELL", "status": "open", "market_category": "crypto", "created_at": f"2026-01-0{index-99}T00:00:00+00:00"})
    page = repo.list(limit=2, status="active")
    assert len(page["items"]) == 2 and page["next_cursor"]
    assert repo.list(limit=10, market="crypto", search="BTC")["items"]
    assert repo.revision_count("100") == 2
    assert repo.delete("100") is True
    assert repo.delete("100") is False
    with pytest.raises(ValueError, match="SIGNAL_ID_REQUIRED"):
        repo.upsert({"symbol": "XAUUSD"})
    with pytest.raises(ValueError, match="SIGNAL_NOT_FOUND"):
        repo.replay("missing")
