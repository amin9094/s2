from __future__ import annotations

from datetime import UTC, datetime

from modules.admin_control_center import notification_preferences, set_notification_digest_time
from modules.notification_digest import (
    build_user_digest,
    claim_due_user_digests,
    mark_user_digest_delivery,
    render_user_digest,
)


def _db(now: datetime) -> dict:
    return {
        "users": {"1": {"id": 1, "language": "en", "created_at": now.isoformat()}},
        "user_profiles": {"1": {"language": "en"}},
        "user_points": {"1": 7},
        "vip_users": {},
        "vip_orders": [],
        "education_orders": [],
        "education_access": {},
        "lessons": [],
        "tickets": [],
        "user_rewards": [],
        "reward_requests": [],
        "price_alerts": [],
        "missions": [],
        "user_missions": {},
        "user_referrals": {},
        "signals": [],
        "signal_archive": [],
        "user_signal_choices": {},
        "user_watchlists": {"1": []},
        "trade_journal": {"1": []},
        "journal_admin_notes": {},
        "economic_calendar": {"cached_events": []},
        "economic_calendar_user_preferences": {},
    }


def _enable_digest(db: dict, *, daily: bool = True, weekly: bool = False) -> None:
    pref = notification_preferences(db, 1)
    pref.update(
        {
            "daily_digest": daily,
            "weekly_digest": weekly,
            "digest_time": "09:00",
            "timezone": "UTC",
            "quiet_enabled": False,
            "paused_until": None,
        }
    )


def test_digest_claim_is_retry_safe_and_idempotent():
    now = datetime(2026, 9, 22, 10, 0, tzinfo=UTC)  # Tuesday
    db = _db(now)
    _enable_digest(db)

    first = claim_due_user_digests(db, now=now)
    assert len(first) == 1 and first[0]["kind"] == "daily"
    assert claim_due_user_digests(db, now=now) == []

    claim = first[0]
    mark_user_digest_delivery(db, 1, claim["kind"], claim["period_key"], success=False, error="telegram", now=now)
    retry = claim_due_user_digests(db, now=now)
    assert len(retry) == 1

    claim = retry[0]
    mark_user_digest_delivery(db, 1, claim["kind"], claim["period_key"], success=True, now=now)
    assert claim_due_user_digests(db, now=now) == []


def test_weekly_digest_replaces_daily_on_configured_weekday():
    now = datetime(2026, 9, 21, 10, 0, tzinfo=UTC)  # Monday
    db = _db(now)
    _enable_digest(db, daily=True, weekly=True)
    pref = notification_preferences(db, 1)
    pref["weekly_digest_day"] = 0

    claims = claim_due_user_digests(db, now=now)
    assert len(claims) == 1
    assert claims[0]["kind"] == "weekly"


def test_digest_time_validation_and_rendering():
    now = datetime(2026, 9, 22, 10, 0, tzinfo=UTC)
    db = _db(now)
    assert set_notification_digest_time(db, 1, "12:00") == "12:00"
    payload = build_user_digest(db, 1, "daily", now=now)
    text = render_user_digest(payload)
    assert "daily summary" in text.lower()
    assert "Signals" in text
