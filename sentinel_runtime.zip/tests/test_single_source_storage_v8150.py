from services.unified_journal_service import mirror_normalized_journal_create
from services.vip_entitlement_projection import project_normalized_entitlements_to_legacy
from services.unified_signal_service import sync_legacy_signals_to_normalized


def test_normalized_journal_is_not_mirrored():
    row = {"id": "jnl-1", "user_id": 7, "symbol": "XAUUSD"}
    assert mirror_normalized_journal_create(7, row) == row


def test_runtime_legacy_projections_are_disabled():
    assert project_normalized_entitlements_to_legacy(7) == 0
    result = sync_legacy_signals_to_normalized()
    assert result["single_source"] == 1
    assert result["current"] == 0
