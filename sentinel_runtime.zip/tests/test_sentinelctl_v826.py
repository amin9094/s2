from pathlib import Path
import importlib.util


SPEC = importlib.util.spec_from_file_location("sentinelctl", Path(__file__).parents[1] / "scripts" / "sentinelctl.py")
module = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(module)


def test_doctor_contains_architecture_and_security_checks():
    labels = [label for label, _ in module.doctor_commands()]
    assert labels == ["Compile", "Security audit", "Dependency boundaries", "Circular imports"]


def test_release_order_is_quality_build_gate(tmp_path):
    commands = module.release_commands(output=tmp_path / "out.zip", evidence=tmp_path / "evidence.zip")
    assert [label for label, _ in commands] == ["Quality gate", "Build release", "Release gate"]
    assert "--full-suite" in commands[0][1]
    assert "scripts/build_release.py" in commands[1][1]


def test_production_release_never_skips_production_gates(tmp_path):
    commands = module.release_commands(output=tmp_path / "out.zip", evidence=tmp_path / "evidence.zip", production=True)
    assert "--enforce-production-thresholds" in commands[0][1]
    assert "--production" in commands[1][1]
    assert "--production" in commands[2][1]
