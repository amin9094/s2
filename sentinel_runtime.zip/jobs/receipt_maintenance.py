from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso
from modules.receipt_storage import delete_receipt_blob


def cleanup_orphan_receipts(db: dict[str, Any], *, older_than_days: int = 7, limit: int = 500) -> dict[str, Any]:
    """Remove expired, unused receipt uploads while preserving order evidence."""
    threshold = datetime.now(UTC) - timedelta(days=max(1, min(int(older_than_days), 365)))
    used = {
        str(row.get("receipt_id") or "")
        for row in db.get("vip_orders", [])
        if isinstance(row, dict) and row.get("receipt_id")
    }
    uploads = db.setdefault("receipt_uploads", {})
    candidates: list[tuple[str, dict[str, Any]]] = []
    for receipt_id, row in uploads.items():
        if not isinstance(row, dict) or str(receipt_id) in used:
            continue
        created = parse_dt(str(row.get("created_at") or ""))
        if created and created <= threshold:
            candidates.append((str(receipt_id), row))
    removed = 0
    failed = 0
    for receipt_id, row in candidates[: max(1, min(int(limit), 5000))]:
        if delete_receipt_blob(row):
            uploads.pop(receipt_id, None)
            removed += 1
        else:
            failed += 1
    result = {
        "removed": removed,
        "failed": failed,
        "eligible": len(candidates),
        "retention_days": max(1, min(int(older_than_days), 365)),
        "completed_at": utc_iso(),
    }
    db.setdefault("maintenance_log", []).append({"type": "receipt_cleanup", **result})
    db["maintenance_log"] = db["maintenance_log"][-1000:]
    return result
