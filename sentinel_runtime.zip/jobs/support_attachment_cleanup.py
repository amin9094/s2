from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from modules.support_attachment_storage import _root


def cleanup_orphaned_support_attachments(db: dict[str, Any], *, max_age_hours: int = 24) -> dict[str, int]:
    """Delete unclaimed or missing support attachment records safely."""
    cutoff = datetime.now(UTC) - timedelta(hours=max(1, int(max_age_hours)))
    rows = db.setdefault("support_attachments", {})
    removed_files = removed_records = missing_files = 0
    for storage_id, row in list(rows.items()):
        if not isinstance(row, dict) or row.get("ticket_id"):
            continue
        try:
            created = datetime.fromisoformat(str(row.get("created_at") or "").replace("Z", "+00:00"))
            if created.tzinfo is None:
                created = created.replace(tzinfo=UTC)
        except ValueError:
            created = datetime.fromtimestamp(0, UTC)
        if created > cutoff:
            continue
        path = Path(str(row.get("path") or ""))
        try:
            path.resolve().relative_to(_root())
            if path.is_file():
                path.unlink()
                removed_files += 1
            else:
                missing_files += 1
        except (OSError, ValueError):
            missing_files += 1
        rows.pop(storage_id, None)
        removed_records += 1
    return {"removed_files": removed_files, "removed_records": removed_records, "missing_files": missing_files}
