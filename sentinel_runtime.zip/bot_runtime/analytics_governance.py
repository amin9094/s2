"""Feature-owned Telegram handlers extracted from the v7 runtime: analytics_governance."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

from services.automation_v2_dispatcher import (
    deliver_automation_v2_jobs,
    run_scheduled_automation_cycle,
)

async def crm_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    uid = query.data.split(":", 1)[1]
    if uid not in (await async_snapshot()).get("users", {}):
        await query.answer("کاربر پیدا نشد", show_alert=True)
        return
    context.user_data["admin_user_uid"] = uid
    text, rows = _crm_view_payload(uid)
    await edit(query, text, rows)



async def crm_message_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_DIRECT_MESSAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    uid = str(query.data or "").split(":", 1)[1]
    if uid not in (await async_snapshot()).get("users", {}):
        await query.answer("کاربر پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["crm_message_uid"] = uid
    await edit(query, f"💬 پیام مستقیم برای کاربر <code>{uid}</code> را بفرستید:", [[InlineKeyboardButton("⬅️ CRM کاربر", callback_data=f"crm_open:{uid}")]])
    return CRM_MESSAGE_INPUT


async def crm_message_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_DIRECT_MESSAGE):
        return ConversationHandler.END
    uid = str(context.user_data.pop("crm_message_uid", "") or "")
    text = str(update.effective_message.text or "").strip()[:3500]
    if not uid or not text:
        await reply(update, "❌ کاربر یا متن پیام معتبر نیست.")
        return ConversationHandler.END
    try:
        await _telegram_request_with_button_fallback(context.bot.send_message, int(uid), text, parse_mode=ParseMode.HTML)
        await async_with_db(lambda db: (record_user_activity(db, uid, "crm_direct_message", source="admin", detail=text[:200]), audit(db, update.effective_user.id, "crm_direct_message", uid)))
    except TelegramError as exc:
        await reply(update, f"❌ ارسال پیام ناموفق بود: {esc(exc)}", [[InlineKeyboardButton("⬅️ CRM کاربر", callback_data=f"crm_open:{uid}")]])
        return ConversationHandler.END
    await reply(update, "✅ پیام مستقیم ارسال شد.", [[InlineKeyboardButton("⬅️ CRM کاربر", callback_data=f"crm_open:{uid}")]])
    return ConversationHandler.END


async def crm_discount_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_DISCOUNT_SEND):
        return
    query = update.callback_query
    await query.answer()
    uid = str(query.data or "").split(":", 1)[1]
    db = await async_snapshot()
    codes = []
    for code, row in (db.get("discount_codes", {}) or {}).items():
        if isinstance(row, dict) and str(row.get("status") or "active") == "active" and int(row.get("remaining", row.get("max_uses", 1)) or 0) != 0:
            codes.append((str(code), int(row.get("percent", row.get("discount_percent", 0)) or 0)))
    rows = [[InlineKeyboardButton(f"🎟 {code} · {percent}٪", callback_data=f"crm_discount_send:{uid}:{index}")] for index, (code, percent) in enumerate(codes[:20])]
    context.user_data["crm_discount_codes"] = codes[:20]
    rows.append([InlineKeyboardButton("⬅️ CRM کاربر", callback_data=f"crm_open:{uid}")])
    await edit(query, f"🎟 کد تخفیف برای کاربر <code>{uid}</code> را انتخاب کنید:" if codes else "کد تخفیف فعال وجود ندارد.", rows)


async def crm_discount_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_DISCOUNT_SEND):
        return
    query = update.callback_query
    await query.answer()
    parts = str(query.data or "").split(":")
    uid, index = parts[1], int(parts[2])
    codes = context.user_data.get("crm_discount_codes") or []
    if not 0 <= index < len(codes):
        await query.answer("فهرست منقضی شده؛ دوباره باز کنید.", show_alert=True)
        return
    code, percent = codes[index]
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message, int(uid),
            f"🎁 یک کد تخفیف ویژه برای شما فعال است.\nکد: <code>{esc(code)}</code>\nمقدار تخفیف: <b>{percent}٪</b>",
            parse_mode=ParseMode.HTML,
        )
        await async_with_db(lambda db: audit(db, query.from_user.id, "crm_discount_sent", f"{uid}:{code}"))
    except TelegramError as exc:
        await query.answer(f"ارسال ناموفق: {exc}", show_alert=True)
        return
    await edit(query, f"✅ کد <code>{esc(code)}</code> برای کاربر ارسال شد.", [[InlineKeyboardButton("⬅️ CRM کاربر", callback_data=f"crm_open:{uid}")]])

async def crm_note_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if not context.user_data.get("admin_user_uid"):
        await query.answer("ابتدا کاربر را انتخاب کنید", show_alert=True)
        return ConversationHandler.END
    await edit(query, "📝 یادداشت داخلی CRM را وارد کنید:", back("a_crm"))
    return CRM_NOTE_INPUT


async def crm_note_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    uid = context.user_data.get("admin_user_uid")
    try:
        await async_with_db(lambda db: add_crm_note(db, uid, update.effective_user.id, update.effective_message.text or ""))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "crm_note", str(uid)))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CRM_NOTE_INPUT
    text, rows = _crm_view_payload(str(uid))
    await reply(update, "✅ یادداشت ثبت شد.\n\n" + text, rows)
    return ConversationHandler.END


async def crm_tag_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if not context.user_data.get("admin_user_uid"):
        await query.answer("ابتدا کاربر را انتخاب کنید", show_alert=True)
        return ConversationHandler.END
    await edit(query, "🏷 نام برچسب را بنویسید. اگر قبلاً وجود داشته باشد حذف می‌شود:", back("a_crm"))
    return CRM_TAG_INPUT


async def crm_tag_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    uid = context.user_data.get("admin_user_uid")
    try:
        profile = await async_with_db(lambda db: toggle_crm_tag(db, uid, update.effective_message.text or ""))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "crm_tag", str(uid)))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CRM_TAG_INPUT
    await reply(
        update,
        "✅ برچسب‌ها بروزرسانی شد: " + esc("، ".join(profile.get("tags", [])) or "بدون برچسب"),
        [[InlineKeyboardButton("🔙 CRM کاربر", callback_data=f"crm_open:{uid}")]],
    )
    return ConversationHandler.END


async def crm_followup_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    if not context.user_data.get("admin_user_uid"):
        await query.answer("ابتدا کاربر را انتخاب کنید", show_alert=True)
        return ConversationHandler.END
    await edit(
        query,
        "⏰ پیگیری را با قالب زیر وارد کنید:\n"
        "<code>زمان | یادداشت | اولویت | نوع | تکرار</code>\n\n"
        "مثال:\n<code>2026-07-01 14:30 | تماس برای تمدید | high | call | weekly</code>\n\n"
        "اولویت: <code>low, normal, high, urgent</code>\n"
        "نوع: <code>call, message, payment, renewal, support, other</code>\n"
        "تکرار: <code>none, daily, weekly, monthly</code>\n"
        "فقط زمان نیز قابل قبول است. زمان بر اساس منطقه زمانی سرور ثبت می‌شود.",
        back("a_crm"),
    )
    return CRM_FOLLOWUP_INPUT


async def crm_followup_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return ConversationHandler.END
    from datetime import datetime
    from zoneinfo import ZoneInfo

    uid = context.user_data.get("admin_user_uid")
    raw = (update.effective_message.text or "").strip()
    parts = [part.strip() for part in raw.split("|", 4)]
    date_text = parts[0] if parts else ""
    note = parts[1] if len(parts) > 1 else ""
    priority = (parts[2] if len(parts) > 2 else "normal").lower()
    follow_up_type = (parts[3] if len(parts) > 3 else "call").lower()
    repeat = (parts[4] if len(parts) > 4 else "none").lower()
    try:
        local_dt = datetime.strptime(date_text, "%Y-%m-%d %H:%M").replace(tzinfo=ZoneInfo(SETTINGS.timezone))
        profile = await async_with_db(
            lambda db: set_crm_follow_up(
                db,
                uid,
                update.effective_user.id,
                utc_iso(local_dt),
                note=note,
                priority=priority,
                follow_up_type=follow_up_type,
                repeat=repeat,
            )
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "crm_followup", f"{uid}:{profile.get('follow_up_at')}"))
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ زمان نامعتبر است: {esc(exc)}")
        return CRM_FOLLOWUP_INPUT
    await reply(
        update,
        f"✅ پیگیری برای {display_dt(profile.get('follow_up_at'))} ثبت شد.\n"
        f"اولویت: <b>{esc(profile.get('follow_up_priority'))}</b> | نوع: <b>{esc(profile.get('follow_up_type'))}</b> | "
        f"تکرار: <b>{esc(profile.get('follow_up_repeat'))}</b>",
        [[InlineKeyboardButton("🔙 CRM کاربر", callback_data=f"crm_open:{uid}")]],
    )
    return ConversationHandler.END


async def crm_followup_clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    uid = context.user_data.get("admin_user_uid")
    if not uid:
        await query.answer("ابتدا کاربر را انتخاب کنید", show_alert=True)
        return
    await async_with_db(lambda db: set_crm_follow_up(db, uid, query.from_user.id, None))
    await async_with_db(lambda db: audit(db, query.from_user.id, "crm_followup_clear", str(uid)))
    text, rows = _crm_view_payload(str(uid))
    await edit(query, "✅ پیگیری بسته شد.\n\n" + text, rows)


async def crm_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_USER_SENSITIVE_DATA_VIEW):
        return
    query = update.callback_query
    await query.answer()
    uid = query.data.split(":", 1)[1]
    orders = [row for row in reversed((await async_snapshot()).get("vip_orders", [])) if str(row.get("user_id")) == uid][:20]
    lines = [f"📦 <b>سفارش‌های VIP کاربر {uid}</b>", ""]
    for row in orders:
        lines.append(
            f"• <code>{esc(row.get('order_id'))}</code> | {int(row.get('price', 0)):,} تومان | "
            f"{esc(row.get('status'))} | {display_dt(row.get('created_at'))}"
        )
    if not orders:
        lines.append("سفارشی ثبت نشده است.")
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("🔙 CRM", callback_data=f"crm_open:{uid}")]])


async def crm_education_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_USER_SENSITIVE_DATA_VIEW):
        return
    query = update.callback_query
    await query.answer()
    uid = query.data.split(":", 1)[1]
    orders = [row for row in reversed((await async_snapshot()).get("education_orders", [])) if str(row.get("user_id")) == uid][:20]
    lines = [f"🎓 <b>خریدهای آموزش کاربر {uid}</b>", ""]
    for row in orders:
        lines.append(
            f"• <code>{esc(row.get('order_id'))}</code> | {esc(row.get('lesson_title'))} | "
            f"{int(row.get('price', 0)):,} تومان | {esc(row.get('status'))}"
        )
    if not orders:
        lines.append("خرید آموزشی ثبت نشده است.")
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("🔙 CRM", callback_data=f"crm_open:{uid}")]])


def _automation_panel_text(
    settings: dict[str, Any],
    health: dict[str, Any] | None = None,
) -> str:
    def icon(value: Any) -> str:
        return "✅" if value else "❌"

    automation = dict((health or {}).get("automation") or {})
    automation_v2 = dict((health or {}).get("automation_v2") or {})
    text = (
        "🤖 <b>اتوماسیون مدیریتی و CRM</b>\n\n"
        f"کل سیستم: {icon(settings.get('enabled'))}\n"
        f"زمان‌بندی کمپین: {icon(settings.get('campaign_scheduler_enabled'))} | هر چرخه <b>{int(settings.get('campaign_scheduler_batch', 10))}</b> کمپین\n"
        f"CRM خودکار: {icon(settings.get('crm_enabled'))} | مرحله‌بندی خودکار: {icon(settings.get('crm_auto_stage_enabled'))}\n"
        f"ساعات سکوت: {icon(settings.get('crm_quiet_hours_enabled'))} | "
        f"<b>{int(settings.get('crm_quiet_start_hour', 23)):02d}:00 تا {int(settings.get('crm_quiet_end_hour', 8)):02d}:00</b>\n"
        f"سقف تماس روزانه هر کاربر: <b>{int(settings.get('crm_daily_contact_cap', 3))}</b> | "
        f"بچ: <b>{int(settings.get('crm_max_batch', 200))}</b>\n"
        f"تلاش مجدد: <b>{int(settings.get('crm_max_attempts', 5))}</b> بار | "
        f"فاصله پایه: <b>{int(settings.get('crm_retry_base_minutes', 5))} دقیقه</b>\n"
        f"خوش‌آمدگویی: {icon(settings.get('crm_welcome_enabled'))} | <b>فقط یک‌بار در اولین ورود</b>\n"
        f"خرید نیمه‌کاره: {icon(settings.get('crm_abandoned_checkout_enabled'))} | بعد از <b>{int(settings.get('crm_abandoned_checkout_hours', 2))} ساعت</b>\n"
        f"ریسک ریزش: {icon(settings.get('crm_churn_risk_enabled'))} | بعد از <b>{int(settings.get('crm_churn_risk_days', 21))} روز</b>\n"
        f"سرنخ داغ: {icon(settings.get('crm_lead_alert_enabled'))} | امتیاز <b>{int(settings.get('crm_lead_alert_threshold', 70))}+</b>\n"
        f"مشتری باارزش: {icon(settings.get('crm_high_value_enabled'))} | خرید <b>{int(settings.get('crm_high_value_threshold', 5000000)):,} تومان</b>\n\n"
        f"یادآوری تمدید: {icon(settings.get('vip_reminders_enabled'))} | روزها: <code>{','.join(map(str, settings.get('vip_reminder_days', [])))}</code>\n"
        f"هدیه تمدید: <b>{int(settings.get('renewal_discount_percent', 0))}٪</b> | اعتبار کد: <b>{int(settings.get('renewal_code_expiry_days', 7))} روز</b>\n"
        f"کاربر غیرفعال: {icon(settings.get('inactive_enabled'))} | بعد از <b>{int(settings.get('inactive_days', 30))} روز</b> | کد <b>{int(settings.get('inactive_discount_percent', 0))}٪</b>\n"
        f"پرداخت معلق: {icon(settings.get('pending_payment_enabled'))} | هشدار بعد از <b>{int(settings.get('pending_payment_hours', 3))} ساعت</b>\n"
        f"امتیاز بالا: {icon(settings.get('high_points_enabled'))} | آستانه <b>{int(settings.get('high_points_threshold', 1000))}</b>"
    )
    if automation:
        text += (
            "\n\n📊 <b>سلامت اتوماسیون</b>\n"
            f"موفق: <b>{int(automation.get('sent', 0)):,}</b> | "
            f"صف: <b>{int(automation.get('pending', 0)):,}</b> | "
            f"Retry: <b>{int(automation.get('retry', 0)):,}</b>\n"
            f"Dead-letter: <b>{int(automation.get('dead_letter', 0)):,}</b> | "
            f"نرخ موفقیت: <b>{float(automation.get('success_rate', 0)):.1f}٪</b>"
        )
    if automation_v2:
        text += (
            "\n\n⚡ <b>Automation V2 · Trigger → Condition → Action</b>\n"
            f"قانون فعال: <b>{int(automation_v2.get('enabled_rules', 0))}</b> از "
            f"<b>{int(automation_v2.get('rules', 0))}</b> | "
            f"اجرای موفق: <b>{int(automation_v2.get('completed_runs', 0))}</b>\n"
            f"Job آماده/Retry: <b>{int(automation_v2.get('pending_jobs', 0))}</b> / "
            f"<b>{int(automation_v2.get('retry_jobs', 0))}</b> | "
            f"Dead-letter: <b>{int(automation_v2.get('dead_letter_jobs', 0))}</b>"
        )
    return text


def _automation_dashboard_health(db: dict[str, Any]) -> dict[str, Any]:
    """Combine legacy CRM delivery health with the live Automation V2 engine."""
    health = dict(crm_dashboard_snapshot(db))
    rules = [
        row for row in db.get("automation_rules_v2", {}).values()
        if isinstance(row, dict)
    ]
    runs = [row for row in db.get("automation_v2_runs", []) if isinstance(row, dict)]
    jobs = [
        row for row in db.get("automation_v2_jobs", {}).values()
        if isinstance(row, dict)
    ]
    health["automation_v2"] = {
        "rules": len(rules),
        "enabled_rules": sum(bool(row.get("enabled")) for row in rules),
        "completed_runs": sum(str(row.get("status") or "") == "completed" for row in runs),
        "failed_runs": sum(str(row.get("status") or "") == "failed" for row in runs),
        "pending_jobs": sum(str(row.get("status") or "pending") == "pending" for row in jobs),
        "retry_jobs": sum(str(row.get("status") or "") == "retry" for row in jobs),
        "dead_letter_jobs": sum(str(row.get("status") or "") == "dead_letter" for row in jobs),
    }
    return health


def _automation_rows(settings: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    return [
        [
            state_button("کل اتوماسیون", bool(settings.get("enabled")), callback_data="auto_toggle:enabled"),
            state_button("CRM خودکار", bool(settings.get("crm_enabled")), callback_data="auto_toggle:crm_enabled"),
        ],
        [
            state_button("مرحله‌بندی خودکار", bool(settings.get("crm_auto_stage_enabled")), callback_data="auto_toggle:crm_auto_stage_enabled"),
            state_button("خوش‌آمدگویی", bool(settings.get("crm_welcome_enabled")), callback_data="auto_toggle:crm_welcome_enabled"),
        ],
        [
            state_button("زمان‌بندی کمپین", bool(settings.get("campaign_scheduler_enabled")), callback_data="auto_toggle:campaign_scheduler_enabled"),
            InlineKeyboardButton("📦 اندازه بچ کمپین", callback_data="auto_set:campaign_scheduler_batch"),
        ],
        [
            state_button("ساعات سکوت", bool(settings.get("crm_quiet_hours_enabled")), callback_data="auto_toggle:crm_quiet_hours_enabled"),
            InlineKeyboardButton("🕒 شروع سکوت", callback_data="auto_set:crm_quiet_start_hour"),
        ],
        [
            InlineKeyboardButton("🕗 پایان سکوت", callback_data="auto_set:crm_quiet_end_hour"),
            InlineKeyboardButton("📞 سقف تماس روزانه", callback_data="auto_set:crm_daily_contact_cap"),
        ],
        [
            InlineKeyboardButton("📦 اندازه بچ CRM", callback_data="auto_set:crm_max_batch"),
            InlineKeyboardButton("🔁 حداکثر تلاش", callback_data="auto_set:crm_max_attempts"),
        ],
        [InlineKeyboardButton("⏱ فاصله Retry", callback_data="auto_set:crm_retry_base_minutes")],
        [
            state_button("خرید نیمه‌کاره", bool(settings.get("crm_abandoned_checkout_enabled")), callback_data="auto_toggle:crm_abandoned_checkout_enabled"),
        ],
        [
            InlineKeyboardButton("⏳ ساعت خرید نیمه‌کاره", callback_data="auto_set:crm_abandoned_checkout_hours"),
            state_button("ریسک ریزش", bool(settings.get("crm_churn_risk_enabled")), callback_data="auto_toggle:crm_churn_risk_enabled"),
        ],
        [
            InlineKeyboardButton("📅 روز ریسک ریزش", callback_data="auto_set:crm_churn_risk_days"),
            state_button("سرنخ داغ", bool(settings.get("crm_lead_alert_enabled")), callback_data="auto_toggle:crm_lead_alert_enabled"),
        ],
        [
            InlineKeyboardButton("🎯 آستانه Lead", callback_data="auto_set:crm_lead_alert_threshold"),
            state_button("مشتری باارزش", bool(settings.get("crm_high_value_enabled")), callback_data="auto_toggle:crm_high_value_enabled"),
        ],
        [InlineKeyboardButton("💰 حد مشتری باارزش", callback_data="auto_set:crm_high_value_threshold")],
        [
            state_button("یادآوری تمدید", bool(settings.get("vip_reminders_enabled")), callback_data="auto_toggle:vip_reminders_enabled"),
            InlineKeyboardButton("📅 روزهای تمدید", callback_data="auto_set:vip_reminder_days"),
        ],
        [
            InlineKeyboardButton("🎟 درصد هدیه", callback_data="auto_set:renewal_discount_percent"),
            InlineKeyboardButton("⏳ اعتبار کد", callback_data="auto_set:renewal_code_expiry_days"),
        ],
        [
            state_button("پیگیری کاربر غیرفعال", bool(settings.get("inactive_enabled")), callback_data="auto_toggle:inactive_enabled"),
            InlineKeyboardButton("📅 روز غیرفعالی", callback_data="auto_set:inactive_days"),
        ],
        [
            state_button("پرداخت معلق", bool(settings.get("pending_payment_enabled")), callback_data="auto_toggle:pending_payment_enabled"),
            InlineKeyboardButton("⏰ ساعت هشدار پرداخت", callback_data="auto_set:pending_payment_hours"),
        ],
        [
            state_button("امتیاز بالا", bool(settings.get("high_points_enabled")), callback_data="auto_toggle:high_points_enabled"),
            InlineKeyboardButton("🏅 آستانه امتیاز", callback_data="auto_set:high_points_threshold"),
        ],
        [InlineKeyboardButton("▶️ اجرای کامل CRM + Automation V2", callback_data="crm_automation_run", style="primary")],
        [InlineKeyboardButton("📜 گزارش CRM", callback_data="crm_automation_log")],
        back("admin_home")[0],
    ]


async def a_automations(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_AUTOMATIONS):
        return
    query = update.callback_query
    await query.answer()
    settings, health = await asyncio.gather(
        async_with_db(automation_settings),
        async_with_db(_automation_dashboard_health),
    )
    await edit(query, _automation_panel_text(settings, health), _automation_rows(settings))


async def a_renewals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RENEWALS):
        return
    query = update.callback_query
    await query.answer()
    settings = await async_with_db(automation_settings)
    db = await async_snapshot()
    active = sum(1 for uid in db.get("vip_users", {}) if is_vip(db, uid))
    text = (
        "♻️ <b>تمدید هوشمند VIP</b>\n\n"
        f"VIP فعال: <b>{active}</b>\n"
        f"روزهای یادآوری: <code>{','.join(map(str, settings.get('vip_reminder_days', [])))}</code>\n"
        f"کد هدیه: <b>{int(settings.get('renewal_discount_percent', 0))}٪</b>\n"
        f"اعتبار کد: <b>{int(settings.get('renewal_code_expiry_days', 7))} روز</b>\n"
        f"پاداش تمدید پیش از انقضا: <b>{int(settings.get('early_renewal_bonus_days', 0))} روز</b>"
    )
    rows = [
        [InlineKeyboardButton("📅 روزهای یادآوری", callback_data="auto_set:vip_reminder_days")],
        [InlineKeyboardButton("🎟 درصد کد هدیه", callback_data="auto_set:renewal_discount_percent")],
        [InlineKeyboardButton("⏳ اعتبار کد", callback_data="auto_set:renewal_code_expiry_days")],
        [InlineKeyboardButton("➕ روز هدیه", callback_data="auto_set:early_renewal_bonus_days")],
        [InlineKeyboardButton("📤 اجرای آزمایشی اکنون", callback_data="renewal_run_now")],
        [InlineKeyboardButton("🎯 مرکز نگهداشت مشتری", callback_data="a_retention")],
        back("admin_home")[0],
    ]
    await edit(query, text, rows)


async def automation_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not _has_any_admin_permission(user_id, PERMISSION_AUTOMATIONS, PERMISSION_RENEWALS):
        await require_admin(update, PERMISSION_AUTOMATIONS)
        return
    query = update.callback_query
    await query.answer()
    key = query.data.split(":", 1)[1]
    current = bool(automation_settings(await async_snapshot()).get(key))
    settings = await async_with_db(lambda db: update_automation_setting(db, key, not current))
    await async_with_db(lambda db: audit(db, query.from_user.id, "automation_toggle", f"{key}:{not current}"))
    health = await async_with_db(_automation_dashboard_health)
    await edit(query, _automation_panel_text(settings, health), _automation_rows(settings))


async def automation_setting_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not _has_any_admin_permission(update.effective_user.id, PERMISSION_AUTOMATIONS, PERMISSION_RENEWALS):
        await require_admin(update, PERMISSION_AUTOMATIONS)
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    key = query.data.split(":", 1)[1]
    context.user_data["automation_setting_key"] = key
    prompts = {
        "vip_reminder_days": "روزهای یادآوری را با کاما وارد کنید؛ مثال: <code>7,3,1,0</code>",
        "renewal_discount_percent": "درصد کد هدیه تمدید را بین ۰ تا ۱۰۰ وارد کنید:",
        "renewal_code_expiry_days": "مدت اعتبار کد هدیه را به روز وارد کنید:",
        "early_renewal_bonus_days": "تعداد روز هدیه تمدید زودهنگام را وارد کنید:",
        "inactive_days": "پس از چند روز عدم فعالیت پیام بازگشت ارسال شود؟",
        "inactive_discount_percent": "درصد کد بازگشت را وارد کنید:",
        "pending_payment_hours": "چند ساعت بعد از پرداخت معلق به ادمین هشدار داده شود؟",
        "high_points_threshold": "آستانه امتیاز را وارد کنید:",
        "high_points_discount_percent": "درصد هدیه امتیاز بالا را وارد کنید:",
        "crm_abandoned_checkout_hours": "چند ساعت بعد از خرید نیمه‌کاره یادآوری ارسال شود؟",
        "crm_churn_risk_days": "پس از چند روز عدم فعالیت، کاربر در معرض ریزش محسوب شود؟",
        "crm_lead_alert_threshold": "حداقل امتیاز Lead برای هشدار به ادمین را وارد کنید:",
        "crm_high_value_threshold": "حداقل مجموع خرید مشتری باارزش را به تومان وارد کنید:",
        "campaign_scheduler_batch": "حداکثر چند کمپین زمان‌بندی‌شده در هر چرخه پردازش شود؟ (۱ تا ۵۰)",
        "crm_quiet_start_hour": "ساعت شروع سکوت را از ۰ تا ۲۳ وارد کنید:",
        "crm_quiet_end_hour": "ساعت پایان سکوت را از ۰ تا ۲۳ وارد کنید:",
        "crm_daily_contact_cap": "حداکثر پیام خودکار روزانه برای هر کاربر را وارد کنید:",
        "crm_max_batch": "حداکثر رویداد CRM در هر چرخه را وارد کنید:",
        "crm_max_attempts": "حداکثر تعداد تلاش ارسال را از ۱ تا ۱۰ وارد کنید:",
        "crm_retry_base_minutes": "فاصله پایه تلاش مجدد را به دقیقه وارد کنید:",
    }
    await edit(query, prompts.get(key, "مقدار جدید را وارد کنید:"), back("a_automations"))
    return AUTOMATION_SETTING_INPUT


async def automation_setting_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not _has_any_admin_permission(update.effective_user.id, PERMISSION_AUTOMATIONS, PERMISSION_RENEWALS):
        await require_admin(update, PERMISSION_AUTOMATIONS)
        return ConversationHandler.END
    key = context.user_data.get("automation_setting_key")
    raw = (update.effective_message.text or "").strip()
    try:
        value: Any = (
            [int(part.strip()) for part in raw.split(",") if part.strip()] if key == "vip_reminder_days" else int(raw.replace(",", ""))
        )
        settings = await async_with_db(lambda db: update_automation_setting(db, key, value))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "automation_setting", f"{key}:{value}"))
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return AUTOMATION_SETTING_INPUT
    context.user_data.pop("automation_setting_key", None)
    health = await async_with_db(_automation_dashboard_health)
    await reply(update, "✅ تنظیم ذخیره شد.\n\n" + _automation_panel_text(settings, health), _automation_rows(settings))
    return ConversationHandler.END


async def _run_automation_cycle(context: ContextTypes.DEFAULT_TYPE) -> dict[str, int]:
    counts = {
        "renewal": 0, "inactive": 0, "pending": 0, "followup": 0, "high_points": 0,
        "crm": 0, "crm_failed": 0, "discount_reminder": 0, "discount_reminder_failed": 0,
        "campaign_scheduled": 0, "campaign_failed": 0,
    }
    settings = await async_with_db(automation_settings)
    if not settings.get("enabled"):
        return counts
    campaign_counts = await run_campaign_scheduler(
        context.bot,
        bot_username=effective_bot_username(),
    )
    counts.update(campaign_counts)
    events = await async_with_db(renewal_events)
    for event in events:
        existing_code = str(event.get("code") or "")
        code_item = (await async_snapshot()).get("discount_codes", {}).get(existing_code) if existing_code else None
        percent = int(settings.get("renewal_discount_percent", 0) or 0)
        try:
            if percent > 0 and not code_item:
                code_item = await async_with_db(
                    lambda db, uid=event["user_id"], pct=percent: issue_custom_discount(
                        db,
                        uid,
                        pct,
                        expires_days=int(settings.get("renewal_code_expiry_days", 7) or 7),
                        source="smart_renewal",
                    )
                )
            if code_item:
                issued_code = str(code_item.get("code") or "")
                await async_with_db(
                    lambda db, ev=event, code=issued_code: (
                        db.get("vip_users", {})
                        .get(str(ev["user_id"]), {})
                        .setdefault("renewal_reminders", {})
                        .setdefault(ev["key"], {})
                        .update({"code": code})
                    )
                )
            days_left = int(event["days_left"])
            renewal_deadline = "امروز" if days_left == 0 else f"{days_left} روز دیگر"
            renewal_code = str((code_item or {}).get("code") or "")
            renewal_code_text = (
                f"\n🎟 کد هدیه {percent}٪: <code>{esc(renewal_code)}</code>"
                if renewal_code
                else ""
            )
            await async_with_db(
                lambda db, ev=event, code=renewal_code, text=(
                    "♻️ <b>یادآوری تمدید اشتراک</b>\n"
                    f"اشتراک شما {renewal_deadline} منقضی می‌شود. "
                    f"برای جلوگیری از قطع دسترسی تمدید کنید.{renewal_code_text}"
                ): enqueue_automation_message(
                    db,
                    dedupe_key=f"renewal:{ev['user_id']}:{ev['key']}",
                    kind="renewal",
                    recipient_id=ev["user_id"],
                    payload={
                        "text": text,
                        "parse_mode": "HTML",
                        "buttons": [[
                            {"label": "💎 تمدید اشتراک", "callback_data": "u_vip"}
                        ]],
                    },
                    finalizers=[
                        {
                            "when": "success",
                            "path": [
                                "vip_users",
                                str(ev["user_id"]),
                                "renewal_reminders",
                                str(ev["key"]),
                            ],
                            "values": {
                                "status": "sent",
                                "sent_at": "$now",
                                "code": code,
                                "error": "",
                            },
                        },
                        {
                            "when": "failure",
                            "path": [
                                "vip_users",
                                str(ev["user_id"]),
                                "renewal_reminders",
                                str(ev["key"]),
                            ],
                            "values": {
                                "status": "failed",
                                "sent_at": "$now",
                                "code": code,
                                "error": "$detail",
                            },
                        },
                    ],
                    priority=4,
                )
            )
            counts["renewal"] += 1
        except Exception as exc:
            await async_with_db(
                lambda db, ev=event, error=exc.__class__.__name__, code=code_item: mark_renewal_event(
                    db, ev["user_id"], ev["key"], success=False, code=(code or {}).get("code", ""), error=error
                )
            )
    inactive = await async_with_db(inactive_automation_events)
    for event in inactive:
        try:
            percent = int(settings.get("inactive_discount_percent", 0) or 0)
            item = None
            if percent > 0:
                item = await async_with_db(
                    lambda db, uid=event["user_id"], pct=percent: issue_custom_discount(
                        db, uid, pct, expires_days=7, source="inactive_return"
                    )
                )
            inactive_code = str((item or {}).get("code") or "")
            inactive_code_text = (
                f"\n🎟 کد بازگشت {percent}٪: <code>{esc(inactive_code)}</code>"
                if inactive_code
                else ""
            )
            await async_with_db(
                lambda db, ev=event, code=inactive_code, text=(
                    "👋 مدتی است از ربات استفاده نکرده‌اید. "
                    f"امکانات و آموزش‌های جدید منتظر شماست.{inactive_code_text}"
                ): enqueue_automation_message(
                    db,
                    dedupe_key=str(ev["key"]),
                    kind="inactive_return",
                    recipient_id=ev["user_id"],
                    payload={"text": text, "parse_mode": "HTML"},
                    finalizers=[
                        {
                            "when": "success",
                            "path": ["automation_log", str(ev["key"])],
                            "values": {
                                "status": "sent",
                                "updated_at": "$now",
                                "detail": "",
                                "code": code,
                            },
                        },
                        {
                            "when": "failure",
                            "path": ["automation_log", str(ev["key"])],
                            "values": {
                                "status": "failed",
                                "updated_at": "$now",
                                "detail": "$detail",
                                "code": code,
                            },
                        },
                    ],
                )
            )
            counts["inactive"] += 1
        except Exception as exc:
            await async_with_db(
                lambda db, key=event["key"], error=exc.__class__.__name__: mark_automation_log(db, key, success=False, detail=error)
            )
    if settings.get("high_points_enabled"):
        threshold = int(settings.get("high_points_threshold", 1000) or 1000)
        percent = int(settings.get("high_points_discount_percent", 0) or 0)
        for uid, points in (await async_snapshot()).get("user_points", {}).items():
            if int(points or 0) < threshold:
                continue
            key = f"high_points:{uid}:{threshold}"
            log_row = (await async_snapshot()).get("automation_log", {}).get(key, {})
            if isinstance(log_row, dict) and log_row.get("status") in {"pending", "sent"}:
                continue
            existing_code = str(log_row.get("code") or "") if isinstance(log_row, dict) else ""
            item = (await async_snapshot()).get("discount_codes", {}).get(existing_code) if existing_code else None
            await async_with_db(
                lambda db, event_key=key, old_code=existing_code: db.setdefault("automation_log", {}).update(
                    {event_key: {"status": "pending", "created_at": utc_iso(), "code": old_code}}
                )
            )
            try:
                if percent > 0 and not item:
                    item = await async_with_db(
                        lambda db, user_id=uid, pct=percent: issue_custom_discount(db, user_id, pct, expires_days=7, source="high_points")
                    )
                issued_code = str((item or {}).get("code") or "")
                reward_code_text = (
                    f"\n🎟 کد هدیه {percent}٪: <code>{esc(issued_code)}</code>"
                    if issued_code
                    else ""
                )
                await async_with_db(
                    lambda db, user_id=uid, event_key=key, code=issued_code, text=(
                        f"🏆 امتیاز شما به {int(points):,} رسیده است؛ تبریک!"
                        f"{reward_code_text}"
                    ): enqueue_automation_message(
                        db,
                        dedupe_key=event_key,
                        kind="high_points_reward",
                        recipient_id=user_id,
                        payload={"text": text, "parse_mode": "HTML"},
                        finalizers=[
                            {
                                "when": "success",
                                "path": ["automation_log", event_key],
                                "values": {
                                    "status": "sent",
                                    "updated_at": "$now",
                                    "code": code,
                                    "detail": "",
                                },
                            },
                            {
                                "when": "failure",
                                "path": ["automation_log", event_key],
                                "values": {
                                    "status": "failed",
                                    "updated_at": "$now",
                                    "code": code,
                                    "detail": "$detail",
                                },
                            },
                        ],
                    )
                )
                counts["high_points"] += 1
            except Exception as exc:
                issued_code = (item or {}).get("code", "")
                error_name = exc.__class__.__name__
                await async_with_db(
                    lambda db, event_key=key, code=issued_code, error=error_name: (
                        db.setdefault("automation_log", {})
                        .setdefault(event_key, {})
                        .update({"status": "failed", "updated_at": utc_iso(), "code": code, "detail": error})
                    )
                )
    now = utc_now()
    if settings.get("pending_payment_enabled"):
        threshold = int(settings.get("pending_payment_hours", 3) or 3)
        for order in (await async_snapshot()).get("vip_orders", []):
            if not isinstance(order, dict) or order.get("status") != "pending" or order.get("automation_pending_alert_at"):
                continue
            created = parse_dt(order.get("created_at"))
            if created is None or now - created < timedelta(hours=threshold):
                continue
            delivered = False
            for admin_id in _admin_ids_for_permission(PERMISSION_PAYMENTS):
                try:
                    await _telegram_request_with_button_fallback(
                        context.bot.send_message,
                        admin_id,
                        f"⏰ پرداخت <code>{esc(order.get('order_id'))}</code> بیش از {threshold} ساعت در انتظار بررسی است.",
                        parse_mode=ParseMode.HTML,
                    )
                    delivered = True
                except TelegramError:
                    pass
            if delivered:
                order_id = order.get("order_id")
                await async_with_db(
                    lambda db, oid=order_id: next(
                        (
                            row.update({"automation_pending_alert_at": utc_iso()})
                            for row in db.get("vip_orders", [])
                            if row.get("order_id") == oid
                        ),
                        None,
                    )
                )
                counts["pending"] += 1
    followups = await async_with_db(lambda db: due_crm_followups(db, horizon_minutes=0))
    for item in followups:
        uid = str(item.get("user_id") or "")
        admin_id = str(item.get("assigned_admin") or "")
        if not uid or not admin_id.isdigit():
            continue
        note = str(item.get("note") or "").strip()
        note_text = f"\n📝 {esc(note)}" if note else ""
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(admin_id),
                f"⏰ زمان پیگیری CRM کاربر <code>{uid}</code> رسیده است.{note_text}\n"
                f"اولویت: <b>{esc(item.get('priority', 'normal'))}</b> | نوع: <b>{esc(item.get('type', 'call'))}</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton("✅ انجام شد", callback_data=f"crm_followup_done:{uid}"),
                            InlineKeyboardButton("⏳ یک ساعت بعد", callback_data=f"crm_followup_snooze:{uid}:60"),
                        ],
                        [InlineKeyboardButton("بازکردن CRM", callback_data=f"crm_open:{uid}")],
                    ]
                ),
            )
            await async_with_db(lambda db, user_id=uid: mark_followup_notified(db, user_id))
            counts["followup"] += 1
        except TelegramError:
            logger.warning("Could not deliver CRM follow-up for user %s", uid)
    crm_events = await async_with_db(claim_crm_automation_events)
    for event in crm_events:
        event_type = str(event.get("type") or "")
        uid = str(event.get("user_id") or "")
        if not uid.isdigit():
            await async_with_db(
                lambda db, key=event["key"]: mark_crm_automation_event(
                    db, key, success=False, detail="invalid_user_id"
                )
            )
            counts["crm_failed"] += 1
            continue
        try:
            if event.get("audience") == "user":
                if event_type == "welcome":
                    text = (
                        "👋 <b>به SENTINEL خوش آمدید</b>\n\n"
                        "برای شروع می‌توانید قیمت بازار، تقویم اقتصادی، سیگنال‌ها و آموزش‌ها را از منوی اصلی ببینید."
                    )
                    markup = InlineKeyboardMarkup([[InlineKeyboardButton("🏠 شروع استفاده", callback_data="home")]])
                elif event_type == "abandoned_checkout":
                    text = (
                        "🛒 <b>خرید شما هنوز کامل نشده است</b>\n\n"
                        "اگر در پرداخت یا انتخاب پلن مشکلی داشتید، از بخش پشتیبانی پیام بدهید یا فرایند خرید را ادامه دهید."
                    )
                    markup = InlineKeyboardMarkup(
                        [[InlineKeyboardButton("💎 ادامه خرید", callback_data="u_vip"), InlineKeyboardButton("🎫 پشتیبانی", callback_data="u_support")]]
                    )
                else:
                    percent = int(settings.get("inactive_discount_percent", 0) or 0)
                    item = None
                    if percent > 0:
                        item = await async_with_db(
                            lambda db, user_id=uid, pct=percent: issue_custom_discount(
                                db, user_id, pct, expires_days=7, source="crm_churn_return"
                            )
                        )
                    code_text = f"\n🎟 کد بازگشت {percent}٪: <code>{item['code']}</code>" if item else ""
                    text = (
                        "👋 <b>دلمان برای حضورتان تنگ شده</b>\n\n"
                        "مدتی است از ربات استفاده نکرده‌اید. قیمت‌ها، سیگنال‌ها و آموزش‌های جدید آماده‌اند."
                        + code_text
                    )
                    markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 بازگشت به ربات", callback_data="home")]])
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    int(uid),
                    text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=markup,
                )
            else:
                assigned = str(event.get("assigned_admin") or "")
                recipients = [int(assigned)] if assigned.isdigit() else _admin_ids_for_permission(PERMISSION_CRM)
                if event_type == "hot_lead":
                    text = (
                        f"🔥 <b>سرنخ داغ CRM</b>\nکاربر: <code>{uid}</code>\n"
                        f"امتیاز Lead: <b>{int(event.get('lead_score', 0) or 0)}/100</b>"
                    )
                else:
                    text = (
                        f"💎 <b>مشتری باارزش شناسایی شد</b>\nکاربر: <code>{uid}</code>\n"
                        f"مجموع خرید: <b>{int(event.get('total_spend', 0) or 0):,} تومان</b>"
                    )
                delivered = False
                for admin_id in recipients:
                    try:
                        await _telegram_request_with_button_fallback(
                            context.bot.send_message,
                            admin_id,
                            text,
                            parse_mode=ParseMode.HTML,
                            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🗂 بازکردن CRM", callback_data=f"crm_open:{uid}")]]),
                        )
                        delivered = True
                    except TelegramError:
                        continue
                if not delivered:
                    raise RuntimeError("no_crm_admin_delivery")
            await async_with_db(lambda db, key=event["key"]: mark_crm_automation_event(db, key, success=True))
            counts["crm"] += 1
        except Exception as exc:
            await async_with_db(
                lambda db, key=event["key"], error=exc.__class__.__name__: mark_crm_automation_event(
                    db, key, success=False, detail=error
                )
            )
            counts["crm_failed"] += 1

    discount_events = await async_with_db(claim_discount_reminder_events)
    for event in discount_events:
        try:
            await async_with_db(
                lambda db, ev=event: enqueue_automation_message(
                    db,
                    dedupe_key=str(ev["key"]),
                    kind="discount_reminder",
                    recipient_id=ev["user_id"],
                    payload={
                        "text": (
                            "🎟 <b>یادآوری کد تخفیف</b>\n\n"
                            f"کد <code>{esc(ev['code'])}</code> هنوز استفاده نشده است. "
                            f"مهلت: <b>{display_dt(ev.get('expires_at'))}</b>"
                        ),
                        "parse_mode": "HTML",
                        "buttons": [[
                            {"label": "💎 استفاده در خرید اشتراک", "callback_data": "u_vip"}
                        ]],
                    },
                    finalizers=[
                        {
                            "when": "success",
                            "path": ["discount_automation_log", str(ev["key"])],
                            "values": {
                                "status": "sent",
                                "updated_at": "$now",
                                "detail": "",
                            },
                        },
                        {
                            "when": "failure",
                            "path": ["discount_automation_log", str(ev["key"])],
                            "values": {
                                "status": "failed",
                                "updated_at": "$now",
                                "detail": "$detail",
                            },
                        },
                    ],
                )
            )
            counts["discount_reminder"] += 1
        except Exception as exc:
            await async_with_db(
                lambda db, key=event["key"], error=exc.__class__.__name__: mark_discount_reminder_event(
                    db, key, success=False, detail=error
                )
            )
            counts["discount_reminder_failed"] += 1
    return counts


async def crm_automation_run(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_AUTOMATIONS):
        return
    query = update.callback_query
    await query.answer("در حال اجرای اتوماسیون…")
    counts = await _run_automation_cycle(context)
    v2_cycle = await async_with_db(run_scheduled_automation_cycle)
    v2_delivery = await deliver_automation_v2_jobs(limit=50)
    audit_payload = {
        "legacy": counts,
        "v2_cycle": v2_cycle,
        "v2_delivery": v2_delivery,
    }
    await async_with_db(
        lambda db: audit(db, query.from_user.id, "automation_full_run", str(audit_payload))
    )
    await edit(
        query,
        "✅ <b>چرخه کامل اتوماسیون اجرا شد</b>\n\n"
        f"کمپین زمان‌بندی‌شده: <b>{counts.get('campaign_scheduled', 0)}</b> | "
        f"خطای کمپین: <b>{counts.get('campaign_failed', 0)}</b>\n"
        f"CRM: <b>{counts.get('crm', 0)}</b> | خطای CRM: <b>{counts.get('crm_failed', 0)}</b>\n"
        f"تمدید: <b>{counts.get('renewal', 0)}</b> | غیرفعال: <b>{counts.get('inactive', 0)}</b>\n"
        f"پرداخت معلق: <b>{counts.get('pending', 0)}</b> | پیگیری: <b>{counts.get('followup', 0)}</b>\n\n"
        "⚡ <b>Automation V2</b>\n"
        f"رویداد: <b>{int(v2_cycle.get('events', 0))}</b> | "
        f"قانون منطبق: <b>{int(v2_cycle.get('matched_rules', 0))}</b>\n"
        f"Job تحویل‌شده: <b>{int(v2_delivery.get('completed', 0))}</b> | "
        f"ناموفق/Retry: <b>{int(v2_delivery.get('failed', 0))}</b>",
        [
            [InlineKeyboardButton("📜 گزارش CRM", callback_data="crm_automation_log")],
            [InlineKeyboardButton("↩️ اتوماسیون", callback_data="a_automations")],
        ],
    )


async def crm_followup_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    parts = str(query.data or "").split(":")
    action = parts[0]
    uid = parts[1] if len(parts) > 1 else ""
    if not uid.isdigit():
        await query.answer("کاربر نامعتبر است", show_alert=True)
        return
    if action == "crm_followup_done":
        profile = await async_with_db(lambda db: complete_crm_follow_up(db, uid, query.from_user.id, outcome="completed"))
        message = "✅ پیگیری انجام‌شده ثبت شد."
        if profile.get("follow_up_at"):
            message += f"\nپیگیری بعدی: <b>{display_dt(profile.get('follow_up_at'))}</b>"
    else:
        minutes = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 60
        profile = await async_with_db(lambda db: snooze_crm_follow_up(db, uid, query.from_user.id, minutes=minutes))
        message = f"⏳ پیگیری تا <b>{display_dt(profile.get('follow_up_at'))}</b> به تعویق افتاد."
    await async_with_db(lambda db: audit(db, query.from_user.id, action, uid))
    await edit(
        query,
        message,
        [[InlineKeyboardButton("بازکردن CRM", callback_data=f"crm_open:{uid}")]],
    )


async def automation_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        await _run_automation_cycle(context)
    except Exception:
        logger.exception("Automation cycle failed")


async def automation_outbox_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        await deliver_automation_outbox(context.bot, limit=50)
    except Exception:
        logger.exception("Automation outbox cycle failed")


async def campaign_scheduler_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        await run_campaign_scheduler(
            context.bot,
            bot_username=effective_bot_username(),
        )
    except Exception:
        logger.exception("Campaign scheduler cycle failed")


async def renewal_run_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RENEWALS):
        return
    query = update.callback_query
    await query.answer("در حال اجرا…")
    try:
        counts = await _run_automation_cycle(context)
    except Exception as exc:
        logger.exception("Manual renewal automation failed")
        await edit(
            query,
            "❌ اجرای تمدید هوشمند کامل نشد. تنظیمات پرداخت، کد تخفیف و صف ارسال بررسی شدند؛ دوباره تلاش کنید.\n"
            f"<code>{esc(type(exc).__name__)}</code>",
            back("a_renewals"),
        )
        return
    await edit(
        query,
        "✅ اجرای اتوماسیون تمام شد.\n"
        f"یادآوری تمدید: <b>{counts['renewal']}</b>\n"
        f"بازگشت کاربران: <b>{counts['inactive']}</b>\n"
        f"پرداخت معلق: <b>{counts['pending']}</b>\n"
        f"پیگیری CRM: <b>{counts['followup']}</b>\n"
        f"هدیه امتیاز بالا: <b>{counts['high_points']}</b>",
        back("a_renewals"),
    )


async def a_shifts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_SHIFTS):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    admin_ids = sorted({*map(int, SETTINGS.admin_ids), *[int(uid) for uid in delegated_admins(db)]})
    rows = []
    lines = ["🕒 <b>شیفت ادمین‌ها</b>", "روزها: ۰ دوشنبه تا ۶ یکشنبه", ""]
    today = utc_now().date()
    for admin_id in admin_ids:
        shift = db.get("admin_shifts", {}).get(str(admin_id))
        actions_today = sum(
            1
            for item in db.get("admin_logs", [])
            if isinstance(item, dict)
            and str(item.get("admin_id")) == str(admin_id)
            and (parse_dt(item.get("created_at")) or utc_now()).date() == today
        )
        on_shift = is_admin_on_shift(db, admin_id)
        if shift:
            status = "فعال" if shift.get("enabled", True) else "غیرفعال"
            lines.append(
                f"• <code>{admin_id}</code> | {status} | {'🟢 داخل شیفت' if on_shift else '🔴 خارج شیفت'} | "
                f"{','.join(map(str, shift.get('days', [])))} | {shift.get('start')} تا {shift.get('end')} | "
                f"عملیات امروز: <b>{actions_today}</b>"
            )
        else:
            lines.append(f"• <code>{admin_id}</code> | بدون محدودیت شیفت | عملیات امروز: <b>{actions_today}</b>")
        rows.append([InlineKeyboardButton(f"⚙️ تنظیم {admin_id}", callback_data=f"shift_set:{admin_id}")])
        if shift:
            rows[-1].append(
                state_button(
                    "شیفت",
                    bool(shift.get("enabled", True)),
                    callback_data=f"shift_toggle:{admin_id}",
                )
            )
    rows += back("admin_home")
    await edit(query, "\n".join(lines), rows)


async def shift_set_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ADMIN_SHIFTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    admin_id = query.data.split(":", 1)[1]
    context.user_data["shift_admin_id"] = admin_id
    await edit(
        query,
        "شیفت را با قالب زیر وارد کنید:\n<code>روزها | شروع | پایان</code>\n"
        "مثال: <code>0,1,2,3,4 | 09:00 | 18:00</code>\n"
        "روزها از ۰ دوشنبه تا ۶ یکشنبه است.",
        back("a_shifts"),
    )
    return ADMIN_SHIFT_INPUT


async def shift_set_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ADMIN_SHIFTS):
        return ConversationHandler.END
    parts = [part.strip() for part in (update.effective_message.text or "").split("|")]
    if len(parts) != 3:
        await reply(update, "❌ قالب صحیح نیست.")
        return ADMIN_SHIFT_INPUT
    try:
        days = [int(value.strip()) for value in parts[0].split(",") if value.strip()]
        admin_id = context.user_data["shift_admin_id"]
        row = await async_with_db(
            lambda db: set_admin_shift(db, admin_id, days, parts[1], parts[2], SETTINGS.timezone, update.effective_user.id)
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "admin_shift_set", str(admin_id)))
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ADMIN_SHIFT_INPUT
    context.user_data.pop("shift_admin_id", None)
    await reply(
        update,
        f"✅ شیفت ادمین <code>{row['admin_id']}</code> ثبت شد: {row['start']} تا {row['end']}",
        back("a_shifts"),
    )
    return ConversationHandler.END


async def shift_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_SHIFTS):
        return
    query = update.callback_query
    await query.answer()
    admin_id = query.data.split(":", 1)[1]
    try:
        row = await async_with_db(lambda db: toggle_admin_shift(db, admin_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("شیفت فعال شد" if row.get("enabled") else "شیفت غیرفعال شد", show_alert=True)
    await a_shifts(update, context)


def _backup_index_path(index: int) -> Path:
    backups = list_payload_backups(SETTINGS.backup_dir, limit=30)
    if index < 0 or index >= len(backups):
        raise ValueError("بکاپ پیدا نشد")
    return backups[index]


def _backup_control_state() -> dict[str, Any]:
    return control_module_state(load_db(), "backup")


async def a_backups(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_CREATE):
        return
    query = update.callback_query
    await query.answer()
    state = await run_blocking(_backup_control_state, timeout=10)
    backups = await run_blocking(list_payload_backups, SETTINGS.backup_dir, limit=10, timeout=15)
    encryption_ready = bool(SETTINGS.backup_encryption_key)
    rows = [[InlineKeyboardButton("➕ ساخت بکاپ فوری", callback_data="backup_create")]]
    if backups:
        rows.append([InlineKeyboardButton("🧪 بررسی سلامت همه", callback_data="backup_verify_all")])
    rows.append([InlineKeyboardButton("🧹 پاک‌سازی نسخه‌های قدیمی", callback_data="backup_prune")])
    lines = [
        "💾 <b>بکاپ و بازیابی امن</b>",
        f"وضعیت ماژول: <b>{'فعال' if state.get('enabled', True) else 'غیرفعال'}</b>",
        f"رمزگذاری اجباری: <b>{'بله' if state.get('encrypted', True) else 'خیر'}</b>",
        f"کلید رمزگذاری سرور: <b>{'تنظیم شده' if encryption_ready else 'تنظیم نشده'}</b>",
        f"تعداد بکاپ قابل نمایش: <b>{len(backups)}</b>",
        "",
    ]
    for index, path in enumerate(backups):
        meta = await run_blocking(backup_metadata, path, timeout=10)
        size_kb = path.stat().st_size / 1024
        encrypted = bool(meta.get("encrypted") or path.name.endswith(".enc"))
        lines.append(f"{index + 1}. {'🔐' if encrypted else '⚠️'} <code>{esc(path.name)}</code> — {size_kb:.1f} KB")
        rows.append(
            [
                InlineKeyboardButton(f"📥 دریافت #{index + 1}", callback_data=f"backup_get:{index}"),
                InlineKeyboardButton(f"🧪 تست #{index + 1}", callback_data=f"backup_verify:{index}"),
                InlineKeyboardButton(f"♻️ بازیابی #{index + 1}", callback_data=f"backup_restore:{index}"),
            ]
        )
    rows += back("admin_home")
    await edit(query, "\n".join(lines), rows)


async def backup_create_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_CREATE):
        return
    query = update.callback_query
    state = await run_blocking(_backup_control_state, timeout=10)
    if not state.get("enabled", True):
        await query.answer("ماژول بکاپ از مرکز کنترل غیرفعال است", show_alert=True)
        return
    if state.get("encrypted", True) and not SETTINGS.backup_encryption_key:
        await query.answer("BACKUP_ENCRYPTION_KEY روی سرور تنظیم نشده است", show_alert=True)
        return
    await query.answer("در حال ساخت بکاپ امن…")
    key = SETTINGS.backup_encryption_key if state.get("encrypted", True) else ""
    path = await run_blocking(create_payload_backup, (await async_snapshot()), SETTINGS.backup_dir, encryption_key=key, key_version=SETTINGS.backup_key_version, timeout=60)
    verify = await run_blocking(verify_payload_backup, path, SETTINGS.backup_dir, encryption_key=key, timeout=60)
    keep = max(1, int(state.get("keep_daily", 14) or 14) + int(state.get("keep_weekly", 8) or 0) + int(state.get("keep_monthly", 12) or 0))
    removed = await run_blocking(prune_operational_backups, SETTINGS.backup_dir, keep=keep, timeout=30)
    await async_with_db(lambda db: audit(db, query.from_user.id, "backup_create_secure", f"{path.name};pruned={removed}"))
    caption = (
        f"✅ بکاپ ساخته و تست شد: {path.name}\n"
        f"Schema: {verify.get('schema_version')} | Users: {verify.get('user_count')} | Signals: {verify.get('signal_count')}"
    )
    with path.open("rb") as handle:
        await context.bot.send_document(query.from_user.id, handle, caption=caption)
    await a_backups(update, context)


async def backup_get_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_DOWNLOAD):
        return
    query = update.callback_query
    try:
        path = await run_blocking(_backup_index_path, int(query.data.split(":", 1)[1]), timeout=15)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    meta = await run_blocking(backup_metadata, path, timeout=10)
    with path.open("rb") as handle:
        await context.bot.send_document(
            query.from_user.id,
            handle,
            caption=(
                f"💾 {path.name}\nEncrypted: {'yes' if meta.get('encrypted') else 'no'}\nSHA-256: {str(meta.get('sha256') or '')[:24]}…"
            ),
        )


async def backup_verify_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_CREATE):
        return
    query = update.callback_query
    try:
        path = await run_blocking(_backup_index_path, int(query.data.split(":", 1)[1]), timeout=15)
        result = await run_blocking(
            run_payload_restore_drill, path, SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
            key_version=SETTINGS.backup_key_version, timeout=60,
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "backup_verify", path.name))
    await query.answer("بکاپ سالم است", show_alert=True)
    await edit(
        query,
        "🧪 <b>نتیجه بررسی بکاپ</b>\n\n"
        f"فایل: <code>{esc(path.name)}</code>\n"
        f"Schema: <b>{esc(result.get('schema_version'))}</b>\n"
        f"کاربران: <b>{result.get('user_count')}</b>\n"
        f"سیگنال‌ها: <b>{result.get('signal_count')}</b>\n"
        f"رمزگذاری: <b>{'بله' if result.get('encrypted') else 'خیر'}</b>\n"
        "وضعیت: ✅ سالم و قابل بازیابی",
        back("a_backups"),
    )


async def backup_verify_all_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_CREATE):
        return
    query = update.callback_query
    await query.answer("در حال بررسی…")
    healthy = 0
    failed: list[str] = []
    for path in await run_blocking(list_payload_backups, SETTINGS.backup_dir, limit=30, timeout=15):
        try:
            await run_blocking(
                run_payload_restore_drill, path, SETTINGS.backup_dir,
                encryption_key=SETTINGS.backup_encryption_key,
                decryption_keys=SETTINGS.backup_previous_keys, timeout=60
            )
            healthy += 1
        except ValueError:
            failed.append(path.name)
    await async_with_db(lambda db: audit(db, query.from_user.id, "backup_verify_all", f"healthy={healthy};failed={len(failed)}"))
    text = f"🧪 بررسی کامل شد.\nسالم: <b>{healthy}</b>\nخراب/غیرقابل‌خواندن: <b>{len(failed)}</b>"
    if failed:
        text += "\n\n" + "\n".join(f"• <code>{esc(name)}</code>" for name in failed[:15])
    await edit(query, text, back("a_backups"))


async def backup_prune_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_CREATE):
        return
    query = update.callback_query
    state = await run_blocking(_backup_control_state, timeout=10)
    keep = max(1, int(state.get("keep_daily", 14) or 14) + int(state.get("keep_weekly", 8) or 0) + int(state.get("keep_monthly", 12) or 0))
    removed = await run_blocking(prune_operational_backups, SETTINGS.backup_dir, keep=keep, timeout=30)
    await async_with_db(lambda db: audit(db, query.from_user.id, "backup_prune", f"removed={removed};keep={keep}"))
    await query.answer(f"{removed} نسخه قدیمی حذف شد", show_alert=True)
    await a_backups(update, context)


async def _notify_pending_approval(context: ContextTypes.DEFAULT_TYPE, row: dict[str, Any]) -> None:
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("✅ تأیید دوم", callback_data=f"approval_accept:{row['token']}"),
                InlineKeyboardButton("❌ رد", callback_data=f"approval_reject:{row['token']}"),
            ]
        ]
    )
    for admin_id in _admin_ids_for_permission(PERMISSION_TWO_STEP_APPROVALS):
        if str(admin_id) == str(row.get("requested_by")):
            continue
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                admin_id,
                "🔐 <b>درخواست تأیید عملیات حساس</b>\n"
                f"درخواست‌کننده: <code>{row.get('requested_by')}</code>\n"
                f"عملیات: <b>{esc(row.get('operation'))}</b>\n"
                f"شرح: {esc(row.get('description'))}\n"
                f"مهلت: {display_dt(row.get('expires_at'))}",
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except TelegramError:
            logger.warning("Could not send two-step approval to admin %s", admin_id)


async def backup_restore_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BACKUP_RESTORE):
        return
    query = update.callback_query
    state = await run_blocking(_backup_control_state, timeout=10)
    if not state.get("enabled", True):
        await query.answer("ماژول بکاپ غیرفعال است", show_alert=True)
        return
    try:
        path = await run_blocking(_backup_index_path, int(query.data.split(":", 1)[1]), timeout=15)
        payload = await run_blocking(
            load_payload_backup, path, SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
            key_version=SETTINGS.backup_key_version, timeout=60,
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("در حال بازیابی امن…")
    safety = None
    if state.get("safe_restore", True):
        if state.get("encrypted", True) and not SETTINGS.backup_encryption_key:
            await query.answer("برای بکاپ ایمنی، کلید رمزگذاری سرور لازم است", show_alert=True)
            return
        safety = await run_blocking(
            create_payload_backup, (await async_snapshot()), SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key if state.get("encrypted", True) else "",
            key_version=SETTINGS.backup_key_version, timeout=60,
        )
        await run_blocking(
            verify_payload_backup, safety, SETTINGS.backup_dir,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys, timeout=60,
        )
    await async_with_db(lambda db: (db.clear(), db.update(payload), ensure_control_center(db)))
    await async_with_db(lambda db: audit(db, query.from_user.id, "backup_restore", path.name))
    message = f"✅ دیتابیس از <code>{esc(path.name)}</code> بازیابی و اعتبارسنجی شد."
    if safety:
        message += f"\nبکاپ ایمنی: <code>{esc(safety.name)}</code>"
    await edit(query, message, back("admin_home"))


async def a_approvals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
        return
    query = update.callback_query
    await query.answer()
    settings = await async_with_db(approval_settings)
    pending = await async_with_db(pending_approvals)
    active_operations = set(settings.get("operations", []))
    rows = [[state_button("کنترل دومرحله‌ای", bool(settings.get("enabled")), callback_data="approval_toggle")]]
    operation_buttons = [
        state_button(
            label,
            operation in active_operations,
            callback_data=f"approval_op:{operation}",
            enabled_label="فعال",
            disabled_label="غیرفعال",
        )
        for operation, label in APPROVAL_OPERATION_LABELS.items()
    ]
    rows.extend([operation_buttons[index : index + 2] for index in range(0, len(operation_buttons), 2)])
    rows.append(
        [
            InlineKeyboardButton("⏱ ۱۵ دقیقه", callback_data="approval_expiry:15"),
            InlineKeyboardButton("⏱ ۳۰ دقیقه", callback_data="approval_expiry:30"),
            InlineKeyboardButton("⏱ ۶۰ دقیقه", callback_data="approval_expiry:60"),
        ]
    )
    lines = [
        "🔐 <b>کنترل دومرحله‌ای</b>",
        f"وضعیت: <b>{'فعال' if settings.get('enabled') else 'غیرفعال'}</b>",
        f"مهلت تأیید: <b>{int(settings.get('expires_minutes', 30))} دقیقه</b>",
        f"درخواست در انتظار: <b>{len(pending)}</b>",
        "هر عملیات حساس را جداگانه روشن یا خاموش کنید.",
        "",
    ]
    for row in pending[:20]:
        lines.append(f"• #{row.get('id')} | {esc(row.get('operation'))} | درخواست‌کننده <code>{row.get('requested_by')}</code>")
        rows.append(
            [
                InlineKeyboardButton("✅ تأیید", callback_data=f"approval_accept:{row['token']}"),
                InlineKeyboardButton("❌ رد", callback_data=f"approval_reject:{row['token']}"),
            ]
        )
    rows += back("admin_home")
    await edit(query, "\n".join(lines), rows)


async def approval_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
        return
    query = update.callback_query
    await query.answer()

    def toggle(db: dict[str, Any]) -> bool:
        settings = approval_settings(db)
        settings["enabled"] = not bool(settings.get("enabled"))
        settings["updated_at"] = utc_iso()
        return bool(settings["enabled"])

    enabled = await async_with_db(toggle)
    await query.answer("فعال شد" if enabled else "غیرفعال شد", show_alert=True)
    await a_approvals(update, context)


async def approval_operation_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
        return
    query = update.callback_query
    await query.answer()
    operation = query.data.split(":", 1)[1]
    if operation not in APPROVAL_OPERATION_LABELS:
        await query.answer("عملیات نامعتبر است", show_alert=True)
        return

    def toggle(db: dict[str, Any]) -> bool:
        settings = approval_settings(db)
        operations = set(settings.get("operations", []))
        if operation in operations:
            operations.remove(operation)
            enabled = False
        else:
            operations.add(operation)
            enabled = True
        settings["operations"] = [name for name in APPROVAL_OPERATION_LABELS if name in operations]
        settings["updated_at"] = utc_iso()
        return enabled

    enabled = await async_with_db(toggle)
    await query.answer("برای این عملیات فعال شد" if enabled else "برای این عملیات غیرفعال شد", show_alert=True)
    await a_approvals(update, context)


async def approval_expiry_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
        return
    query = update.callback_query
    await query.answer()
    minutes = int(query.data.split(":", 1)[1])
    if minutes not in {15, 30, 60}:
        await query.answer("زمان نامعتبر است", show_alert=True)
        return
    await async_with_db(lambda db: approval_settings(db).update({"expires_minutes": minutes, "updated_at": utc_iso()}))
    await query.answer(f"مهلت روی {minutes} دقیقه تنظیم شد", show_alert=True)
    await a_approvals(update, context)


async def _execute_approved_action(context: ContextTypes.DEFAULT_TYPE, row: dict[str, Any]) -> str:
    operation = row.get("operation")
    payload = row.get("payload", {})
    if operation == "restore_backup":
        path = SETTINGS.backup_dir / str(payload.get("filename"))
        restored = load_backup(path, SETTINGS.backup_dir)
        safety = create_backup((await async_snapshot()), SETTINGS.backup_dir, label="before-restore")
        await async_with_db(lambda db: (db.clear(), db.update(restored)))
        return f"دیتابیس از {path.name} بازیابی شد؛ بکاپ ایمنی {safety.name} ساخته شد"
    if operation == "admin_remove":
        uid = str(payload.get("uid"))
        await async_with_db(lambda db: remove_delegated_admin(db, uid))
        return f"ادمین {uid} حذف شد"
    if operation == "admin_all_permissions":
        uid = str(payload.get("uid"))
        mode = str(payload.get("mode"))
        await async_with_db(lambda db: set_permissions(db, uid, ALL_PERMISSIONS if mode == "on" else (), row.get("requested_by")))
        return f"مجوزهای ادمین {uid} بروزرسانی شد"
    if operation == "admin_role_preset":
        uid = str(payload.get("uid"))
        preset = str(payload.get("preset") or "")
        updated = await async_with_db(
            lambda db: apply_admin_role_preset(db, uid, preset, row.get("requested_by"))
        )
        return f"نقش {updated.get('role_preset_label') or preset} برای ادمین {uid} اعمال شد"
    if operation == "bulk_vip_extension":
        days = int(payload.get("days", 0) or 0)

        def extend(db: dict[str, Any]) -> int:
            count = 0
            for uid in list(db.get("vip_users", {})):
                if is_vip(db, uid):
                    activate_vip(db, uid, days)
                    count += 1
            return count

        count = await async_with_db(extend)
        return f"{count} کاربر به مدت {days} روز تمدید شدند"
    if operation == "broadcast_all":
        message = str(payload.get("message") or "")
        recipients = user_segments((await async_snapshot()), "all")
        job = await async_with_db(
            lambda db: enqueue_broadcast(
                db,
                admin_id=row.get("requested_by"),
                segment="all",
                recipients=recipients,
                message=message,
                two_step=True,
            )
        )
        return f"ارسال همگانی وارد صف شد؛ شناسه {job['id']} برای {len(recipients)} کاربر"
    raise ValueError("عملیات تأییدشده پشتیبانی نمی‌شود")


async def approval_review_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TWO_STEP_APPROVALS):
        return
    query = update.callback_query
    await query.answer()
    action, token = query.data.split(":", 1)
    approve = action.endswith("accept")
    try:
        row = await async_with_db(lambda db: resolve_pending_approval(db, token, query.from_user.id, approve))
        result = "درخواست رد شد"
        if approve:
            result = await _execute_approved_action(context, row)
            await async_with_db(
                lambda db: next(
                    (
                        item.update({"executed_at": utc_iso(), "execution_result": result})
                        for item in db.get("pending_admin_actions", [])
                        if item.get("token") == token
                    ),
                    None,
                )
            )
        await async_with_db(lambda db: audit(db, query.from_user.id, "two_step_review", f"{token}:{approve}"))
    except (ValueError, TelegramError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await mark_callback_message(query, "✅ " + result if approve else "❌ درخواست رد شد")
    try:
        await _telegram_request_with_button_fallback(context.bot.send_message, int(row["requested_by"]), f"🔐 نتیجه عملیات: {result}")
    except TelegramError:
        pass


async def mission_control_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MISSION_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    snapshot = mission_control_snapshot(db)
    from modules.admin_command_os import admin_command_center_snapshot

    try:
        command = admin_command_center_snapshot(db, query.from_user.id)
    except PermissionError:
        command = {"metrics": {}, "action_items": [], "suggestions": []}
    attention = snapshot["attention"]
    trading = snapshot["trading"]
    risk = trading["risk"]
    providers = snapshot["providers"]
    commerce = snapshot["commerce"]
    metrics = dict(command.get("metrics") or {})
    action_items = list(command.get("action_items") or [])
    suggestions = list(command.get("suggestions") or [])

    action_lines = [
        f"• {esc(str(item.get('title') or 'اقدام'))}: <b>{int(item.get('count', 0) or 0)}</b>"
        for item in action_items[:6]
    ] or ["• مورد فوری ثبت نشده است."]
    suggestion_lines = [
        f"• {esc(str(item.get('title') or 'پیشنهاد'))}"
        for item in suggestions[:4]
    ] or ["• پیشنهاد بحرانی وجود ندارد."]
    text = (
        "🛰 <b>SENTINEL Admin Command Center</b>\n\n"
        "<b>نیازمند اقدام</b>\n" + "\n".join(action_lines) + "\n\n"
        "<b>عملیات لحظه‌ای</b>\n"
        f"• کاربران: <b>{int(metrics.get('users', 0) or 0)}</b> | VIP فعال: <b>{int(metrics.get('active_vip', 0) or 0)}</b>\n"
        f"• سیگنال فعال: <b>{int(metrics.get('active_signals', trading.get('open_signals', 0)) or 0)}</b>\n"
        f"• ریسک باز: <b>{float(risk.get('total_open_risk', 0)):.2f}٪</b>\n"
        f"• پرداخت معلق: <b>{int(metrics.get('pending_payments', attention.get('pending_orders', 0)) or 0)}</b>\n"
        f"• تیکت منتظر: <b>{int(metrics.get('waiting_tickets', 0) or 0)}</b>\n"
        f"• تأیید Gemini: <b>{int(metrics.get('pending_ai_approvals', 0) or 0)}</b>\n"
        f"• خطای اتوماسیون: <b>{int(metrics.get('automation_failures', 0) or 0)}</b>\n"
        f"• تبلیغ آماده: <b>{int(metrics.get('ready_campaigns', 0) or 0)}</b>\n\n"
        "<b>زیرساخت</b>\n"
        f"• منبع سالم/کل: <b>{providers['healthy']}/{providers['total']}</b>\n"
        f"• پرداخت منطبق: <b>{commerce['matched']}</b> | بررسی لازم: <b>{commerce['review_required']}</b>\n\n"
        "<b>پیشنهادهای هوشمند</b>\n" + "\n".join(suggestion_lines)
    )
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("🧠 فرمان Gemini", callback_data="a_ai_chat_start", style="primary"),
            InlineKeyboardButton("🔎 جست‌وجوی سراسری", callback_data="a_admin_search", style="primary"),
        ]
    ]
    for index in range(0, min(len(action_items), 6), 2):
        row: list[InlineKeyboardButton] = []
        for item in action_items[index:index + 2]:
            callback = str(item.get("callback") or "a_mission_control")
            label = f"{str(item.get('title') or 'اقدام')[:18]} ({int(item.get('count', 0) or 0)})"
            row.append(InlineKeyboardButton(label, callback_data=callback))
        if row:
            rows.append(row)
    rows.extend([
        [
            InlineKeyboardButton("🤖 اتوماسیون", callback_data="a_automations"),
            InlineKeyboardButton("📣 تبلیغات", callback_data="a_campaigns"),
        ],
        [
            InlineKeyboardButton("🚨 رخدادها", callback_data="a_incidents"),
            InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_mission_control"),
        ],
        back("admin_home")[0],
    ])
    await edit(query, text, rows)

async def admin_today_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("چک‌لیست «ادمین امروز» فقط برای ادمین اصلی است.", show_alert=True)
        return
    await query.answer()
    snapshot = await async_with_db(
        lambda db: admin_today_snapshot(
            db,
            actor_id=query.from_user.id,
            owner_id=SETTINGS.admin_ids[0],
        )
    )
    checklist_lines = [
        f"{'✅' if row['done'] else '⬜️'} {esc(row['label'])}"
        for row in snapshot["checklist"]
    ]
    providers = snapshot["providers"]
    retention = snapshot["retention"]
    backup_text = (
        display_dt(snapshot["backup"]["latest_at"])
        if snapshot["backup"]["latest_at"]
        else "ثبت نشده"
    )
    text = (
        "☀️ <b>ادمین امروز</b>\n"
        f"تاریخ کاری: <code>{esc(snapshot['date'])}</code>\n\n"
        "<b>صف‌های نیازمند اقدام</b>\n"
        f"📡 سیگنال باز: <b>{snapshot['signals']['open']}</b> | تأیید منتظر: <b>{snapshot['signals']['pending_approval']}</b>\n"
        f"💳 پرداخت معلق: <b>{snapshot['payments']['pending']}</b> | مغایرت: <b>{snapshot['payments']['review']}</b>\n"
        f"🎫 تیکت باز: <b>{snapshot['support']['open']}</b> | فوری: <b>{snapshot['support']['urgent']}</b>\n"
        f"🔌 منابع سالم: <b>{providers['healthy']}/{providers['total']}</b> | قطع: <b>{providers['offline']}</b>\n"
        f"💎 VIP رو به پایان: <b>{retention['expiring_vip']}</b> | کمپین در صف: <b>{retention['pending']}</b>\n"
        f"💾 آخرین بکاپ: <b>{esc(backup_text)}</b>\n\n"
        f"<b>چک‌لیست اختصاصی مالک ({snapshot['completed']}/{snapshot['total']})</b>\n"
        + "\n".join(checklist_lines)
        + "\n\nبا لمس هر مورد، انجام‌شدن آن فقط برای امروز ثبت می‌شود."
    )
    buttons = [
        [
            InlineKeyboardButton(
                f"{'✅' if row['done'] else '⬜️'} {row['label'][:22]}",
                callback_data=f"admin_today_toggle:{row['key']}",
            )
        ]
        for row in snapshot["checklist"]
    ]
    buttons.extend(
        [
            [
                InlineKeyboardButton("📡 سیگنال‌ها", callback_data="admin_cat:trading"),
                InlineKeyboardButton("💳 پرداخت‌ها", callback_data="admin_cat:sales"),
            ],
            [
                InlineKeyboardButton("🎫 کاربران", callback_data="admin_cat:users"),
                InlineKeyboardButton("🚨 رخدادها", callback_data="a_incidents"),
            ],
            [InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_admin_today")],
            back("admin_home")[0],
        ]
    )
    await edit(query, text, buttons)


async def admin_today_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_owner_admin(query.from_user.id):
        await query.answer("این چک‌لیست فقط در اختیار ادمین اصلی است.", show_alert=True)
        return
    item_key = str(query.data or "").split(":", 1)[1]
    try:
        state = await async_with_db(
            lambda db: toggle_admin_today_item(
                db,
                item_key,
                query.from_user.id,
                owner_id=SETTINGS.admin_ids[0],
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("انجام شد ✅" if state["done"] else "از حالت انجام‌شده خارج شد.")
    await admin_today_view(update, context)


async def provider_health_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_INTEGRATION_HEALTH_VIEW):
        return
    query = update.callback_query
    await query.answer()
    snapshot = provider_health_summary(await async_snapshot())
    lines = [
        "🔌 <b>سلامت منابع قیمت</b>",
        "",
        f"سالم: <b>{snapshot['healthy']}</b> | در حال بازیابی: <b>{snapshot.get('recovering', 0)}</b> | کند/ناپایدار: <b>{snapshot['degraded']}</b> | قطع: <b>{snapshot['offline']}</b>",
        "",
    ]
    for row in snapshot.get("providers", [])[:15]:
        icon = {"healthy": "🟢", "recovering": "🟡", "degraded": "🟠", "offline": "🔴"}.get(str(row.get("status")), "⚪️")
        lines.append(
            f"{icon} <b>{esc(row.get('provider'))}</b> — موفقیت اخیر {float(row.get('recent_success_rate', row.get('success_rate', 0))):.1f}٪ | "
            f"تأخیر {float(row.get('latency_ms_ema', 0)):.0f}ms"
        )
    if not snapshot.get("providers"):
        lines.append("هنوز داده عملیاتی ثبت نشده؛ پس از اولین دریافت قیمت این جدول پر می‌شود.")
    await edit(
        query,
        "\n".join(lines),
        [[InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_provider_health")], back("admin_cat:analytics")[0]],
    )


async def payment_reconciliation_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAYMENT_RECONCILIATION):
        return
    query = update.callback_query
    await query.answer()
    summary = reconciliation_summary(await async_snapshot())
    await edit(
        query,
        "🧾 <b>تطبیق و مغایرت پرداخت</b>\n\n"
        f"کل سفارش‌ها: <b>{summary['orders_total']}</b>\n"
        f"بدون تطبیق: <b>{summary['unreconciled']}</b>\n"
        f"منطبق: <b>{summary['matched']}</b>\n"
        f"نیازمند بررسی: <b>{summary['review_required']}</b>\n"
        f"مسدود به‌دلیل مغایرت: <b>{summary['blocked']}</b>\n\n"
        "تطبیق، مبلغ، تأییدهای شبکه و TXID تکراری را کنترل می‌کند؛ تأیید نهایی خودکار نیست.",
        [
            [InlineKeyboardButton("🔎 اجرای تطبیق سفارش‌های جدید", callback_data="reconciliation_run")],
            [InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_reconciliation")],
            back("admin_cat:sales")[0],
        ],
    )


async def payment_reconciliation_run(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAYMENT_RECONCILIATION):
        return
    query = update.callback_query

    def run(db: dict[str, Any]) -> int:
        known = {
            str(row.get("order_id") or "")
            for row in db.get("payment_reconciliations", [])
            if isinstance(row, dict)
        }
        rows = [
            row
            for row in db.get("vip_orders", [])
            if isinstance(row, dict) and str(row.get("order_id") or "") not in known
        ]
        for row in rows[:500]:
            reconcile_order(db, row, actor_id=query.from_user.id)
        return min(len(rows), 500)

    count = await async_with_db(run)
    await query.answer(f"{count} سفارش تطبیق شد.", show_alert=True)
    await payment_reconciliation_view(update, context)


async def miniapp_runtime_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RUNTIME_SAFETY):
        return
    query = update.callback_query
    await query.answer()
    from modules.miniapp_runtime import miniapp_runtime_state

    state = miniapp_runtime_state(await async_snapshot())
    enabled = bool(state.get("enabled", True))
    await edit(
        query,
        "📱 <b>کنترل دسترسی Mini App</b>\n\n"
        f"وضعیت فعلی: <b>{'روشن ✅' if enabled else 'خاموش ⛔'}</b>\n"
        f"آخرین تغییر: <b>{esc(state.get('updated_at') or '—')}</b>\n"
        f"مدیر: <code>{esc(state.get('updated_by') or '—')}</code>\n\n"
        "با خاموش‌کردن، دکمه Mini App از منوی داخل پیام کاربران حذف می‌شود. "
        "دکمه سمت چپ کادر پیام همیشه برای فهرست Commandهای تلگرام باقی می‌ماند. "
        "مدیران همچنان می‌توانند برای بررسی فنی وارد پنل شوند.",
        [
            [
                InlineKeyboardButton("✅ روشن‌کردن", callback_data="miniapp_runtime:on", style="success"),
                InlineKeyboardButton("⛔ خاموش‌کردن", callback_data="miniapp_runtime:off", style="danger"),
            ],
            [InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_miniapp_runtime")],
            back("admin_cat:system")[0],
        ],
    )


async def miniapp_runtime_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RUNTIME_SAFETY):
        return
    query = update.callback_query
    enabled = str(query.data or "").endswith(":on")
    from modules.miniapp_runtime import set_miniapp_enabled

    await async_with_db(
        lambda db: set_miniapp_enabled(
            db, enabled, actor_id=query.from_user.id,
            reason="فعال‌سازی دستی مدیر" if enabled else "غیرفعال‌سازی دستی مدیر",
        )
    )
    # The global Telegram menu button is intentionally reserved for commands.
    # Mini App visibility is controlled by inline menus and /miniapp only.
    try:
        await context.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
    except Exception:
        logger.exception("Could not synchronize Telegram command menu button")
        await query.answer("وضعیت ذخیره شد؛ همگام‌سازی منوی فرمان در راه‌اندازی بعدی تکرار می‌شود.", show_alert=True)
    else:
        await query.answer("Mini App روشن شد." if enabled else "Mini App خاموش و از منوی کاربر حذف شد.", show_alert=True)
    await miniapp_runtime_view(update, context)


async def runtime_safety_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RUNTIME_SAFETY):
        return
    query = update.callback_query
    await query.answer()
    state = runtime_safety(await async_snapshot())
    await edit(
        query,
        "🛟 <b>حالت اجرا و اضطرار</b>\n\n"
        f"محیط: <b>{esc(state.get('mode'))}</b>\n"
        f"فقط‌خواندنی: <b>{'بله' if state.get('read_only') else 'خیر'}</b>\n"
        f"اضطراری: <b>{'فعال' if state.get('disaster_mode') else 'غیرفعال'}</b>\n"
        f"دلیل: {esc(state.get('reason') or '—')}\n\n"
        "در Staging تمام انتشارها فقط به کانال‌های آزمایشی می‌روند. حالت اضطراری انتشار سیگنال را متوقف می‌کند.",
        [
            [
                InlineKeyboardButton("🧪 Staging", callback_data="runtime_mode:staging"),
                InlineKeyboardButton("🚀 Production", callback_data="runtime_mode:production"),
            ],
            [
                InlineKeyboardButton("🛑 فعال‌سازی اضطراری", callback_data="runtime_disaster:on"),
                InlineKeyboardButton("✅ پایان اضطرار", callback_data="runtime_disaster:off"),
            ],
            [InlineKeyboardButton("📱 کنترل روشن/خاموش مینی‌اپ", callback_data="a_miniapp_runtime", style="primary")],
            back("admin_cat:system")[0],
        ],
    )


async def runtime_safety_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RUNTIME_SAFETY):
        return
    query = update.callback_query
    action, value = str(query.data).split(":", 1)
    try:
        if action == "runtime_mode":
            await async_with_db(lambda db: set_runtime_mode(db, mode=value, actor_id=query.from_user.id))
        else:
            enabled = value == "on"
            await async_with_db(
                lambda db: set_runtime_mode(
                    db,
                    disaster_mode=enabled,
                    read_only=enabled,
                    reason="فعال‌سازی دستی مدیر" if enabled else "",
                    actor_id=query.from_user.id,
                )
            )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("حالت اجرا بروزرسانی شد.")
    await runtime_safety_view(update, context)


async def signal_exposure_board(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RISK_BOARDS):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    boards = professional_exposure_boards(db, controls=control_module_state(db, "signals"))
    key = str(query.data).split(":", 1)[1] if ":" in str(query.data) else "executive"
    if key not in boards:
        key = "executive"
    board = boards[key]
    lines = [f"🛡 <b>{esc(board['title'])}</b>", ""]
    if key == "executive":
        lines.extend(
            [
                f"ریسک باز باقی‌مانده: <b>{board['total_open_risk']:.2f}٪</b>",
                f"ریسک اولیه معاملات: <b>{board['declared_open_risk']:.2f}٪</b>",
                f"ریسک جهت‌دار خالص: <b>{board['net_directional_risk']:.2f}٪</b>",
                f"کاهش ریسک پس از خروج/BE: <b>{board['risk_reduced']:.2f}٪</b>",
                f"استفاده از سقف کل: <b>{board['total_utilization']:.1f}٪</b>",
            ]
        )
    elif key == "markets":
        lines.extend(
            f"• {esc(market_label(name))}: <b>{value:.2f}٪</b> — استفاده {board['market_utilization'].get(name, 0):.1f}٪"
            for name, value in board["by_market"].items()
        )
        lines.append(f"\nجهت‌ها: {esc(board['by_side'])}")
    elif key == "symbols":
        lines.extend(
            f"• <code>{esc(name)}</code>: <b>{value:.2f}٪</b> — استفاده {board['symbol_utilization'].get(name, 0):.1f}٪"
            for name, value in list(board["by_symbol"].items())[:15]
        )
        lines.append(f"\nتمرکز بزرگ‌ترین نماد: <b>{board['largest_symbol_concentration_percent']:.1f}٪</b>")
    elif key == "factors":
        for row in board["rows"][:15]:
            lines.append(
                f"• <b>{esc(row['factor'])}</b>: خالص {float(row['net']):+.2f}٪ | ناخالص {float(row['gross']):.2f}٪"
            )
    else:
        lines.extend(f"• {esc(name.upper())}: <b>{value:.2f}٪</b>" for name, value in board["by_group"].items())
        lines.append("\n<b>سناریوهای تنش</b>")
        lines.extend(
            f"• {esc(row['scenario'])}: <b>{float(row['estimated_risk_r']):.2f}R</b>"
            for row in board["stress_scenarios"]
        )
    if len(lines) == 2:
        lines.append("داده‌ای برای نمایش وجود ندارد.")
    await edit(
        query,
        "\n".join(lines),
        [
            [
                InlineKeyboardButton("📌 خلاصه", callback_data="risk_board:executive"),
                InlineKeyboardButton("🌐 بازار", callback_data="risk_board:markets"),
            ],
            [
                InlineKeyboardButton("🎯 نماد", callback_data="risk_board:symbols"),
                InlineKeyboardButton("🗺 مواجهه", callback_data="risk_board:factors"),
            ],
            [InlineKeyboardButton("⚠️ هم‌بستگی و تنش", callback_data="risk_board:correlation_stress")],
            back("a_signal_results")[0],
        ],
    )


async def signal_session_report(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    stats = session_performance(await async_snapshot())
    lines = ["🕒 <b>عملکرد سشن‌های بازار</b>", ""]
    for item in stats:
        lines.append(
            f"<b>{esc(item.get('label'))}</b> — سیگنال: {int(item.get('total', 0))} | بسته: {int(item.get('closed', 0))} | "
            f"وین‌ریت: <b>{float(item.get('win_rate', 0) or 0):.1f}٪</b> | "
            f"میانگین R/R: <b>{float(item.get('average_rr', 0) or 0):.2f}</b> | "
            f"برآیند: <b>{float(item.get('profit_percent', 0) or 0):+.2f}٪</b>"
        )
    lines.extend(["", "سشن هنگام ایجاد سیگنال ثبت می‌شود و بعداً تغییر نمی‌کند."])
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("🔄 تازه‌سازی", callback_data="sig_sessions")], back("a_signal_results")[0]])


async def signal_versions_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNALS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    signal_id = int(str(query.data).split(":", 1)[1])
    db = await async_snapshot()
    row = next((item for item in db.get("signals", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id), None)
    if not row:
        row = next((item for item in db.get("signal_archive", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == signal_id), None)
    if not row:
        await query.answer("سیگنال پیدا نشد.", show_alert=True)
        return
    versions = list(reversed(signal_version_history(row, db.get("signal_revisions", []))))[:20]
    lines = [f"🧾 <b>تاریخچه نسخه‌های #{signal_display_number(row)} | {esc(row.get('symbol'))}</b>", ""]
    for item in versions:
        changed = ", ".join(str(key) for key in item.get("changed_fields", [])) or "ایجاد اولیه"
        lines.append(
            f"• نسخه <b>{int(item.get('version', 1) or 1)}</b> | {display_dt(item.get('created_at'))}\n"
            f"  مدیر: <code>{esc(item.get('actor_id'))}</code> | دلیل: {esc(item.get('reason'))}\n"
            f"  تغییرات: <code>{esc(changed)}</code> | Hash: <code>{esc(item.get('hash'))}</code>"
        )
    await edit(query, "\n\n".join(lines), [[InlineKeyboardButton("🔙 بازگشت به سیگنال", callback_data=f"sig_result_view:{signal_id}")]])


def _kpi_task_title(task: dict[str, Any], language: str) -> str:
    key = "title_en" if normalize_language(language) == "en" else "title_fa"
    fallback = "title_fa" if key == "title_en" else "title_en"
    return str(task.get(key) or task.get(fallback) or task.get("id") or "KPI task")


def _kpi_task_description(task: dict[str, Any], language: str) -> str:
    key = "description_en" if normalize_language(language) == "en" else "description_fa"
    fallback = "description_fa" if key == "description_en" else "description_en"
    return str(task.get(key) or task.get(fallback) or "")


def _kpi_status_label(status: str, language: str) -> str:
    labels = {
        "fa": {
            "active": "فعال",
            "paused": "متوقف",
            "closed": "بسته",
            "archived": "آرشیو",
            "pending": "در انتظار بررسی",
            "approved": "تأییدشده",
            "rejected": "ردشده",
        },
        "en": {
            "active": "Active",
            "paused": "Paused",
            "closed": "Closed",
            "archived": "Archived",
            "pending": "Pending review",
            "approved": "Approved",
            "rejected": "Rejected",
        },
    }
    language = normalize_language(language)
    return labels[language].get(str(status), str(status))


def _kpi_task_text(
    task: dict[str, Any],
    language: str,
    *,
    submission: dict[str, Any] | None = None,
) -> str:
    language = normalize_language(language)
    overdue = kpi_task_is_overdue(task)
    due = display_dt(task.get("due_at")) if task.get("due_at") else ("No deadline" if language == "en" else "بدون مهلت")
    assigned = list(task.get("assignee_ids") or [])
    assigned_text = (
        ", ".join(f"<code>{esc(uid)}</code>" for uid in assigned)
        if assigned
        else ("All traders" if language == "en" else "همه تحلیلگران")
    )
    description = _kpi_task_description(task, language)
    if language == "en":
        lines = [
            f"🎯 <b>{esc(_kpi_task_title(task, language))}</b>",
            f"Task: <code>{esc(task.get('id'))}</code>",
            "",
            esc(description) if description else "<i>No additional description</i>",
            "",
            f"⭐ Score: <b>{int(task.get('points', 0) or 0)}</b>",
            f"📦 Target quantity: <b>{int(task.get('required_count', 1) or 1)}</b>",
            f"🏷 Category: <b>{esc(task.get('category'))}</b>",
            f"⚡ Priority: <b>{esc(task.get('priority'))}</b>",
            f"🗓 Deadline: <b>{due}</b>{' · OVERDUE' if overdue else ''}",
            f"👥 Assigned to: {assigned_text}",
            f"📌 Status: <b>{_kpi_status_label(str(task.get('status')), language)}</b>",
        ]
    else:
        lines = [
            f"🎯 <b>{esc(_kpi_task_title(task, language))}</b>",
            f"شناسه تسک: <code>{esc(task.get('id'))}</code>",
            "",
            esc(description) if description else "<i>توضیح تکمیلی ثبت نشده است</i>",
            "",
            f"⭐ امتیاز: <b>{int(task.get('points', 0) or 0)}</b>",
            f"📦 تعداد هدف: <b>{int(task.get('required_count', 1) or 1)}</b>",
            f"🏷 دسته: <b>{esc(task.get('category'))}</b>",
            f"⚡ اولویت: <b>{esc(task.get('priority'))}</b>",
            f"🗓 مهلت: <b>{due}</b>{' · عقب‌افتاده' if overdue else ''}",
            f"👥 تخصیص: {assigned_text}",
            f"📌 وضعیت: <b>{_kpi_status_label(str(task.get('status')), language)}</b>",
        ]
    if submission:
        if language == "en":
            lines.extend(
                [
                    "",
                    f"Your latest submission: <b>{_kpi_status_label(str(submission.get('status')), language)}</b>",
                    f"Submitted: <b>{display_dt(submission.get('submitted_at'))}</b>",
                ]
            )
            if submission.get("review_note"):
                lines.append(f"Review note: {esc(submission.get('review_note'))}")
        else:
            lines.extend(
                [
                    "",
                    f"آخرین ارسال شما: <b>{_kpi_status_label(str(submission.get('status')), language)}</b>",
                    f"زمان ارسال: <b>{display_dt(submission.get('submitted_at'))}</b>",
                ]
            )
            if submission.get("review_note"):
                lines.append(f"نظر بررسی: {esc(submission.get('review_note'))}")
    return "\n".join(lines)


def _kpi_trader_ids(db: dict[str, Any]) -> list[int]:
    output: set[int] = set()
    for uid, row in delegated_admins(db).items():
        permissions = set(row.get("permissions", [])) if isinstance(row, dict) else set()
        if row.get("active", True) and permissions.intersection(
            {PERMISSION_KPI_TRADER_VIEW, PERMISSION_SIGNALS}
        ):
            output.add(int(uid))
    return sorted(output)


async def kpi_trader_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = query.from_user.id
    language = _language_for_user(user_id)
    if not _has_any_admin_permission(
        user_id, PERMISSION_KPI_TRADER_VIEW, PERMISSION_KPI_TRADER_MANAGE
    ):
        await query.answer(
            "You do not have KPI Trader access."
            if language == "en"
            else "شما به فضای KPI Trader دسترسی ندارید.",
            show_alert=True,
        )
        return
    await query.answer()
    db = await async_snapshot()
    if not bool(kpi_settings(db).get("enabled", True)):
        await edit(
            query,
            "⛔ KPI Trader is temporarily disabled."
            if language == "en"
            else "⛔ بخش KPI Trader موقتاً توسط ادمین اصلی غیرفعال شده است.",
            main_menu(user_id),
        )
        return
    dashboard = kpi_trader_dashboard(db, user_id)
    tasks = list_tasks_for_trader(db, user_id)[:12]
    if language == "en":
        lines = [
            "🎯 <b>KPI Trader workspace</b>",
            "",
            f"Total score: <b>{dashboard['points_total']}</b> · This month: <b>{dashboard['points_month']}</b>",
            f"Approved: <b>{dashboard['approved']}</b> · Pending: <b>{dashboard['pending']}</b> · Rejected: <b>{dashboard['rejected']}</b>",
            f"Approval rate: <b>{dashboard['approval_rate']:.1f}%</b> · On-time: <b>{dashboard['on_time_rate']:.1f}%</b>",
            f"Available tasks: <b>{dashboard['available_tasks']}</b> · Overdue: <b>{dashboard['overdue_tasks']}</b>",
            "",
            "Choose a task, complete it, and submit a report or evidence for admin review.",
        ]
    else:
        lines = [
            "🎯 <b>فضای کاری KPI Trader</b>",
            "",
            f"امتیاز کل: <b>{dashboard['points_total']}</b> · این ماه: <b>{dashboard['points_month']}</b>",
            f"تأییدشده: <b>{dashboard['approved']}</b> · در بررسی: <b>{dashboard['pending']}</b> · ردشده: <b>{dashboard['rejected']}</b>",
            f"نرخ تأیید: <b>{dashboard['approval_rate']:.1f}٪</b> · انجام به‌موقع: <b>{dashboard['on_time_rate']:.1f}٪</b>",
            f"تسک فعال: <b>{dashboard['available_tasks']}</b> · عقب‌افتاده: <b>{dashboard['overdue_tasks']}</b>",
            "",
            "تسک را باز کنید و پس از انجام، گزارش یا مدرک را برای بررسی ادمین بفرستید.",
        ]
    rows = [
        [
            InlineKeyboardButton(
                f"{'🔴' if kpi_task_is_overdue(task) else '🎯'} {esc(_kpi_task_title(task, language))[:40]} · {int(task.get('points', 0) or 0)}",
                callback_data=f"kpi_trader_task:{task['id']}",
            )
        ]
        for task in tasks
    ]
    if not tasks:
        lines.extend(
            [
                "",
                "No active task is assigned to you."
                if language == "en"
                else "در حال حاضر تسک فعالی برای شما وجود ندارد.",
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                "🔄 Refresh" if language == "en" else "🔄 تازه‌سازی",
                callback_data="kpi_trader_home",
            ),
            InlineKeyboardButton(
                "🏠 Main menu" if language == "en" else "🏠 منوی اصلی",
                callback_data="home",
            ),
        ]
    )
    await edit(query, "\n".join(lines), rows)


async def kpi_trader_task_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = _language_for_user(query.from_user.id)
    if not _has_any_admin_permission(
        query.from_user.id, PERMISSION_KPI_TRADER_VIEW, PERMISSION_KPI_TRADER_MANAGE
    ):
        await query.answer(
            "Access denied." if language == "en" else "دسترسی ندارید.",
            show_alert=True,
        )
        return
    await query.answer()
    task_id = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    task = kpi_task_by_id(db, task_id)
    if not task or task not in list_tasks_for_trader(
        db, query.from_user.id, include_closed=True
    ):
        await query.answer(
            "Task not found." if language == "en" else "تسک پیدا نشد.",
            show_alert=True,
        )
        return
    submission = trader_task_submission(db, task_id, query.from_user.id)
    rows: list[list[InlineKeyboardButton]] = []
    can_submit = (
        str(task.get("status")) == "active"
        and (not submission or submission.get("status") == "rejected")
    )
    if can_submit:
        rows.append(
            [
                InlineKeyboardButton(
                    "✅ Submit completion" if language == "en" else "✅ ثبت انجام تسک",
                    callback_data=f"kpi_task_submit:{task_id}",
                    style="success",
                )
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                "↩️ KPI workspace" if language == "en" else "↩️ فضای KPI",
                callback_data="kpi_trader_home",
            )
        ]
    )
    await edit(query, _kpi_task_text(task, language, submission=submission), rows)


async def kpi_submission_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    query = update.callback_query
    language = _language_for_user(query.from_user.id)
    if not _has_any_admin_permission(
        query.from_user.id, PERMISSION_KPI_TRADER_VIEW, PERMISSION_KPI_TRADER_MANAGE
    ):
        await query.answer(
            "Access denied." if language == "en" else "دسترسی ندارید.",
            show_alert=True,
        )
        return ConversationHandler.END
    task_id = str(query.data).split(":", 1)[1]
    task = kpi_task_by_id(await async_snapshot(), task_id)
    if not task:
        await query.answer(
            "Task not found." if language == "en" else "تسک پیدا نشد.",
            show_alert=True,
        )
        return ConversationHandler.END
    context.user_data["kpi_submission_task_id"] = task_id
    await query.answer()
    await edit(
        query,
        (
            "📎 <b>Submit task evidence</b>\n\nSend a report as text, photo, document, video, audio or voice message. "
            "It will be sent to the admin review queue."
            if language == "en"
            else "📎 <b>ارسال مدرک انجام تسک</b>\n\nگزارش را به‌صورت متن، عکس، فایل، ویدئو، صوت یا ویس ارسال کنید. "
            "مورد برای صف بررسی ادمین فرستاده می‌شود."
        ),
        [
            [
                InlineKeyboardButton(
                    "Cancel" if language == "en" else "انصراف",
                    callback_data=f"kpi_trader_task:{task_id}",
                )
            ]
        ],
    )
    return KPI_SUBMISSION_INPUT


def _kpi_evidence_from_message(message: Any) -> tuple[str, str, dict[str, Any]]:
    note = str(message.text or message.caption or "").strip()
    evidence_type = "text"
    file_id = ""
    if message.photo:
        evidence_type, file_id = "photo", message.photo[-1].file_id
    elif message.document:
        evidence_type, file_id = "document", message.document.file_id
    elif message.video:
        evidence_type, file_id = "video", message.video.file_id
    elif message.voice:
        evidence_type, file_id = "voice", message.voice.file_id
    elif message.audio:
        evidence_type, file_id = "audio", message.audio.file_id
    evidence = {
        "type": evidence_type,
        "file_id": file_id,
        "source_chat_id": int(message.chat_id),
        "source_message_id": int(message.message_id),
    }
    return note, evidence_type, evidence


async def kpi_submission_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    language = _language_for_user(update.effective_user.id)
    task_id = str(context.user_data.pop("kpi_submission_task_id", "") or "")
    if not task_id:
        await reply(
            update,
            "The task session expired." if language == "en" else "نشست تسک منقضی شده است.",
            main_menu(update.effective_user.id),
        )
        return ConversationHandler.END
    note, _, evidence = _kpi_evidence_from_message(update.effective_message)
    try:
        submission = await async_with_db(
            lambda db: submit_kpi_task(
                db,
                task_id=task_id,
                trader_id=update.effective_user.id,
                note=note,
                evidence=evidence,
            )
        )
    except (ValueError, PermissionError) as exc:
        await reply(
            update,
            f"❌ {esc(exc)}",
            [[InlineKeyboardButton("KPI Trader", callback_data="kpi_trader_home")]],
        )
        return ConversationHandler.END
    db = await async_snapshot()
    task = kpi_task_by_id(db, task_id) or {}
    reviewer_ids = [
        admin_id
        for admin_id in _admin_ids_for_permission(PERMISSION_KPI_TRADER_MANAGE)
        if int(admin_id) != int(update.effective_user.id)
    ]
    for admin_id in reviewer_ids:
        try:
            await context.bot.copy_message(
                chat_id=admin_id,
                from_chat_id=update.effective_message.chat_id,
                message_id=update.effective_message.message_id,
            )
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                chat_id=admin_id,
                text=(
                    "🎯 <b>KPI Trader · گزارش جدید</b>\n\n"
                    f"تسک: <b>{esc(task.get('title_fa') or task_id)}</b>\n"
                    f"شناسه: <code>{esc(submission['id'])}</code>\n"
                    f"تحلیلگر: <code>{update.effective_user.id}</code>\n"
                    f"امتیاز پس از تأیید: <b>{int(task.get('points', 0) or 0)}</b>"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "✅ تأیید",
                                callback_data=f"kpi_review_action:{submission['id']}:approve",
                                style="success",
                            ),
                            InlineKeyboardButton(
                                "📝 بررسی",
                                callback_data=f"kpi_review_view:{submission['id']}",
                            ),
                        ]
                    ]
                ),
            )
        except TelegramError:
            logger.warning("Could not notify KPI reviewer %s", admin_id, exc_info=True)
    await reply(
        update,
        (
            "✅ Your report was submitted for admin review."
            if language == "en"
            else "✅ گزارش شما برای بررسی ادمین ارسال شد."
        ),
        [[InlineKeyboardButton("🎯 KPI Trader", callback_data="kpi_trader_home")]],
    )
    return ConversationHandler.END


def _owner_kpi_admin_ids(db: dict[str, Any]) -> list[int]:
    owner_id = int(SETTINGS.admin_ids[0]) if SETTINGS.admin_ids else 0
    values = {
        *[int(value) for value in SETTINGS.admin_ids],
        *[int(value) for value in delegated_admins(db)],
    }
    return sorted(value for value in values if value > 0 and value != owner_id)


def _owner_kpi_admin_name(db: dict[str, Any], user_id: int | str) -> str:
    user = db.get("users", {}).get(str(user_id), {})
    if not isinstance(user, dict):
        user = {}
    full_name = " ".join(
        str(user.get(key) or "").strip() for key in ("first_name", "last_name")
    ).strip()
    username = str(user.get("username") or "").strip().lstrip("@")
    return full_name or (f"@{username}" if username else str(user_id))


async def _require_owner_kpi(update: Update) -> bool:
    query = update.callback_query
    user = update.effective_user
    if user and _is_owner_admin(user.id):
        return True
    if query:
        await query.answer(
            "این بخش فقط برای ادمین اصلی قابل استفاده است.", show_alert=True
        )
    return False


async def owner_kpi_center(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    if not context.user_data.pop("_owner_kpi_query_answered", False):
        await query.answer()
    db = await async_snapshot()
    settings = kpi_settings(db)
    team = kpi_team_dashboard(db)
    admin_ids = _owner_kpi_admin_ids(db)
    monthly_used = kpi_monthly_points_awarded(db)
    budget = int(settings.get("monthly_points_budget", 100000) or 100000)
    lines = [
        "👑 <b>مرکز مالک · تسک، دسترسی و امتیاز ادمین‌ها</b>",
        "",
        f"ادمین‌های قابل مدیریت: <b>{len(admin_ids)}</b>",
        f"تسک فعال: <b>{team['active_tasks']}</b> · عقب‌افتاده: <b>{team['overdue_tasks']}</b>",
        f"صف بررسی: <b>{team['pending_reviews']}</b>",
        f"امتیاز این ماه: <b>{monthly_used:,}</b> از <b>{budget:,}</b>",
        "",
        f"KPI Trader: <b>{'فعال ✅' if settings.get('enabled', True) else 'غیرفعال ⛔'}</b>",
        f"مدرک انجام کار: <b>{'الزامی ✅' if settings.get('evidence_required', True) else 'اختیاری'}</b>",
        f"تأیید نتیجه: <b>{'فقط ادمین اصلی' if settings.get('owner_review_only') else 'مدیران مجاز'}</b>",
        f"اصلاح دستی امتیاز: <b>{'فعال' if settings.get('allow_manual_score_adjustment', True) else 'غیرفعال'}</b>",
        f"گیت کیفیت: <b>{'اجباری ✅' if settings.get('quality_gate_required', True) else 'غیرفعال'}</b> · حداقل <b>{int(settings.get('quality_gate_min_score', 80) or 80)}٪</b>",
        f"سقف هر تسک: <b>{int(settings.get('max_task_points', 1000) or 1000):,}</b> · مهلت پیش‌فرض: <b>{int(settings.get('default_due_days', 7) or 0)}</b> روز",
        "",
        "برای تعیین تسک، دسترسی و امتیاز، ادمین موردنظر را انتخاب کنید.",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for uid in admin_ids:
        dashboard = kpi_trader_dashboard(db, uid)
        view_enabled = delegated_has_permission(
            db, uid, PERMISSION_KPI_TRADER_VIEW
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'✅' if view_enabled else '⛔'} {_owner_kpi_admin_name(db, uid)[:24]} · {dashboard['points_total']} امتیاز",
                    callback_data=f"owner_kpi_admin:{uid}",
                )
            ]
        )
    if not admin_ids:
        lines.append("\nهنوز ادمین دیگری ثبت نشده است؛ ابتدا از مدیریت ادمین‌ها فرد را اضافه کنید.")
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    f"{'✅' if settings.get('enabled', True) else '⛔'} فعال‌بودن KPI",
                    callback_data="owner_kpi_setting:enabled",
                ),
                InlineKeyboardButton(
                    f"{'✅' if settings.get('evidence_required', True) else '⛔'} مدرک اجباری",
                    callback_data="owner_kpi_setting:evidence_required",
                ),
            ],
            [
                InlineKeyboardButton(
                    f"{'👑' if settings.get('owner_review_only') else '👥'} تأیید فقط مالک",
                    callback_data="owner_kpi_setting:owner_review_only",
                ),
                InlineKeyboardButton(
                    f"{'✅' if settings.get('allow_manual_score_adjustment', True) else '⛔'} اصلاح امتیاز",
                    callback_data="owner_kpi_setting:allow_manual_score_adjustment",
                ),
            ],
            [
                InlineKeyboardButton(
                    f"{'🛡' if settings.get('quality_gate_required', True) else '⛔'} گیت کیفیت",
                    callback_data="owner_kpi_setting:quality_gate_required",
                ),
                InlineKeyboardButton("🏆 عملکرد تیم", callback_data="owner_team_performance"),
            ],
            [
                InlineKeyboardButton("🗓 تقویم عملیات", callback_data="owner_team_calendar"),
                InlineKeyboardButton("💎 رشد اشتراک", callback_data="owner_subscription_growth"),
            ],
            [InlineKeyboardButton("🔔 هوشمندی اعلان‌ها", callback_data="owner_notification_intelligence")],
            [
                InlineKeyboardButton(
                    "⚙️ سقف امتیاز و مهلت",
                    callback_data="owner_kpi_limits",
                ),
                InlineKeyboardButton(
                    "🎯 مدیریت عمومی KPI", callback_data="a_kpi_trader"
                ),
            ],
            [
                InlineKeyboardButton(
                    "👮 مدیریت کامل دسترسی ادمین‌ها", callback_data="a_admins"
                )
            ],
            [
                InlineKeyboardButton(
                    "🧭 مرکز کنترل", callback_data="a_control_center"
                ),
                InlineKeyboardButton("↩️ پنل مدیریت", callback_data="admin_home"),
            ],
        ]
    )
    await edit(query, "\n".join(lines), rows)


async def owner_team_performance(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    board = team_performance_dashboard(db, _owner_kpi_admin_ids(db))
    team = board["team"]
    lines = [
        "🏆 <b>داشبورد حرفه‌ای عملکرد تیم</b>",
        "کیفیت، سرعت، امتیاز و اثر تجاری در یک نما",
        "",
        f"کیفیت میانگین: <b>{float(team['quality_score']):.1f}٪</b> · امتیاز: <b>{int(team['points']):,}</b>",
        f"درآمد منتسب: <b>{int(team['revenue']):,}</b> · فروش: <b>{int(team['sales']):,}</b>",
        f"تمدید: <b>{int(team['renewals']):,}</b> · لید: <b>{int(team['leads']):,}</b>",
        "",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for index, item in enumerate(board["admins"][:20], start=1):
        business = item["commercial"]
        lines.append(
            f"{index}. <code>{item['trader_id']}</code> · کیفیت <b>{float(item['quality_score']):.0f}٪</b> · "
            f"تأیید اول <b>{float(item['first_pass_rate']):.0f}٪</b> · امتیاز <b>{int(item['points_total'])}</b> · "
            f"درآمد <b>{int(business['revenue']):,}</b>"
        )
        rows.append(
            [
                InlineKeyboardButton(
                    f"👤 {_owner_kpi_admin_name(db, item['trader_id'])[:26]}",
                    callback_data=f"owner_kpi_admin:{item['trader_id']}",
                )
            ]
        )
    if not board["admins"]:
        lines.append("هنوز داده عملکردی برای ادمین‌های تیم ثبت نشده است.")
    rows.append([InlineKeyboardButton("↩️ مرکز مالک", callback_data="owner_kpi_center")])
    await edit(query, "\n".join(lines), rows)


async def owner_team_calendar(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    board = team_operations_calendar(db, admin_ids=_owner_kpi_admin_ids(db), days=14)
    lines = [
        "🗓 <b>تقویم عملیات تیم · ۱۴ روز</b>",
        "تسک‌ها، سیگنال‌های زمان‌بندی‌شده و کمپین‌ها",
        "",
        f"رویداد: <b>{board['event_count']}</b> · عقب‌افتاده: <b>{board['overdue_count']}</b> · تداخل: <b>{len(board['conflicts'])}</b>",
        "",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    kind_icon = {"kpi_task": "🎯", "scheduled_signal": "📡", "campaign": "🚀"}
    for event in board["events"][:20]:
        lines.append(
            f"{'🔴' if event['overdue'] else kind_icon.get(event['kind'], '•')} "
            f"<b>{esc(event['title'])}</b> · {display_dt(event['at'])}"
        )
        if event.get("callback"):
            rows.append(
                [
                    InlineKeyboardButton(
                        f"{kind_icon.get(event['kind'], '📌')} {str(event['title'])[:34]}",
                        callback_data=str(event["callback"]),
                    )
                ]
            )
    if not board["events"]:
        lines.append("برای ۱۴ روز آینده رویداد ثبت‌شده‌ای وجود ندارد.")
    if board["conflicts"]:
        lines.extend(["", "⚠️ تداخل‌های کمتر از ۳۰ دقیقه شناسایی شده‌اند؛ بار کاری ادمین‌ها را بازبینی کنید."])
    rows.append([InlineKeyboardButton("🔄 تازه‌سازی", callback_data="owner_team_calendar")])
    rows.append([InlineKeyboardButton("↩️ مرکز مالک", callback_data="owner_kpi_center")])
    await edit(query, "\n".join(lines), rows)


async def owner_subscription_growth(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    await query.answer()
    board = subscription_growth_center(await async_snapshot())
    funnel, revenue, vip = board["funnel"], board["revenue"], board["vip"]
    lines = [
        "💎 <b>مرکز رشد اشتراک SENTINEL</b>",
        "قیف فروش و فرصت‌های قابل اقدام بر اساس رفتار واقعی کاربران",
        "",
        f"کاربر: <b>{int(funnel['users']):,}</b> → قصد خرید بالا: <b>{int(funnel['high_intent']):,}</b>",
        f"خریدار ۳۰ روز: <b>{int(funnel['buyers_30d']):,}</b> → VIP فعال: <b>{int(funnel['active_vip']):,}</b>",
        f"نرخ تبدیل: <b>{float(funnel['conversion_percent']):.1f}٪</b>",
        "",
        f"درآمد ۳۰ روز: <b>{int(revenue['current']):,}</b> · تغییر: <b>{float(revenue['change_percent']):+.1f}٪</b>",
        f"رو به انقضا: <b>{int(vip['expiring_7d']):,}</b> · خرید تکراری: <b>{int(vip['repeat_buyers_all']):,}</b>",
        "",
        "<b>فرصت‌های پیشنهادی</b>",
    ]
    for action in board["actions"][:8]:
        lines.append(
            f"• {esc(action['title'])}: <b>{int(action['users']):,}</b> کاربر · ارزش بالقوه <b>{int(action['estimated_value']):,}</b>"
        )
    if not board["actions"]:
        lines.append("• در حال حاضر فرصت فوری شناسایی نشد.")
    rows = [
        [
            InlineKeyboardButton("🚀 ساخت کمپین", callback_data="a_campaigns", style="success"),
            InlineKeyboardButton("👥 CRM", callback_data="a_crm"),
        ],
        [InlineKeyboardButton("📊 داشبورد تجاری", callback_data="a_dash:business")],
        [InlineKeyboardButton("↩️ مرکز مالک", callback_data="owner_kpi_center")],
    ]
    await edit(query, "\n".join(lines), rows)


async def owner_notification_intelligence(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    await query.answer()
    board = notification_intelligence(await async_snapshot())
    routing = board["routing"]
    lines = [
        "🔔 <b>هوشمندی اعلان‌ها</b>",
        "اندازه مخاطب، محدودیت‌ها و بهترین گروه پیش از ارسال",
        "",
        f"کاربران: <b>{int(board['users']):,}</b> · فارسی: <b>{int(board['languages'].get('fa', 0)):,}</b> · انگلیسی: <b>{int(board['languages'].get('en', 0)):,}</b>",
        f"ساعات سکوت: <b>{int(board['quiet_hours_users']):,}</b> · توقف اعلان: <b>{int(board['paused_users']):,}</b>",
        f"مسیرهای ثبت‌شده: <b>{int(routing['total']):,}</b> · مجاز: <b>{int(routing['allowed']):,}</b> · مسدود: <b>{int(routing['blocked']):,}</b>",
        f"نرخ عبور هوشمند: <b>{float(routing['delivery_rate']):.1f}٪</b>",
        "",
        "<b>پیشنهاد ارسال</b>",
    ]
    for item in board["recommendations"][:8]:
        lines.append(f"• {esc(item['title'])}: <b>{int(item['users']):,}</b> کاربر")
    if not board["recommendations"]:
        lines.append("• هنوز گروه رفتاری قابل اقدام ساخته نشده است.")
    rows = [
        [
            InlineKeyboardButton("📣 ارسال گروهی", callback_data="a_broadcast", style="primary"),
            InlineKeyboardButton("📢 مرکز اعلان", callback_data="a_announcement"),
        ],
        [InlineKeyboardButton("🚀 کمپین هدفمند", callback_data="a_campaigns")],
        [InlineKeyboardButton("↩️ مرکز مالک", callback_data="owner_kpi_center")],
    ]
    await edit(query, "\n".join(lines), rows)


async def owner_kpi_admin_detail(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    if not context.user_data.pop("_owner_kpi_query_answered", False):
        await query.answer()
    uid = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    if not uid.isdigit() or int(uid) not in _owner_kpi_admin_ids(db):
        await query.answer("ادمین پیدا نشد.", show_alert=True)
        return
    dashboard = kpi_trader_dashboard(db, uid)
    assigned_tasks = [
        row
        for row in db.get("kpi_trader_tasks", [])
        if isinstance(row, dict) and uid in [str(value) for value in row.get("assignee_ids", [])]
    ]
    active_tasks = sum(1 for row in assigned_tasks if row.get("status") == "active")
    delegated = get_delegated_admin(db, uid)
    view_enabled = delegated_has_permission(db, uid, PERMISSION_KPI_TRADER_VIEW)
    manage_enabled = delegated_has_permission(
        db, uid, PERMISSION_KPI_TRADER_MANAGE
    )
    lines = [
        f"👤 <b>{esc(_owner_kpi_admin_name(db, uid))}</b>",
        f"شناسه: <code>{uid}</code>",
        "",
        f"مشاهده و انجام تسک: <b>{'فعال ✅' if view_enabled else 'غیرفعال ⛔'}</b>",
        f"مدیریت و بررسی KPI: <b>{'فعال ✅' if manage_enabled else 'غیرفعال ⛔'}</b>",
        f"تسک اختصاص‌یافته: <b>{len(assigned_tasks)}</b> · فعال: <b>{active_tasks}</b>",
        f"امتیاز کل: <b>{dashboard['points_total']}</b> · این ماه: <b>{dashboard['points_month']}</b>",
        f"تأیید: <b>{dashboard['approved']}</b> · رد: <b>{dashboard['rejected']}</b> · در بررسی: <b>{dashboard['pending']}</b>",
        f"نرخ تأیید: <b>{dashboard['approval_rate']:.1f}٪</b> · به‌موقع: <b>{dashboard['on_time_rate']:.1f}٪</b>",
        f"کیفیت میانگین: <b>{dashboard['quality_score']:.1f}٪</b> · درآمد منتسب: <b>{int(dashboard['business']['revenue']):,}</b>",
        f"فروش: <b>{int(dashboard['business']['sales'])}</b> · تمدید: <b>{int(dashboard['business']['renewals'])}</b> · لید: <b>{int(dashboard['business']['leads'])}</b>",
    ]
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(
                "➕ تعیین تسک اختصاصی",
                callback_data=f"owner_kpi_assign:{uid}",
                style="success",
            )
        ],
        [
            InlineKeyboardButton(
                "➕/➖ اصلاح امتیاز", callback_data=f"owner_kpi_score:{uid}"
            ),
            InlineKeyboardButton(
                "📊 داشبورد تحلیلگر", callback_data=f"sig_analyst:{uid}"
            ),
        ],
    ]
    if delegated:
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'✅' if view_enabled else '⛔'} دسترسی انجام تسک",
                    callback_data=f"owner_kpi_perm:{uid}:{PERMISSION_KPI_TRADER_VIEW}",
                ),
                InlineKeyboardButton(
                    f"{'✅' if manage_enabled else '⛔'} دسترسی مدیریت KPI",
                    callback_data=f"owner_kpi_perm:{uid}:{PERMISSION_KPI_TRADER_MANAGE}",
                ),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton(
                    "👮 همه دسترسی‌های این ادمین",
                    callback_data=f"admin_manage:{uid}",
                )
            ]
        )
    else:
        lines.append(
            "\nاین فرد در ADMIN_IDS تعریف شده و دسترسی‌های اصلی او از داخل ربات محدود نمی‌شود."
        )
    rows.append(
        [InlineKeyboardButton("↩️ مرکز مالک", callback_data="owner_kpi_center")]
    )
    await edit(query, "\n".join(lines), rows)


async def owner_kpi_permission_toggle(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    _, uid, permission = str(query.data).split(":", 2)
    if permission not in {
        PERMISSION_KPI_TRADER_VIEW,
        PERMISSION_KPI_TRADER_MANAGE,
    }:
        await query.answer("دسترسی نامعتبر است.", show_alert=True)
        return
    db = await async_snapshot()
    if not get_delegated_admin(db, uid):
        await query.answer(
            "دسترسی ادمین‌های اصلی از متغیر ADMIN_IDS کنترل می‌شود.",
            show_alert=True,
        )
        return
    row = await async_with_db(
        lambda database: toggle_permission(
            database, uid, permission, query.from_user.id
        )
    )
    enabled = permission in set(row.get("permissions", []))
    await async_with_db(
        lambda database: audit(
            database,
            query.from_user.id,
            "owner_kpi_permission",
            f"{uid}:{permission}:{enabled}",
        )
    )
    await query.answer(
        "دسترسی فعال شد ✅" if enabled else "دسترسی غیرفعال شد ⛔",
        show_alert=True,
    )
    context.user_data["_owner_kpi_query_answered"] = True
    await owner_kpi_admin_detail(update, context)


async def owner_kpi_assign_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _require_owner_kpi(update):
        return ConversationHandler.END
    query = update.callback_query
    uid = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    if not uid.isdigit() or int(uid) not in _owner_kpi_admin_ids(db):
        await query.answer("ادمین پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    context.user_data["kpi_forced_assignee"] = uid
    context.user_data["kpi_return_callback"] = f"owner_kpi_admin:{uid}"
    await query.answer()
    await edit(
        query,
        (
            f"➕ <b>تسک اختصاصی برای ادمین {uid}</b>\n\n"
            "اطلاعات را دقیقاً در چهار خط بفرستید:\n\n"
            f"<code>عنوان فارسی\nEnglish title\n"
            f"10 | 2026-08-01 18:00 | {uid} | operations | high | 1\n"
            "توضیح فارسی || English description</code>\n\n"
            "ترتیب خط سوم: امتیاز | مهلت | شناسه | دسته | اولویت | تعداد هدف\n"
            "تسک بدون توجه به مقدار خط سوم، فقط به همین ادمین اختصاص داده می‌شود."
        ),
        [
            [
                InlineKeyboardButton(
                    "انصراف", callback_data=f"owner_kpi_admin:{uid}"
                )
            ]
        ],
    )
    return KPI_TASK_INPUT


async def owner_kpi_score_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _require_owner_kpi(update):
        return ConversationHandler.END
    query = update.callback_query
    uid = str(query.data).split(":", 1)[1]
    db = await async_snapshot()
    if not uid.isdigit() or int(uid) not in _owner_kpi_admin_ids(db):
        await query.answer("ادمین پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    context.user_data["owner_kpi_score_uid"] = uid
    await query.answer()
    await edit(
        query,
        (
            f"➕/➖ <b>اصلاح امتیاز KPI ادمین {uid}</b>\n\n"
            "مقدار و دلیل را با | جدا کنید:\n"
            "<code>+10 | پاداش عملکرد ویژه</code>\n"
            "<code>-5 | اصلاح ثبت اشتباه</code>\n\n"
            "هر تغییر در دفتر امتیاز غیرقابل‌حذف و قابل ممیزی ثبت می‌شود."
        ),
        [
            [
                InlineKeyboardButton(
                    "انصراف", callback_data=f"owner_kpi_admin:{uid}"
                )
            ]
        ],
    )
    return OWNER_KPI_SCORE_INPUT


async def owner_kpi_score_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not update.effective_user or not _is_owner_admin(update.effective_user.id):
        return ConversationHandler.END
    uid = str(context.user_data.get("owner_kpi_score_uid") or "")
    raw = str(update.effective_message.text or "").strip()
    try:
        value_raw, reason = [part.strip() for part in raw.split("|", 1)]
        points = int(_ascii_digits(value_raw))
        ledger = await async_with_db(
            lambda db: adjust_kpi_trader_score(
                db,
                trader_id=uid,
                points=points,
                actor_id=update.effective_user.id,
                reason=reason,
            )
        )
        await async_with_db(
            lambda db: audit(
                db,
                update.effective_user.id,
                "owner_kpi_score_adjustment",
                f"{uid}:{ledger['id']}:{points}",
            )
        )
    except (ValueError, TypeError, PermissionError) as exc:
        await reply(
            update,
            f"❌ {esc(exc)}\n\nفرمت درست: <code>+10 | دلیل تغییر</code>",
            [
                [
                    InlineKeyboardButton(
                        "انصراف", callback_data=f"owner_kpi_admin:{uid}"
                    )
                ]
            ],
        )
        return OWNER_KPI_SCORE_INPUT
    context.user_data.pop("owner_kpi_score_uid", None)
    total = kpi_trader_dashboard(await async_snapshot(), uid)["points_total"]
    try:
        language = _language_for_user(uid)
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            chat_id=int(uid),
            text=(
                f"📊 <b>KPI score adjustment</b>\nChange: <b>{points:+d}</b>\n"
                f"Reason: {esc(reason)}\nNew total: <b>{total}</b>"
                if language == "en"
                else f"📊 <b>اصلاح امتیاز KPI</b>\nتغییر: <b>{points:+d}</b>\n"
                f"دلیل: {esc(reason)}\nمجموع جدید: <b>{total}</b>"
            ),
            parse_mode=ParseMode.HTML,
        )
    except TelegramError:
        logger.info("Could not notify admin %s about KPI score adjustment", uid)
    await reply(
        update,
        f"✅ تغییر <b>{points:+d}</b> ثبت شد. مجموع جدید ادمین: <b>{total}</b>",
        [
            [
                InlineKeyboardButton(
                    "↩️ پرونده ادمین", callback_data=f"owner_kpi_admin:{uid}"
                )
            ]
        ],
    )
    return ConversationHandler.END


async def owner_kpi_setting_toggle(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _require_owner_kpi(update):
        return
    query = update.callback_query
    key = str(query.data).split(":", 1)[1]
    allowed = {
        "enabled",
        "evidence_required",
        "owner_review_only",
        "allow_manual_score_adjustment",
        "quality_gate_required",
    }
    if key not in allowed:
        await query.answer("تنظیم نامعتبر است.", show_alert=True)
        return
    db = await async_snapshot()
    value = not bool(kpi_settings(db).get(key, False))
    await async_with_db(
        lambda database: update_kpi_settings(
            database, actor_id=query.from_user.id, **{key: value}
        )
    )
    await async_with_db(
        lambda database: audit(
            database,
            query.from_user.id,
            "owner_kpi_setting",
            f"{key}:{value}",
        )
    )
    await query.answer("تنظیم ذخیره شد ✅", show_alert=True)
    context.user_data["_owner_kpi_query_answered"] = True
    await owner_kpi_center(update, context)


async def owner_kpi_limits_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _require_owner_kpi(update):
        return ConversationHandler.END
    query = update.callback_query
    settings = kpi_settings(await async_snapshot())
    await query.answer()
    await edit(
        query,
        (
            "⚙️ <b>سقف‌ها و سیاست امتیاز KPI</b>\n\n"
            "پنج مقدار را با | بفرستید:\n"
            "<code>1000 | 100000 | 7 | 80 | 10</code>\n\n"
            "ترتیب: سقف امتیاز هر تسک | بودجه ماهانه | مهلت پیش‌فرض | حداقل کیفیت | سقف تسک فعال هر تحلیلگر\n\n"
            f"فعلی: <b>{int(settings.get('max_task_points', 1000))}</b> | "
            f"<b>{int(settings.get('monthly_points_budget', 100000))}</b> | "
            f"<b>{int(settings.get('default_due_days', 7))}</b> | "
            f"<b>{int(settings.get('quality_gate_min_score', 80))}</b> | "
            f"<b>{int(settings.get('max_active_tasks_per_trader', 10))}</b>"
        ),
        [[InlineKeyboardButton("انصراف", callback_data="owner_kpi_center")]],
    )
    return OWNER_KPI_LIMITS_INPUT


async def owner_kpi_limits_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not update.effective_user or not _is_owner_admin(update.effective_user.id):
        return ConversationHandler.END
    try:
        values = [
            int(_ascii_digits(part.strip()))
            for part in str(update.effective_message.text or "").split("|")
        ]
        if len(values) not in {3, 5}:
            raise ValueError("دقیقاً پنج مقدار لازم است.")
        if len(values) == 3:
            values.extend([80, 10])
        settings = await async_with_db(
            lambda db: update_kpi_settings(
                db,
                actor_id=update.effective_user.id,
                max_task_points=values[0],
                monthly_points_budget=values[1],
                default_due_days=values[2],
                quality_gate_min_score=values[3],
                max_active_tasks_per_trader=values[4],
            )
        )
        await async_with_db(
            lambda db: audit(
                db,
                update.effective_user.id,
                "owner_kpi_limits",
                f"{values[0]}:{values[1]}:{values[2]}:{values[3]}:{values[4]}",
            )
        )
    except (ValueError, TypeError) as exc:
        await reply(
            update,
            f"❌ {esc(exc)}\n\nنمونه: <code>1000 | 100000 | 7 | 80 | 10</code>",
            [[InlineKeyboardButton("انصراف", callback_data="owner_kpi_center")]],
        )
        return OWNER_KPI_LIMITS_INPUT
    await reply(
        update,
        "✅ سیاست KPI ذخیره شد.\n"
        f"سقف تسک: <b>{int(settings['max_task_points']):,}</b> · "
        f"بودجه ماهانه: <b>{int(settings['monthly_points_budget']):,}</b> · "
        f"مهلت پیش‌فرض: <b>{int(settings['default_due_days'])}</b> روز · "
        f"کیفیت: <b>{int(settings['quality_gate_min_score'])}٪</b> · "
        f"سقف فعال: <b>{int(settings['max_active_tasks_per_trader'])}</b>",
        [[InlineKeyboardButton("👑 مرکز مالک", callback_data="owner_kpi_center")]],
    )
    return ConversationHandler.END


async def kpi_conversation_navigation(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Close KPI input state before routing a back/cancel button."""
    data = str(update.callback_query.data or "")
    for key in (
        "kpi_submission_task_id",
        "kpi_reject_submission_id",
        "kpi_forced_assignee",
        "kpi_return_callback",
        "owner_kpi_score_uid",
        "kpi_business_task_id",
    ):
        context.user_data.pop(key, None)
    if data == "kpi_trader_home":
        await kpi_trader_home(update, context)
    elif data == "a_kpi_trader":
        await kpi_admin_home(update, context)
    elif data == "owner_kpi_center":
        await owner_kpi_center(update, context)
    elif data.startswith("owner_kpi_admin:"):
        await owner_kpi_admin_detail(update, context)
    elif data.startswith("kpi_trader_task:"):
        await kpi_trader_task_view(update, context)
    elif data.startswith("kpi_review_view:"):
        await kpi_review_view(update, context)
    elif data.startswith("kpi_admin_task:"):
        await kpi_admin_task_view(update, context)
    return ConversationHandler.END



__feature_exports__ = ('crm_open', 'crm_message_start', 'crm_message_input', 'crm_discount_menu', 'crm_discount_send', 'crm_note_start', 'crm_note_input', 'crm_tag_start', 'crm_tag_input', 'crm_followup_start', 'crm_followup_input', 'crm_followup_clear', 'crm_orders', 'crm_education_orders', '_automation_panel_text', '_automation_rows', 'a_automations', 'a_renewals', 'automation_toggle', 'automation_setting_start', 'automation_setting_input', '_run_automation_cycle', 'crm_automation_run', 'crm_followup_action', 'automation_job', 'automation_outbox_job', 'campaign_scheduler_job', 'renewal_run_now', 'a_shifts', 'shift_set_start', 'shift_set_input', 'shift_toggle_handler', '_backup_index_path', '_backup_control_state', 'a_backups', 'backup_create_handler', 'backup_get_handler', 'backup_verify_handler', 'backup_verify_all_handler', 'backup_prune_handler', '_notify_pending_approval', 'backup_restore_handler', 'a_approvals', 'approval_toggle_handler', 'approval_operation_toggle', 'approval_expiry_handler', '_execute_approved_action', 'approval_review_handler', 'mission_control_view', 'admin_today_view', 'admin_today_toggle', 'provider_health_view', 'payment_reconciliation_view', 'payment_reconciliation_run', 'miniapp_runtime_view', 'miniapp_runtime_action', 'runtime_safety_view', 'runtime_safety_action', 'signal_exposure_board', 'signal_session_report', 'signal_versions_view', '_kpi_task_title', '_kpi_task_description', '_kpi_status_label', '_kpi_task_text', '_kpi_trader_ids', 'kpi_trader_home', 'kpi_trader_task_view', 'kpi_submission_start', '_kpi_evidence_from_message', 'kpi_submission_input', '_owner_kpi_admin_ids', '_owner_kpi_admin_name', '_require_owner_kpi', 'owner_kpi_center', 'owner_team_performance', 'owner_team_calendar', 'owner_subscription_growth', 'owner_notification_intelligence', 'owner_kpi_admin_detail', 'owner_kpi_permission_toggle', 'owner_kpi_assign_start', 'owner_kpi_score_start', 'owner_kpi_score_input', 'owner_kpi_setting_toggle', 'owner_kpi_limits_start', 'owner_kpi_limits_input', 'kpi_conversation_navigation')
