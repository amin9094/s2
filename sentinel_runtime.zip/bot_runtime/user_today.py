"""Personal daily dashboard for end users."""
from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

from modules.user_today import user_today_snapshot


def _today_event_line(event: dict[str, Any] | None, language: str) -> str:
    if not event:
        return "No high-priority event cached for today." if language == 'en' else "رویداد مهمی برای امروز در کش تقویم نیست."
    title = str(event.get('title') or '-') if language == 'en' else str(event.get('title_fa') or event.get('title') or '-')
    return f"{esc(event.get('currency') or '')} · {esc(title)} · <code>{esc(event.get('datetime') or '')}</code>"


async def user_today_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    language = _language_for_user(user_id)
    snapshot = user_today_snapshot(await async_snapshot(), user_id)
    signal = snapshot['latest_signal'] or {}
    if language == 'en':
        vip = f"Active · {snapshot['vip_days_left']} days" if snapshot['vip_active'] else 'Standard'
        signal_line = (f"{esc(signal.get('symbol'))} {esc(str(signal.get('side') or '').upper())} · {esc(signal.get('status') or 'open')}" if signal else 'No visible signal')
        text = (
            "🧭 <b>Today</b>\n\n"
            f"💎 Access: <b>{vip}</b>\n"
            f"📡 Signals: <b>{int(snapshot['signals'].get('open', 0) or 0)}</b> open · latest: {signal_line}\n"
            f"⭐ Watchlist: <b>{snapshot['watchlist_count']}</b> · 📔 Journal: <b>{snapshot['journal_total']}</b>\n"
            f"🔔 Active alerts: <b>{snapshot['active_alert_count']}</b> · 🎫 Open tickets: <b>{snapshot['open_ticket_count']}</b>\n"
            f"🏅 Points: <b>{snapshot['points']:,}</b>\n\n"
            f"📰 Next event: {_today_event_line(snapshot['next_event'], language)}"
        )
    else:
        vip = f"فعال · {snapshot['vip_days_left']} روز" if snapshot['vip_active'] else 'عادی'
        signal_line = (f"{esc(signal.get('symbol'))} {esc(str(signal.get('side') or '').upper())} · {esc(signal.get('status') or 'open')}" if signal else 'سیگنال قابل مشاهده‌ای نیست')
        text = (
            "🧭 <b>امروز من</b>\n\n"
            f"💎 دسترسی: <b>{vip}</b>\n"
            f"📡 سیگنال‌ها: <b>{int(snapshot['signals'].get('open', 0) or 0)}</b> باز · آخرین: {signal_line}\n"
            f"⭐ واچ‌لیست: <b>{snapshot['watchlist_count']}</b> · 📔 ژورنال: <b>{snapshot['journal_total']}</b>\n"
            f"🔔 هشدار فعال: <b>{snapshot['active_alert_count']}</b> · 🎫 تیکت باز: <b>{snapshot['open_ticket_count']}</b>\n"
            f"🏅 امتیاز: <b>{snapshot['points']:,}</b>\n\n"
            f"📰 رویداد بعدی: {_today_event_line(snapshot['next_event'], language)}"
        )
    rows = [
        [InlineKeyboardButton("📡 Signals" if language == 'en' else "📡 سیگنال‌ها", callback_data="u_signal_portal"), InlineKeyboardButton("📈 Markets" if language == 'en' else "📈 بازار", callback_data="u_price")],
        [InlineKeyboardButton("⭐ Watchlist" if language == 'en' else "⭐ واچ‌لیست", callback_data="user_watchlist"), InlineKeyboardButton("📔 Journal" if language == 'en' else "📔 ژورنال", callback_data="user_journal")],
        [InlineKeyboardButton("🔔 Notifications" if language == 'en' else "🔔 اعلان‌ها", callback_data="account_notifications"), InlineKeyboardButton("📰 Calendar" if language == 'en' else "📰 تقویم", callback_data="u_calendar:today")],
        [InlineKeyboardButton("🔄 Refresh" if language == 'en' else "🔄 تازه‌سازی", callback_data="u_today")],
        [InlineKeyboardButton("🏠 Home" if language == 'en' else "🏠 خانه", callback_data="home")],
    ]
    await edit(query, text, rows)


__feature_exports__ = ('user_today_view',)
